/* Automation Studio generated header file */
/* Do not edit ! */

#ifndef _ARPUBSUBD_
#define _ARPUBSUBD_
#ifdef __cplusplus
extern "C" 
{
#endif

#include <bur/plctypes.h>

#ifndef _BUR_PUBLIC
#define _BUR_PUBLIC
#endif



/* Prototyping of functions and function blocks */
_BUR_PUBLIC unsigned long ArPubSubDGetUdpMsgSendTotal(void);
_BUR_PUBLIC unsigned long ArPubSubDGetUdpMsgSendError(void);
_BUR_PUBLIC unsigned long ArPubSubDGetUdpMsgReceiveTotal(void);
_BUR_PUBLIC unsigned long ArPubSubDGetUdpMsgReceiveError(void);
_BUR_PUBLIC unsigned long ArPubSubDGetDataSetSendTotal(void);
_BUR_PUBLIC unsigned long ArPubSubDGetDataSetSendError(void);
_BUR_PUBLIC unsigned long ArPubSubDGetDataSetReceiveTotal(void);
_BUR_PUBLIC unsigned long ArPubSubDGetDataSetReceiveError(void);


#ifdef __cplusplus
};
#endif
#endif /* _ARPUBSUBD_ */

