#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_SETUP_SET(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue._SETUP_SET", sizeof(sCurrentUnitTest));

	bOperateSubscriptionQueue = 0;
	memset(&fbUA_MonitoredItemOperateList, 0, sizeof(fbUA_MonitoredItemOperateList));
	memset(&Data, 0, sizeof(Data));
	memset(&SubscriptionQueueDataStored, 0, sizeof(SubscriptionQueueDataStored));

	// Operate Queue besetzen
	memset(&Subscription, 0, sizeof(Subscription));
	BrbUaRcGetSubscription(&RunClient, SUBQUEUE_IDX_QUEUE, &Subscription, 0);
	fbUA_MonitoredItemOperateList.SubscriptionHdl = Subscription.nSubscriptionHandle;
	fbUA_MonitoredItemOperateList.MonitoredItemHdlCount = 2;
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	BrbUaRcGetMonitoredItem(&RunClient, SUBQUEUE_IDX_QUEUE, 0, &MonitoredItem);
	fbUA_MonitoredItemOperateList.MonitoredItemHdls[0] = MonitoredItem.nMonitoredItemHandle;
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	BrbUaRcGetMonitoredItem(&RunClient, SUBQUEUE_IDX_QUEUE, 1, &MonitoredItem);
	fbUA_MonitoredItemOperateList.MonitoredItemHdls[1] = MonitoredItem.nMonitoredItemHandle;

	// Finished
	TEST_DONE;
}

_CYCLIC_SET(void)
{
	if(RunClient.State.eState >= eBRB_RCSTATE_INIT_DONE && RunClient.State.eState < eBRB_RCSTATE_EXITING)
	{
		if(bRunCyclic == 1)
		{
			fbBrbUaRunClientCyclic.pRunClient = &RunClient;
			BrbUaRunClientCyclic(&fbBrbUaRunClientCyclic);
		}
		// Operate Queue
		fbUA_MonitoredItemOperateList.Execute = bOperateSubscriptionQueue;
		if(fbUA_MonitoredItemOperateList.Busy)
		{
			fbUA_MonitoredItemOperateList.Execute = 1;
		}
		else if(fbUA_MonitoredItemOperateList.Done || fbUA_MonitoredItemOperateList.Error)
		{
			fbUA_MonitoredItemOperateList.Execute = 0;
		}
		UA_MonitoredItemOperateList(&fbUA_MonitoredItemOperateList);
	}
	BrbUaRcMonitor(&RunClient, &CyclicMonitor);
	return;
}

_TEST SubscriptionQueue_CheckMonitoredItems(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_CheckMonitoredItems", sizeof(sCurrentUnitTest));

	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, SUBQUEUE_IDX_QUEUE, 0, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeQualityId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nMonitoredItemErrorId); // Good
	
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, SUBQUEUE_IDX_QUEUE, 1, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeQualityId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nMonitoredItemErrorId); // Good

	// Finished
	TEST_DONE;
}

// Test des Empfangs -------------------------------------------------------------------------------------------------------------------

_TEST SubscriptionQueue_Receive_NotOperating_Store(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_Receive_NotOperating_Store", sizeof(sCurrentUnitTest));

	// Werte speichern
	memcpy(&SubscriptionQueueDataStored, &Data.SubscriptionQueue, sizeof(SubscriptionQueueDataStored));
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionQueue_Receive_NotOperating_Wait(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_Receive_NotOperating_Wait", sizeof(sCurrentUnitTest));

	// Zeit abwarten
	fbTonWait.IN = 1;
	fbTonWait.PT = 2000;
	TON(&fbTonWait);
	TEST_BUSY_CONDITION(fbTonWait.Q == 0)
	fbTonWait.IN = 0;
	TON(&fbTonWait);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionQueue_Receive_NotOperating_Check(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_Receive_NotOperating_Check", sizeof(sCurrentUnitTest));

	// Werte testen. Achtung: Da der Update stark von Zeiten abh�ngt, die ArSim aber nicht deterministisch ist, kann hier manchmal ein Fehler registiert werden!
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUntCltQueue002 == Data.SubscriptionQueue.nUntCltQueue002, "SubscriptionQueue002 not operated has changed!");
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUntCltQueue010 == Data.SubscriptionQueue.nUntCltQueue010, "SubscriptionQueue010 not operated has changed!");
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionQueue_Receive_StartOperate(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_Receive_StartOperate", sizeof(sCurrentUnitTest));

	// Operate-Aufruf starten
	bOperateSubscriptionQueue = 1;

	// Finished
	TEST_DONE;
}

_TEST SubscriptionQueue_Receive_Operating_Store(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_Receive_Operating_Store", sizeof(sCurrentUnitTest));

	// Werte speichern
	memcpy(&SubscriptionQueueDataStored, &Data.SubscriptionQueue, sizeof(SubscriptionQueueDataStored));
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionQueue_Receive_Operating_Wait(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_Receive_Operating_Wait", sizeof(sCurrentUnitTest));

	// Zeit abwarten
	fbTonWait.IN = 1;
	fbTonWait.PT = 2000;
	TON(&fbTonWait);
	TEST_BUSY_CONDITION(fbTonWait.Q == 0)
	fbTonWait.IN = 0;
	TON(&fbTonWait);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionQueue_Receive_Operating_Check(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_Receive_Operating_Check", sizeof(sCurrentUnitTest));

	// Werte testen. Achtung: Da der Update stark von Zeiten abh�ngt, die ArSim aber nicht deterministisch ist, kann hier manchmal ein Fehler registiert werden!
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUntCltQueue002 != Data.SubscriptionQueue.nUntCltQueue002, "SubscriptionQueue002 operated was not updated!");
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUntCltQueue010 != Data.SubscriptionQueue.nUntCltQueue010, "SubscriptionQueue010 operated was not updated!");

	// Finished
	TEST_DONE;
}

_TEST SubscriptionQueue_Receive_EndOperate(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_Receive_EndOperate", sizeof(sCurrentUnitTest));

	// Operate-Aufruf beenden
	bOperateSubscriptionQueue = 0;

	// Zeit abwarten
	fbTonWait.IN = 1;
	fbTonWait.PT = 1000;
	TON(&fbTonWait);
	TEST_BUSY_CONDITION(fbTonWait.Q == 0)
	fbTonWait.IN = 0;
	TON(&fbTonWait);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-03-19 07:12:48Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("SubscriptionQueue_CheckMonitoredItems", SubscriptionQueue_CheckMonitoredItems), 
	new_TestFixture("SubscriptionQueue_Receive_NotOperating_Store", SubscriptionQueue_Receive_NotOperating_Store), 
	new_TestFixture("SubscriptionQueue_Receive_NotOperating_Wait", SubscriptionQueue_Receive_NotOperating_Wait), 
	new_TestFixture("SubscriptionQueue_Receive_NotOperating_Check", SubscriptionQueue_Receive_NotOperating_Check), 
	new_TestFixture("SubscriptionQueue_Receive_StartOperate", SubscriptionQueue_Receive_StartOperate), 
	new_TestFixture("SubscriptionQueue_Receive_Operating_Store", SubscriptionQueue_Receive_Operating_Store), 
	new_TestFixture("SubscriptionQueue_Receive_Operating_Wait", SubscriptionQueue_Receive_Operating_Wait), 
	new_TestFixture("SubscriptionQueue_Receive_Operating_Check", SubscriptionQueue_Receive_Operating_Check), 
	new_TestFixture("SubscriptionQueue_Receive_EndOperate", SubscriptionQueue_Receive_EndOperate), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaRcSubscriptionQueue, "Set_BrbUaRcSubscriptionQueue", 0, 0, fixtures, setupSet, 0, cyclicSetCaller);

