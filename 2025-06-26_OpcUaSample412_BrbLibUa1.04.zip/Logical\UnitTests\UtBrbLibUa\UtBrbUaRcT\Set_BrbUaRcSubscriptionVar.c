#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

void AssertSubscription(BrbUaRcSubscription_TYP* pSubExpected, BrbUaRcSubscription_TYP* pSubActual)
{
	BRB_ASSERT_EQUAL_BOOL(	pSubExpected->bPublishingEnable,		pSubActual->bPublishingEnable);
	TEST_ASSERT_EQUAL_INT(	pSubExpected->nPriority,						pSubActual->nPriority);
	TEST_ASSERT_EQUAL_INT(	pSubExpected->nMonitoredItemCount,	pSubActual->nMonitoredItemCount);
	TEST_ASSERT_EQUAL_INT(	pSubExpected->nEventItemCount,			pSubActual->nEventItemCount);
	BRB_ASSERT_EQUAL_UDINT(	pSubExpected->nErrorId,							pSubActual->nErrorId);
}

void AssertSubscriptionIntern(BrbUaRcSubscription_TYP* pSubExpected, BrbUaRcSubscriptionIntern_TYP* pSubActual)
{
	BRB_ASSERT_EQUAL_BOOL(	pSubExpected->bPublishingEnable,		pSubActual->bPublishingEnable);
	TEST_ASSERT_EQUAL_INT(	pSubExpected->nPriority,						pSubActual->nPriority);
	TEST_ASSERT_EQUAL_INT(	pSubExpected->nMonitoredItemCount,	pSubActual->nMonitoredItemCount);
	TEST_ASSERT_EQUAL_INT(	pSubExpected->nEventItemCount,			pSubActual->nEventItemCount);
	BRB_ASSERT_EQUAL_UDINT(	pSubExpected->nErrorId,							pSubActual->nErrorId);
}

void AssertMonitoredItem(BrbUaRcMonitoredItem_TYP* pMiExpected, BrbUaRcMonitoredItem_TYP* pMiActual)
{
	TEST_ASSERT_EQUAL_INT(		pMiExpected->nDatObjNamespaceIndex,									pMiActual->nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(		pMiExpected->NodeId.NamespaceIndex,									pMiActual->NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(		pMiExpected->NodeId.IdentifierType,									pMiActual->NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING(	pMiExpected->NodeId.Identifier,											pMiActual->NodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(		pMiExpected->nNodeHandleErrorId,										pMiActual->nNodeHandleErrorId);
	BRB_ASSERT_EQUAL_DINT(		pMiExpected->AddInfo.AttributeId,										pMiActual->AddInfo.AttributeId); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_STRING(	pMiExpected->sVar,																	pMiActual->sVar);
	BRB_ASSERT_EQUAL_UDINT(		pMiExpected->nQueueSizeOri,													pMiActual->nQueueSizeOri);
	BRB_ASSERT_EQUAL_DINT(		pMiExpected->MonitoringParameter.SamplingInterval,	pMiActual->MonitoringParameter.SamplingInterval);
	BRB_ASSERT_EQUAL_UDINT(		pMiExpected->MonitoringParameter.QueueSize,					pMiActual->MonitoringParameter.QueueSize);
	BRB_ASSERT_EQUAL_BOOL(		pMiExpected->MonitoringParameter.DiscardOldest,			pMiActual->MonitoringParameter.DiscardOldest);
	BRB_ASSERT_EQUAL_DINT(		pMiExpected->MonitoringParameter.DeadbandType,			pMiActual->MonitoringParameter.DeadbandType); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_REAL(		pMiExpected->MonitoringParameter.Deadband,					pMiActual->MonitoringParameter.Deadband);
	BRB_ASSERT_EQUAL_UDINT(		pMiExpected->nNodeQualityId,												pMiActual->nNodeQualityId);
	BRB_ASSERT_EQUAL_UDINT(		pMiExpected->nMonitoredItemErrorId,									pMiActual->nMonitoredItemErrorId);
}

_SETUP_SET(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar._SETUP_SET", sizeof(sCurrentUnitTest));

	memset(&Data, 0, sizeof(Data));
	memset(&SubscriptionVarDataStored, 0, sizeof(SubscriptionVarDataStored));

	// Finished
	TEST_DONE;
}

_CYCLIC_SET(void)
{
	if(RunClient.State.eState >= eBRB_RCSTATE_INIT_DONE && RunClient.State.eState < eBRB_RCSTATE_EXITING)
	{
		if(bRunCyclic == 1)
		{
			fbBrbUaRunClientCyclic.pRunClient = &RunClient;
			BrbUaRunClientCyclic(&fbBrbUaRunClientCyclic);
		}
	}
	BrbUaRcMonitor(&RunClient, &CyclicMonitor);
	return;
}

_TEST SubscriptionVar_GetSubscription_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetSubscription_NulPtr", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRcGetSubscription(0, 0, &Subscription, &SubscriptionIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);
	
	uintOut = BrbUaRcGetSubscription(&RunClient, 0, 0, &SubscriptionIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetSubscription_InvalidSubscriptionIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetSubscription_InvalidSubscriptionIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Subscription, 0, sizeof(Subscription));
	memset(&SubscriptionIntern, 0, sizeof(SubscriptionIntern));
	uintOut = BrbUaRcGetSubscription(&RunClient, 99, &Subscription, &SubscriptionIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Subscription.nSubscriptionIndex = 99;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.Subscription.nMonitorStatus);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetSubscription_InvalidPrio(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetSubscription_InvalidPrio", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Subscription, 0, sizeof(Subscription));
	memset(&SubscriptionIntern, 0, sizeof(SubscriptionIntern));
	uintOut = BrbUaRcGetSubscription(&RunClient, SUBVAR_IDX_INV_PRIO, &Subscription, &SubscriptionIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	BRB_ASSERT_EQUAL_BOOL(1, Subscription.bPublishingEnable);
	TEST_ASSERT_EQUAL_INT(255, Subscription.nPriority); // Wird auf 255 korrigiert
	BRB_ASSERT_EQUAL_DINT(500, Subscription.tPublishingInterval);
	TEST_ASSERT_EQUAL_INT(1, Subscription.nMonitoredItemCount);
	TEST_ASSERT_EQUAL_INT(0, Subscription.nEventItemCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Subscription.nErrorId); // Good
	AssertSubscriptionIntern(&Subscription, &SubscriptionIntern);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Subscription.nSubscriptionIndex = SUBVAR_IDX_INV_PRIO;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.Subscription.nMonitorStatus);
	AssertSubscription(&Subscription, &RcMonitor.Subscription.Subscription);
	AssertSubscriptionIntern(&Subscription, &RcMonitor.Subscription.SubscriptionIntern);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetSubscription_InvalidPubInt(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetSubscription_InvalidPubInt", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Subscription, 0, sizeof(Subscription));
	memset(&SubscriptionIntern, 0, sizeof(SubscriptionIntern));
	uintOut = BrbUaRcGetSubscription(&RunClient, SUBVAR_IDX_INV_PUBINT, &Subscription, &SubscriptionIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	BRB_ASSERT_EQUAL_BOOL(1, Subscription.bPublishingEnable);
	TEST_ASSERT_EQUAL_INT(100, Subscription.nPriority);
	BRB_ASSERT_EQUAL_DINT(50, Subscription.tPublishingInterval); // Wird auf 50 korrigiert
	TEST_ASSERT_EQUAL_INT(1, Subscription.nMonitoredItemCount);
	TEST_ASSERT_EQUAL_INT(0, Subscription.nEventItemCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Subscription.nErrorId); // Good
	AssertSubscriptionIntern(&Subscription, &SubscriptionIntern);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Subscription.nSubscriptionIndex = SUBVAR_IDX_INV_PUBINT;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.Subscription.nMonitorStatus);
	AssertSubscription(&Subscription, &RcMonitor.Subscription.Subscription);
	AssertSubscriptionIntern(&Subscription, &RcMonitor.Subscription.SubscriptionIntern);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetSubscription_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetSubscription_Ok", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Subscription, 0, sizeof(Subscription));
	memset(&SubscriptionIntern, 0, sizeof(SubscriptionIntern));
	uintOut = BrbUaRcGetSubscription(&RunClient, SUBVAR_IDX_OK, &Subscription, &SubscriptionIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	BRB_ASSERT_EQUAL_BOOL(1, Subscription.bPublishingEnable);
	TEST_ASSERT_EQUAL_INT(255, Subscription.nPriority);
	BRB_ASSERT_EQUAL_DINT(500, Subscription.tPublishingInterval);
	TEST_ASSERT_EQUAL_INT(10, Subscription.nMonitoredItemCount);
	TEST_ASSERT_EQUAL_INT(0, Subscription.nEventItemCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Subscription.nErrorId); // Good
	AssertSubscriptionIntern(&Subscription, &SubscriptionIntern);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Subscription.nSubscriptionIndex = SUBVAR_IDX_OK;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.Subscription.nMonitorStatus);
	AssertSubscription(&Subscription, &RcMonitor.Subscription.Subscription);
	AssertSubscriptionIntern(&Subscription, &RcMonitor.Subscription.SubscriptionIntern);
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetMonitoredItem_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetMonitoredItem_NulPtr", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRcGetMonitoredItem(0, 0, 0, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);
	
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, 0, 0, 0);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetMonitoredItem_InvalidSubscriptionIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetMonitoredItem_InvalidSubscriptionIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, 99, 0, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.MonitoredItem.nSubscriptionIndex = 99;
	RcMonitor.MonitoredItem.nMonitoredItemIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.MonitoredItem.nMonitorStatus);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, SUBVAR_IDX_OK, 99, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.MonitoredItem.nSubscriptionIndex = SUBVAR_IDX_OK;
	RcMonitor.MonitoredItem.nMonitoredItemIndex = 99;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.MonitoredItem.nMonitorStatus);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemNs(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemNs", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, SUBVAR_IDX_INV_MI_NS, 0, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(99, MonitoredItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, MonitoredItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, MonitoredItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.SubscriptionVar.anUint[2]", MonitoredItem.NodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, MonitoredItem.nNodeHandleErrorId); // Bad_NodeIdUnknown
	BRB_ASSERT_EQUAL_DINT(UAAI_Value, MonitoredItem.AddInfo.AttributeId); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionVar.anUint[2]", MonitoredItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0, MonitoredItem.nQueueSizeOri);
	BRB_ASSERT_EQUAL_DINT(500, MonitoredItem.MonitoringParameter.SamplingInterval);
	BRB_ASSERT_EQUAL_UDINT(0, MonitoredItem.MonitoringParameter.QueueSize);
	BRB_ASSERT_EQUAL_BOOL(1, MonitoredItem.MonitoringParameter.DiscardOldest);
	BRB_ASSERT_EQUAL_DINT(UADeadbandType_None, MonitoredItem.MonitoringParameter.DeadbandType); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_REAL(0.0, MonitoredItem.MonitoringParameter.Deadband);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeQualityId); // Good
	BRB_ASSERT_EQUAL_UDINT(0xA00C0000, MonitoredItem.nMonitoredItemErrorId); // PlcOpen_BadNodeInvalidHdl
	
	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.MonitoredItem.nSubscriptionIndex = SUBVAR_IDX_INV_MI_NS;
	RcMonitor.MonitoredItem.nMonitoredItemIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.MonitoredItem.nMonitorStatus);
	AssertMonitoredItem(&MonitoredItem, &RcMonitor.MonitoredItem.MonitoredItem);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemNode(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemNode", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, SUBVAR_IDX_INV_MI_NODE, 0, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, MonitoredItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, MonitoredItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, MonitoredItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.SubscriptionVar.InvalidNode", MonitoredItem.NodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, MonitoredItem.nNodeHandleErrorId); // Bad_NodeIdUnknown
	BRB_ASSERT_EQUAL_DINT(UAAI_Value, MonitoredItem.AddInfo.AttributeId); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionVar.anUint[3]", MonitoredItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0, MonitoredItem.nQueueSizeOri);
	BRB_ASSERT_EQUAL_DINT(500, MonitoredItem.MonitoringParameter.SamplingInterval);
	BRB_ASSERT_EQUAL_UDINT(0, MonitoredItem.MonitoringParameter.QueueSize);
	BRB_ASSERT_EQUAL_BOOL(1, MonitoredItem.MonitoringParameter.DiscardOldest);
	BRB_ASSERT_EQUAL_DINT(UADeadbandType_None, MonitoredItem.MonitoringParameter.DeadbandType); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_REAL(0.0, MonitoredItem.MonitoringParameter.Deadband);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeQualityId); // Good
	BRB_ASSERT_EQUAL_UDINT(0xA00C0000, MonitoredItem.nMonitoredItemErrorId); // PlcOpen_BadNodeInvalidHdl
	
	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.MonitoredItem.nSubscriptionIndex = SUBVAR_IDX_INV_MI_NODE;
	RcMonitor.MonitoredItem.nMonitoredItemIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.MonitoredItem.nMonitorStatus);
	AssertMonitoredItem(&MonitoredItem, &RcMonitor.MonitoredItem.MonitoredItem);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemVar(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemVar", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, SUBVAR_IDX_INV_MI_VAR, 0, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, MonitoredItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, MonitoredItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, MonitoredItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.SubscriptionVar.anUint[4]", MonitoredItem.NodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(UAAI_Value, MonitoredItem.AddInfo.AttributeId); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionVar.InvalidVar", MonitoredItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0, MonitoredItem.nQueueSizeOri);
	BRB_ASSERT_EQUAL_DINT(500, MonitoredItem.MonitoringParameter.SamplingInterval);
	BRB_ASSERT_EQUAL_UDINT(0, MonitoredItem.MonitoringParameter.QueueSize);
	BRB_ASSERT_EQUAL_BOOL(1, MonitoredItem.MonitoringParameter.DiscardOldest);
	BRB_ASSERT_EQUAL_DINT(UADeadbandType_None, MonitoredItem.MonitoringParameter.DeadbandType); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_REAL(0.0, MonitoredItem.MonitoringParameter.Deadband);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeQualityId); // Good
	BRB_ASSERT_EQUAL_UDINT(0xB0040000, MonitoredItem.nMonitoredItemErrorId); // PlcOpen_BadVariableNameInvalid
	
	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.MonitoredItem.nSubscriptionIndex = SUBVAR_IDX_INV_MI_VAR;
	RcMonitor.MonitoredItem.nMonitoredItemIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.MonitoredItem.nMonitorStatus);
	AssertMonitoredItem(&MonitoredItem, &RcMonitor.MonitoredItem.MonitoredItem);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemAttributeId(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemAttributeId", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, SUBVAR_IDX_INV_MI_ATTID, 0, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, MonitoredItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, MonitoredItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, MonitoredItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.SubscriptionVar.anUint[5]", MonitoredItem.NodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(99, MonitoredItem.AddInfo.AttributeId); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionVar.anUint[5]", MonitoredItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0, MonitoredItem.nQueueSizeOri);
	BRB_ASSERT_EQUAL_DINT(500, MonitoredItem.MonitoringParameter.SamplingInterval);
	BRB_ASSERT_EQUAL_UDINT(0, MonitoredItem.MonitoringParameter.QueueSize);
	BRB_ASSERT_EQUAL_BOOL(1, MonitoredItem.MonitoringParameter.DiscardOldest);
	BRB_ASSERT_EQUAL_DINT(UADeadbandType_None, MonitoredItem.MonitoringParameter.DeadbandType); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_REAL(0.0, MonitoredItem.MonitoringParameter.Deadband);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeQualityId); // PlcOpen_BadMonitoredItemInvalidHdl
	BRB_ASSERT_EQUAL_UDINT(0xA0140000, MonitoredItem.nMonitoredItemErrorId); // Good
	
	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.MonitoredItem.nSubscriptionIndex = SUBVAR_IDX_INV_MI_ATTID;
	RcMonitor.MonitoredItem.nMonitoredItemIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.MonitoredItem.nMonitorStatus);
	AssertMonitoredItem(&MonitoredItem, &RcMonitor.MonitoredItem.MonitoredItem);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemSamplingInterval(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemSamplingInterval", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, SUBVAR_IDX_INV_MI_SAMP, 0, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, MonitoredItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, MonitoredItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, MonitoredItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.SubscriptionVar.anUint[6]", MonitoredItem.NodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(UAAI_Value, MonitoredItem.AddInfo.AttributeId); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionVar.anUint[6]", MonitoredItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0, MonitoredItem.nQueueSizeOri);
	BRB_ASSERT_EQUAL_DINT(1000, MonitoredItem.MonitoringParameter.SamplingInterval); // Wird auf 1000 korrigiert
	BRB_ASSERT_EQUAL_UDINT(1, MonitoredItem.MonitoringParameter.QueueSize);
	BRB_ASSERT_EQUAL_BOOL(1, MonitoredItem.MonitoringParameter.DiscardOldest);
	BRB_ASSERT_EQUAL_DINT(UADeadbandType_None, MonitoredItem.MonitoringParameter.DeadbandType); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_REAL(0.0, MonitoredItem.MonitoringParameter.Deadband);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeQualityId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nMonitoredItemErrorId); // Good
	
	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.MonitoredItem.nSubscriptionIndex = SUBVAR_IDX_INV_MI_SAMP;
	RcMonitor.MonitoredItem.nMonitoredItemIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.MonitoredItem.nMonitorStatus);
	AssertMonitoredItem(&MonitoredItem, &RcMonitor.MonitoredItem.MonitoredItem);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemDeadbandType(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemDeadbandType", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, SUBVAR_IDX_INV_MI_DEADTYPE, 0, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, MonitoredItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, MonitoredItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, MonitoredItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.SubscriptionVar.anUint[7]", MonitoredItem.NodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(UAAI_Value, MonitoredItem.AddInfo.AttributeId); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionVar.anUint[7]", MonitoredItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0, MonitoredItem.nQueueSizeOri);
	BRB_ASSERT_EQUAL_DINT(500, MonitoredItem.MonitoringParameter.SamplingInterval);
	BRB_ASSERT_EQUAL_UDINT(1, MonitoredItem.MonitoringParameter.QueueSize);
	BRB_ASSERT_EQUAL_BOOL(1, MonitoredItem.MonitoringParameter.DiscardOldest);
	BRB_ASSERT_EQUAL_DINT(UADeadbandType_None, MonitoredItem.MonitoringParameter.DeadbandType); // Wird auf 0 korrigiert // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_REAL(0.0, MonitoredItem.MonitoringParameter.Deadband);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeQualityId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nMonitoredItemErrorId); // Good
	
	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.MonitoredItem.nSubscriptionIndex = SUBVAR_IDX_INV_MI_DEADTYPE;
	RcMonitor.MonitoredItem.nMonitoredItemIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.MonitoredItem.nMonitorStatus);
	AssertMonitoredItem(&MonitoredItem, &RcMonitor.MonitoredItem.MonitoredItem);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetMonitoredItem_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetMonitoredItem_Ok", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, SUBVAR_IDX_OK, 5, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, MonitoredItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, MonitoredItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, MonitoredItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.SubscriptionVar.anUint[15]", MonitoredItem.NodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(UAAI_Value, MonitoredItem.AddInfo.AttributeId); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionVar.anUint[15]", MonitoredItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0, MonitoredItem.nQueueSizeOri);
	BRB_ASSERT_EQUAL_DINT(500, MonitoredItem.MonitoringParameter.SamplingInterval);
	BRB_ASSERT_EQUAL_UDINT(1, MonitoredItem.MonitoringParameter.QueueSize);
	BRB_ASSERT_EQUAL_BOOL(1, MonitoredItem.MonitoringParameter.DiscardOldest);
	BRB_ASSERT_EQUAL_DINT(UADeadbandType_None, MonitoredItem.MonitoringParameter.DeadbandType); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_REAL(0.0, MonitoredItem.MonitoringParameter.Deadband);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeQualityId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nMonitoredItemErrorId); // Good
	
	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.MonitoredItem.nSubscriptionIndex = SUBVAR_IDX_OK;
	RcMonitor.MonitoredItem.nMonitoredItemIndex = 5;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.MonitoredItem.nMonitorStatus);
	AssertMonitoredItem(&MonitoredItem, &RcMonitor.MonitoredItem.MonitoredItem);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetMiValueChanged_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetMiValueChanged_NulPtr", sizeof(sCurrentUnitTest));

	boolOut = BrbUaRcGetMiValueChanged(0, SUBVAR_IDX_OK, 2, 1);
	BRB_ASSERT_EQUAL_BOOL(0, boolOut);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetMiValueChanged_InvalidSubscriptionIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetMiValueChanged_InvalidSubscriptionIndex", sizeof(sCurrentUnitTest));

	boolOut = BrbUaRcGetMiValueChanged(&RunClient, 99, 2, 1);
	BRB_ASSERT_EQUAL_BOOL(0, boolOut);
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetMiValueChanged_InvalidMonitoredItemIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetMiValueChanged_InvalidMonitoredItemIndex", sizeof(sCurrentUnitTest));

	boolOut = BrbUaRcGetMiValueChanged(&RunClient, SUBVAR_IDX_OK, 99, 1);
	BRB_ASSERT_EQUAL_BOOL(0, boolOut);
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetMiRemainingValueCount_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetMiRemainingValueCount_NulPtr", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRcGetMiRemainingValueCount(0, SUBVAR_IDX_OK, 2);
	BRB_ASSERT_EQUAL_UDINT(0, uintOut);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetMiRemainingValueCount_InvalidSubscriptionIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetMiRemainingValueCount_InvalidSubscriptionIndex", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRcGetMiRemainingValueCount(&RunClient, 99, 2);
	BRB_ASSERT_EQUAL_UDINT(0, uintOut);
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_GetMiRemainingValueCount_InvalidMonitoredItemIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_GetMiRemainingValueCount_InvalidMonitoredItemIndex", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRcGetMiRemainingValueCount(&RunClient, SUBVAR_IDX_OK, 99);
	BRB_ASSERT_EQUAL_UDINT(0, uintOut);
	
	// Finished
	TEST_DONE;
}

// Test des Empfangs und �nderung der Parameter	-------------------------------------------------------------------------------------------------------------------

_TEST SubscriptionVar_Receive_Enabled_Store(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_Receive_Enabled_Store", sizeof(sCurrentUnitTest));

	// Werte speichern
	memcpy(&SubscriptionVarDataStored, &Data.SubscriptionVar, sizeof(SubscriptionVarDataStored));
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_Receive_Enabled_Wait(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_Receive_Enabled_Wait", sizeof(sCurrentUnitTest));

	// Zeit abwarten
	fbTonWait.IN = 1;
	fbTonWait.PT = 3000;
	TON(&fbTonWait);
	TEST_BUSY_CONDITION(fbTonWait.Q == 0)
	fbTonWait.IN = 0;
	TON(&fbTonWait);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_Receive_Enabled_Check(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_Receive_Enabled_Check", sizeof(sCurrentUnitTest));

	// Werte testen. Achtung: Da der Update stark von Zeiten abh�ngt, die ArSim aber nicht deterministisch ist, kann hier manchmal ein Fehler registiert werden!
	TEST_ASSERT_MESSAGE(SubscriptionVarDataStored.anUint[10] != Data.SubscriptionVar.anUint[10], "SubscriptionVar [10] was not updated!");
	TEST_ASSERT_MESSAGE(SubscriptionVarDataStored.anUint[14] != Data.SubscriptionVar.anUint[14], "SubscriptionVar [14] was not updated!");
	TEST_ASSERT_MESSAGE(SubscriptionVarDataStored.anUint[19] != Data.SubscriptionVar.anUint[19], "SubscriptionVar [19] was not updated!");
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_SetSubscription_NulPtr0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_SetSubscription_NulPtr0", sizeof(sCurrentUnitTest));

	fbBrbUaRcSetSubscription.pRunClient = 0;
	fbBrbUaRcSetSubscription.nSubscriptionIndex = SUBVAR_IDX_OK;
	fbBrbUaRcSetSubscription.pSubscription = &Subscription;
	BrbUaRcSetSubscription(&fbBrbUaRcSetSubscription);
	TEST_BUSY_CONDITION(fbBrbUaRcSetSubscription.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, fbBrbUaRcSetSubscription.nStatus);
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_SetSubscription_NulPtr1(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_SetSubscription_NulPtr1", sizeof(sCurrentUnitTest));

	fbBrbUaRcSetSubscription.pRunClient = &RunClient;
	fbBrbUaRcSetSubscription.nSubscriptionIndex = SUBVAR_IDX_OK;
	fbBrbUaRcSetSubscription.pSubscription = 0;
	BrbUaRcSetSubscription(&fbBrbUaRcSetSubscription);
	TEST_BUSY_CONDITION(fbBrbUaRcSetSubscription.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, fbBrbUaRcSetSubscription.nStatus);
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_SetSubscription_InvalidSubscriptionIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_SetSubscription_InvalidSubscriptionIndex", sizeof(sCurrentUnitTest));

	fbBrbUaRcSetSubscription.pRunClient = &RunClient;
	fbBrbUaRcSetSubscription.nSubscriptionIndex = 99;
	fbBrbUaRcSetSubscription.pSubscription = &Subscription;
	BrbUaRcSetSubscription(&fbBrbUaRcSetSubscription);
	TEST_BUSY_CONDITION(fbBrbUaRcSetSubscription.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, fbBrbUaRcSetSubscription.nStatus);
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_Subscription_Disable_Get(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_Subscription_Disable_Get", sizeof(sCurrentUnitTest));

	memset(&Subscription, 0, sizeof(Subscription));
	uintOut = BrbUaRcGetSubscription(&RunClient, SUBVAR_IDX_OK, &Subscription, 0);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_Subscription_Disable(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_Subscription_Disable", sizeof(sCurrentUnitTest));

	Subscription.bPublishingEnable = 0;
	
	fbBrbUaRcSetSubscription.pRunClient = &RunClient;
	fbBrbUaRcSetSubscription.nSubscriptionIndex = SUBVAR_IDX_OK;
	fbBrbUaRcSetSubscription.pSubscription = &Subscription;
	BrbUaRcSetSubscription(&fbBrbUaRcSetSubscription);
	TEST_BUSY_CONDITION(fbBrbUaRcSetSubscription.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRcSetSubscription.nStatus);
	
	memset(&Subscription, 0, sizeof(Subscription));
	uintOut = BrbUaRcGetSubscription(&RunClient, SUBVAR_IDX_OK, &Subscription, 0);
	BRB_ASSERT_EQUAL_BOOL(0, Subscription.bPublishingEnable);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_Receive_Disabled_Store(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_Receive_Disabled_Store", sizeof(sCurrentUnitTest));

	// Werte speichern
	memcpy(&SubscriptionVarDataStored, &Data.SubscriptionVar, sizeof(SubscriptionVarDataStored));
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_Receive_Disabled_Wait(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_Receive_Disabled_Wait", sizeof(sCurrentUnitTest));

	// Zeit abwarten
	fbTonWait.IN = 1;
	fbTonWait.PT = 2000;
	TON(&fbTonWait);
	TEST_BUSY_CONDITION(fbTonWait.Q == 0)
	fbTonWait.IN = 0;
	TON(&fbTonWait);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_Receive_Disabled_Check(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_Receive_Disabled_Check", sizeof(sCurrentUnitTest));

	// Werte testen. Achtung: Da der Update stark von Zeiten abh�ngt, die ArSim aber nicht deterministisch ist, kann hier manchmal ein Fehler registiert werden!
	TEST_ASSERT_MESSAGE(SubscriptionVarDataStored.anUint[10] == Data.SubscriptionVar.anUint[10], "SubscriptionVar [10] has changed!");
	TEST_ASSERT_MESSAGE(SubscriptionVarDataStored.anUint[14] == Data.SubscriptionVar.anUint[14], "SubscriptionVar [14] has changed!");
	TEST_ASSERT_MESSAGE(SubscriptionVarDataStored.anUint[19] == Data.SubscriptionVar.anUint[19], "SubscriptionVar [19] has changed!");
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_Subscription_ChangePubInt_Get(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_Subscription_ChangePubInt_Get", sizeof(sCurrentUnitTest));

	memset(&Subscription, 0, sizeof(Subscription));
	uintOut = BrbUaRcGetSubscription(&RunClient, SUBVAR_IDX_OK, &Subscription, 0);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_Subscription_ChangePubInt(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_Subscription_ChangePubInt", sizeof(sCurrentUnitTest));

	Subscription.bPublishingEnable = 1;
	Subscription.tPublishingInterval = 200;
	
	fbBrbUaRcSetSubscription.pRunClient = &RunClient;
	fbBrbUaRcSetSubscription.nSubscriptionIndex = SUBVAR_IDX_OK;
	fbBrbUaRcSetSubscription.pSubscription = &Subscription;
	BrbUaRcSetSubscription(&fbBrbUaRcSetSubscription);
	TEST_BUSY_CONDITION(fbBrbUaRcSetSubscription.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRcSetSubscription.nStatus);
	
	memset(&Subscription, 0, sizeof(Subscription));
	uintOut = BrbUaRcGetSubscription(&RunClient, SUBVAR_IDX_OK, &Subscription, 0);
	BRB_ASSERT_EQUAL_BOOL(1, Subscription.bPublishingEnable);
	BRB_ASSERT_EQUAL_DINT(200, Subscription.tPublishingInterval);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_Receive_ChangePubInt_Store(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_Receive_ChangePubInt_Store", sizeof(sCurrentUnitTest));

	// Werte speichern
	memcpy(&SubscriptionVarDataStored, &Data.SubscriptionVar, sizeof(SubscriptionVarDataStored));
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_Receive_ChangePubInt_Wait(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_Receive_ChangePubInt_Wait", sizeof(sCurrentUnitTest));

	// Zeit abwarten
	fbTonWait.IN = 1;
	fbTonWait.PT = 800;
	TON(&fbTonWait);
	TEST_BUSY_CONDITION(fbTonWait.Q == 0)
	fbTonWait.IN = 0;
	TON(&fbTonWait);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_Receive_ChangePubInt_Check(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_Receive_ChangePubInt_Check", sizeof(sCurrentUnitTest));

	// Werte testen. Achtung: Da der Update stark von Zeiten abh�ngt, die ArSim aber nicht deterministisch ist, kann hier manchmal ein Fehler registiert werden!
	TEST_ASSERT_MESSAGE(SubscriptionVarDataStored.anUint[10] != Data.SubscriptionVar.anUint[10], "SubscriptionVar [10] was not updated!");
	TEST_ASSERT_MESSAGE(SubscriptionVarDataStored.anUint[14] != Data.SubscriptionVar.anUint[14], "SubscriptionVar [14] was not updated!");
	TEST_ASSERT_MESSAGE(SubscriptionVarDataStored.anUint[19] != Data.SubscriptionVar.anUint[19], "SubscriptionVar [19] was not updated!");
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_SetMonitoredItem_NulPtr0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_SetMonitoredItem_NulPtr0", sizeof(sCurrentUnitTest));

	fbBrbUaRcSetMonitoredItem.pRunClient = 0;
	fbBrbUaRcSetMonitoredItem.nSubscriptionIndex = SUBVAR_IDX_OK;
	fbBrbUaRcSetMonitoredItem.nMonitoredItemIndex = 0;
	fbBrbUaRcSetMonitoredItem.pMonitoringSettings = &MonitoredItemSettings;
	BrbUaRcSetMonitoredItem(&fbBrbUaRcSetMonitoredItem);
	TEST_BUSY_CONDITION(fbBrbUaRcSetMonitoredItem.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, fbBrbUaRcSetMonitoredItem.nStatus);
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_SetMonitoredItem_NulPtr1(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_SetMonitoredItem_NulPtr1", sizeof(sCurrentUnitTest));

	fbBrbUaRcSetMonitoredItem.pRunClient = &RunClient;
	fbBrbUaRcSetMonitoredItem.nSubscriptionIndex = SUBVAR_IDX_OK;
	fbBrbUaRcSetMonitoredItem.nMonitoredItemIndex = 0;
	fbBrbUaRcSetMonitoredItem.pMonitoringSettings = 0;
	BrbUaRcSetMonitoredItem(&fbBrbUaRcSetMonitoredItem);
	TEST_BUSY_CONDITION(fbBrbUaRcSetMonitoredItem.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, fbBrbUaRcSetMonitoredItem.nStatus);
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_SetMonitoredItem_InvalidSubscriptionIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_SetMonitoredItem_InvalidSubscriptionIndex", sizeof(sCurrentUnitTest));

	fbBrbUaRcSetMonitoredItem.pRunClient = &RunClient;
	fbBrbUaRcSetMonitoredItem.nSubscriptionIndex = 99;
	fbBrbUaRcSetMonitoredItem.nMonitoredItemIndex = 0;
	fbBrbUaRcSetMonitoredItem.pMonitoringSettings = &MonitoredItemSettings;
	BrbUaRcSetMonitoredItem(&fbBrbUaRcSetMonitoredItem);
	TEST_BUSY_CONDITION(fbBrbUaRcSetMonitoredItem.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, fbBrbUaRcSetMonitoredItem.nStatus);
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_SetMonitoredItem_InvalidMonitoredItemIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_SetMonitoredItem_InvalidMonitoredItemIndex", sizeof(sCurrentUnitTest));

	fbBrbUaRcSetMonitoredItem.pRunClient = &RunClient;
	fbBrbUaRcSetMonitoredItem.nSubscriptionIndex = SUBVAR_IDX_OK;
	fbBrbUaRcSetMonitoredItem.nMonitoredItemIndex = 99;
	fbBrbUaRcSetMonitoredItem.pMonitoringSettings = &MonitoredItemSettings;
	BrbUaRcSetMonitoredItem(&fbBrbUaRcSetMonitoredItem);
	TEST_BUSY_CONDITION(fbBrbUaRcSetMonitoredItem.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, fbBrbUaRcSetMonitoredItem.nStatus);
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_MonitoredItem_ChangeSamplInt_Get(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_MonitoredItem_ChangeSamplInt_Get", sizeof(sCurrentUnitTest));

	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, SUBVAR_IDX_OK, 0, &MonitoredItem);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_MonitoredItem_ChangeSamplInt(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_MonitoredItem_ChangeSamplInt", sizeof(sCurrentUnitTest));

	MonitoredItemSettings.SamplingInterval = 100;
	MonitoredItemSettings.Deadband = MonitoredItem.MonitoringParameter.Deadband;
	MonitoredItemSettings.DeadbandType = MonitoredItem.MonitoringParameter.DeadbandType;
	
	fbBrbUaRcSetMonitoredItem.pRunClient = &RunClient;
	fbBrbUaRcSetMonitoredItem.nSubscriptionIndex = SUBVAR_IDX_OK;
	fbBrbUaRcSetMonitoredItem.nMonitoredItemIndex = 0;
	fbBrbUaRcSetMonitoredItem.pMonitoringSettings = &MonitoredItemSettings;
	BrbUaRcSetMonitoredItem(&fbBrbUaRcSetMonitoredItem);
	TEST_BUSY_CONDITION(fbBrbUaRcSetMonitoredItem.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRcSetMonitoredItem.nStatus);
	
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, SUBVAR_IDX_OK, 0, &MonitoredItem);
	BRB_ASSERT_EQUAL_DINT(100, MonitoredItem.MonitoringParameter.SamplingInterval);

	// Finished
	TEST_DONE;
}

// Test des Empfangs -------------------------------------------------------------------------------------------------------------------

_TEST SubscriptionVar_Receive_MonitoredItem_ChangeSamplInt_Store(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_Receive_MonitoredItem_ChangeSamplInt_Store", sizeof(sCurrentUnitTest));

	// Werte speichern
	memcpy(&SubscriptionVarDataStored, &Data.SubscriptionVar, sizeof(SubscriptionVarDataStored));
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_Receive_MonitoredItem_ChangeSamplInt_Wait(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_Receive_MonitoredItem_ChangeSamplInt_Wait", sizeof(sCurrentUnitTest));

	// Zeit abwarten
	fbTonWait.IN = 1;
	fbTonWait.PT = 800;
	TON(&fbTonWait);
	TEST_BUSY_CONDITION(fbTonWait.Q == 0)
	fbTonWait.IN = 0;
	TON(&fbTonWait);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionVar_Receive_MonitoredItem_ChangeSamplInt_Check(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionVar.SubscriptionVar_Receive_MonitoredItem_ChangeSamplInt_Check", sizeof(sCurrentUnitTest));

	// Werte testen. Achtung: Da der Update stark von Zeiten abh�ngt, die ArSim aber nicht deterministisch ist, kann hier manchmal ein Fehler registiert werden!
	TEST_ASSERT_MESSAGE(SubscriptionVarDataStored.anUint[10] != Data.SubscriptionVar.anUint[10], "SubscriptionVar [10] was not updated!");

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-03-18 15:20:24Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("SubscriptionVar_GetSubscription_NulPtr", SubscriptionVar_GetSubscription_NulPtr), 
	new_TestFixture("SubscriptionVar_GetSubscription_InvalidSubscriptionIndex", SubscriptionVar_GetSubscription_InvalidSubscriptionIndex), 
	new_TestFixture("SubscriptionVar_GetSubscription_InvalidPrio", SubscriptionVar_GetSubscription_InvalidPrio), 
	new_TestFixture("SubscriptionVar_GetSubscription_InvalidPubInt", SubscriptionVar_GetSubscription_InvalidPubInt), 
	new_TestFixture("SubscriptionVar_GetSubscription_Ok", SubscriptionVar_GetSubscription_Ok), 
	new_TestFixture("SubscriptionVar_GetMonitoredItem_NulPtr", SubscriptionVar_GetMonitoredItem_NulPtr), 
	new_TestFixture("SubscriptionVar_GetMonitoredItem_InvalidSubscriptionIndex", SubscriptionVar_GetMonitoredItem_InvalidSubscriptionIndex), 
	new_TestFixture("SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemIndex", SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemIndex), 
	new_TestFixture("SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemNs", SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemNs), 
	new_TestFixture("SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemNode", SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemNode), 
	new_TestFixture("SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemVar", SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemVar), 
	new_TestFixture("SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemAttributeId", SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemAttributeId), 
	new_TestFixture("SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemSamplingInterval", SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemSamplingInterval), 
	new_TestFixture("SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemDeadbandType", SubscriptionVar_GetMonitoredItem_InvalidMonitoredItemDeadbandType), 
	new_TestFixture("SubscriptionVar_GetMonitoredItem_Ok", SubscriptionVar_GetMonitoredItem_Ok), 
	new_TestFixture("SubscriptionVar_GetMiValueChanged_NulPtr", SubscriptionVar_GetMiValueChanged_NulPtr), 
	new_TestFixture("SubscriptionVar_GetMiValueChanged_InvalidSubscriptionIndex", SubscriptionVar_GetMiValueChanged_InvalidSubscriptionIndex), 
	new_TestFixture("SubscriptionVar_GetMiValueChanged_InvalidMonitoredItemIndex", SubscriptionVar_GetMiValueChanged_InvalidMonitoredItemIndex), 
	new_TestFixture("SubscriptionVar_GetMiRemainingValueCount_NulPtr", SubscriptionVar_GetMiRemainingValueCount_NulPtr), 
	new_TestFixture("SubscriptionVar_GetMiRemainingValueCount_InvalidSubscriptionIndex", SubscriptionVar_GetMiRemainingValueCount_InvalidSubscriptionIndex), 
	new_TestFixture("SubscriptionVar_GetMiRemainingValueCount_InvalidMonitoredItemIndex", SubscriptionVar_GetMiRemainingValueCount_InvalidMonitoredItemIndex), 
	new_TestFixture("SubscriptionVar_Receive_Enabled_Store", SubscriptionVar_Receive_Enabled_Store), 
	new_TestFixture("SubscriptionVar_Receive_Enabled_Wait", SubscriptionVar_Receive_Enabled_Wait), 
	new_TestFixture("SubscriptionVar_Receive_Enabled_Check", SubscriptionVar_Receive_Enabled_Check), 
	new_TestFixture("SubscriptionVar_SetSubscription_NulPtr0", SubscriptionVar_SetSubscription_NulPtr0), 
	new_TestFixture("SubscriptionVar_SetSubscription_NulPtr1", SubscriptionVar_SetSubscription_NulPtr1), 
	new_TestFixture("SubscriptionVar_SetSubscription_InvalidSubscriptionIndex", SubscriptionVar_SetSubscription_InvalidSubscriptionIndex), 
	new_TestFixture("SubscriptionVar_Subscription_Disable_Get", SubscriptionVar_Subscription_Disable_Get), 
	new_TestFixture("SubscriptionVar_Subscription_Disable", SubscriptionVar_Subscription_Disable), 
	new_TestFixture("SubscriptionVar_Receive_Disabled_Store", SubscriptionVar_Receive_Disabled_Store), 
	new_TestFixture("SubscriptionVar_Receive_Disabled_Wait", SubscriptionVar_Receive_Disabled_Wait), 
	new_TestFixture("SubscriptionVar_Receive_Disabled_Check", SubscriptionVar_Receive_Disabled_Check), 
	new_TestFixture("SubscriptionVar_Subscription_ChangePubInt_Get", SubscriptionVar_Subscription_ChangePubInt_Get), 
	new_TestFixture("SubscriptionVar_Subscription_ChangePubInt", SubscriptionVar_Subscription_ChangePubInt), 
	new_TestFixture("SubscriptionVar_Receive_ChangePubInt_Store", SubscriptionVar_Receive_ChangePubInt_Store), 
	new_TestFixture("SubscriptionVar_Receive_ChangePubInt_Wait", SubscriptionVar_Receive_ChangePubInt_Wait), 
	new_TestFixture("SubscriptionVar_Receive_ChangePubInt_Check", SubscriptionVar_Receive_ChangePubInt_Check), 
	new_TestFixture("SubscriptionVar_SetMonitoredItem_NulPtr0", SubscriptionVar_SetMonitoredItem_NulPtr0), 
	new_TestFixture("SubscriptionVar_SetMonitoredItem_NulPtr1", SubscriptionVar_SetMonitoredItem_NulPtr1), 
	new_TestFixture("SubscriptionVar_SetMonitoredItem_InvalidSubscriptionIndex", SubscriptionVar_SetMonitoredItem_InvalidSubscriptionIndex), 
	new_TestFixture("SubscriptionVar_SetMonitoredItem_InvalidMonitoredItemIndex", SubscriptionVar_SetMonitoredItem_InvalidMonitoredItemIndex), 
	new_TestFixture("SubscriptionVar_MonitoredItem_ChangeSamplInt_Get", SubscriptionVar_MonitoredItem_ChangeSamplInt_Get), 
	new_TestFixture("SubscriptionVar_MonitoredItem_ChangeSamplInt", SubscriptionVar_MonitoredItem_ChangeSamplInt), 
	new_TestFixture("SubscriptionVar_Receive_MonitoredItem_ChangeSamplInt_Store", SubscriptionVar_Receive_MonitoredItem_ChangeSamplInt_Store), 
	new_TestFixture("SubscriptionVar_Receive_MonitoredItem_ChangeSamplInt_Wait", SubscriptionVar_Receive_MonitoredItem_ChangeSamplInt_Wait), 
	new_TestFixture("SubscriptionVar_Receive_MonitoredItem_ChangeSamplInt_Check", SubscriptionVar_Receive_MonitoredItem_ChangeSamplInt_Check), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaRcSubscriptionVar, "Set_BrbUaRcSubscriptionVar", 0, 0, fixtures, setupSet, 0, cyclicSetCaller);

