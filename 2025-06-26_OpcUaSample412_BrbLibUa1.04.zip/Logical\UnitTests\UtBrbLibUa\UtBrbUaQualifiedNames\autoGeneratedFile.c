/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (List of TestSets).
LastUpdated: 2023-04-25 07:27:30Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
#include "UnitTest.h"



UNITTEST_TESTSET_DECLARATION  Set_BrbUaSetQualifiedName;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaGetRandomQualifiedName;



UNITTEST_TESTSET_FIXTURES(utTestSets)
{
	new_TestSet(Set_BrbUaSetQualifiedName),
	new_TestSet(Set_BrbUaGetRandomQualifiedName),
};
UNTITTEST_TESTSET_HANDLER();

