#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_SETUP_SET(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcReadBlocks._SETUP_SET", sizeof(sCurrentUnitTest));

	memset(&fbBrbUaRcReadBlock, 0, sizeof(fbBrbUaRcReadBlock));

	// Finished
	TEST_DONE;
}

_CYCLIC_SET(void)
{
	if(RunClient.State.eState >= eBRB_RCSTATE_INIT_DONE && RunClient.State.eState < eBRB_RCSTATE_EXITING)
	{
		if(bRunCyclic == 1)
		{
			fbBrbUaRunClientCyclic.pRunClient = &RunClient;
			BrbUaRunClientCyclic(&fbBrbUaRunClientCyclic);
		}
	}
	BrbUaRcMonitor(&RunClient, &CyclicMonitor);
	return;
}

_TEST BrbUaRcReadBlocks_GetReadBlock_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcReadBlocks.BrbUaRcReadBlocks_GetReadBlock_NulPtr", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRcGetReadBlock(0, 0, &ReadBlock, &ReadBlockIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);
	
	uintOut = BrbUaRcGetReadBlock(&RunClient, 0, 0, &ReadBlockIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcReadBlocks_GetReadBlock_InvalidReadBlockIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcReadBlocks.BrbUaRcReadBlocks_GetReadBlock_InvalidReadBlockIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&ReadBlock, 0, sizeof(ReadBlock));
	memset(&ReadBlockIntern, 0, sizeof(ReadBlockIntern));
	uintOut = BrbUaRcGetReadBlock(&RunClient, 99, &ReadBlock, &ReadBlockIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);
	TEST_ASSERT_EQUAL_INT(0, ReadBlock.nReadItemCount);
	TEST_ASSERT_EQUAL_INT(0, ReadBlockIntern.nReadItemCount);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.ReadBlock.nReadBlockIndex = 99;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.ReadBlock.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.ReadBlock.ReadBlock.nReadItemCount);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.ReadBlock.ReadBlockIntern.nReadItemCount);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcReadBlocks_GetReadBlock_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcReadBlocks.BrbUaRcReadBlocks_GetReadBlock_Ok", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&ReadBlock, 0, sizeof(ReadBlock));
	memset(&ReadBlockIntern, 0, sizeof(ReadBlockIntern));
	uintOut = BrbUaRcGetReadBlock(&RunClient, eREADBLOCK_IDX_OK, &ReadBlock, &ReadBlockIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(5, ReadBlock.nReadItemCount);
	TEST_ASSERT_EQUAL_INT(5, ReadBlockIntern.nReadItemCount);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.ReadBlock.nReadBlockIndex = eREADBLOCK_IDX_OK;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.ReadBlock.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(5, RcMonitor.ReadBlock.ReadBlock.nReadItemCount);
	TEST_ASSERT_EQUAL_INT(5, RcMonitor.ReadBlock.ReadBlockIntern.nReadItemCount);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcReadBlocks_GetReadItem_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcReadBlocks.BrbUaRcReadBlocks_GetReadItem_NulPtr", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRcGetReadItem(0, 0, 0, &ReadItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);
	
	uintOut = BrbUaRcGetReadItem(&RunClient, 0, 0, 0);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcReadBlocks_GetReadItem_InvalidReadBlockIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcReadBlocks.BrbUaRcReadBlocks_GetReadItem_InvalidReadBlockIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&ReadBlock, 0, sizeof(ReadBlock));
	memset(&ReadBlockIntern, 0, sizeof(ReadBlockIntern));
	uintOut = BrbUaRcGetReadItem(&RunClient, 99, 0, &ReadItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);
	TEST_ASSERT_EQUAL_INT(0, ReadItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, ReadItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, ReadItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("", ReadItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, ReadItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("", ReadItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, ReadItem.nErrorId); // Good

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.ReadItem.nReadBlockIndex = 99;
	RcMonitor.ReadItem.nReadItemIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.ReadItem.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.ReadItem.ReadItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.ReadItem.ReadItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.ReadItem.ReadItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("", RcMonitor.ReadItem.ReadItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.ReadItem.ReadItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("", RcMonitor.ReadItem.ReadItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.ReadItem.ReadItem.nErrorId); // Good

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcReadBlocks_GetReadItem_InvalidReadItemIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcReadBlocks.BrbUaRcReadBlocks_GetReadItem_InvalidReadItemIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&ReadItem, 0, sizeof(ReadItem));
	uintOut = BrbUaRcGetReadItem(&RunClient, 0, 99, &ReadItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);
	TEST_ASSERT_EQUAL_INT(0, ReadItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, ReadItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, ReadItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("", ReadItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, ReadItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("", ReadItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, ReadItem.nErrorId); // Good

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.ReadItem.nReadBlockIndex = 0;
	RcMonitor.ReadItem.nReadItemIndex = 99;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.ReadItem.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.ReadItem.ReadItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.ReadItem.ReadItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.ReadItem.ReadItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("", RcMonitor.ReadItem.ReadItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.ReadItem.ReadItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("", RcMonitor.ReadItem.ReadItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.ReadItem.ReadItem.nErrorId); // Good

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcReadBlocks_GetReadItem_InvalidNamespaceIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcReadBlocks.BrbUaRcReadBlocks_GetReadItem_InvalidNamespaceIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&ReadItem, 0, sizeof(ReadItem));
	uintOut = BrbUaRcGetReadItem(&RunClient, eREADBLOCK_IDX_INV_NS, 3, &ReadItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(99, ReadItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, ReadItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, ReadItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Read.anUint[3]", ReadItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, ReadItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Read.anUint[3]", ReadItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, ReadItem.nErrorId); // Good (wird erst beim Lesen erkannt)

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.ReadItem.nReadBlockIndex = eREADBLOCK_IDX_INV_NS;
	RcMonitor.ReadItem.nReadItemIndex = 3;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.ReadItem.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(99, RcMonitor.ReadItem.ReadItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.ReadItem.ReadItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.ReadItem.ReadItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Read.anUint[3]", RcMonitor.ReadItem.ReadItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, RcMonitor.ReadItem.ReadItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Read.anUint[3]", RcMonitor.ReadItem.ReadItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.ReadItem.ReadItem.nErrorId); // Good (wird erst beim Lesen erkannt)
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcReadBlocks_GetReadItem_InvalidIdentifier(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcReadBlocks.BrbUaRcReadBlocks_GetReadItem_InvalidIdentifier", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&ReadItem, 0, sizeof(ReadItem));
	uintOut = BrbUaRcGetReadItem(&RunClient, eREADBLOCK_IDX_INV_ID, 3, &ReadItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, ReadItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, ReadItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, ReadItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Read.UnknownNode", ReadItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, ReadItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Read.anUint[3]", ReadItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, ReadItem.nErrorId); // Good (wird erst beim Lesen erkannt)

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.ReadItem.nReadBlockIndex = eREADBLOCK_IDX_INV_ID;
	RcMonitor.ReadItem.nReadItemIndex = 3;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.ReadItem.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(3, RcMonitor.ReadItem.ReadItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.ReadItem.ReadItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.ReadItem.ReadItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Read.UnknownNode", RcMonitor.ReadItem.ReadItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, RcMonitor.ReadItem.ReadItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Read.anUint[3]", RcMonitor.ReadItem.ReadItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.ReadItem.ReadItem.nErrorId); // Good (wird erst beim Lesen erkannt)
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcReadBlocks_GetReadItem_InvalidVarName(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcReadBlocks.BrbUaRcReadBlocks_GetReadItem_InvalidVarName", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&ReadItem, 0, sizeof(ReadItem));
	uintOut = BrbUaRcGetReadItem(&RunClient, eREADBLOCK_IDX_INV_VAR, 3, &ReadItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, ReadItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, ReadItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, ReadItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Read.anUint[3]", ReadItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, ReadItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Read.UnknownVar", ReadItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, ReadItem.nErrorId); // Good (wird erst beim Lesen erkannt)

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.ReadItem.nReadBlockIndex = eREADBLOCK_IDX_INV_VAR;
	RcMonitor.ReadItem.nReadItemIndex = 3;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.ReadItem.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(3, RcMonitor.ReadItem.ReadItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.ReadItem.ReadItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.ReadItem.ReadItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Read.anUint[3]", RcMonitor.ReadItem.ReadItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, RcMonitor.ReadItem.ReadItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Read.UnknownVar", RcMonitor.ReadItem.ReadItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.ReadItem.ReadItem.nErrorId); // Good (wird erst beim Lesen erkannt)
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcReadBlocks_GetReadItem_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcReadBlocks.BrbUaRcReadBlocks_GetReadItem_Ok", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&ReadItem, 0, sizeof(ReadItem));
	uintOut = BrbUaRcGetReadItem(&RunClient, eREADBLOCK_IDX_OK, 3, &ReadItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, ReadItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, ReadItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, ReadItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Read.anUint[8]", ReadItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, ReadItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Read.anUint[8]", ReadItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, ReadItem.nErrorId); // Good

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.ReadItem.nReadBlockIndex = eREADBLOCK_IDX_OK;
	RcMonitor.ReadItem.nReadItemIndex = 3;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.ReadItem.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(3, RcMonitor.ReadItem.ReadItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.ReadItem.ReadItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.ReadItem.ReadItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Read.anUint[8]", RcMonitor.ReadItem.ReadItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, RcMonitor.ReadItem.ReadItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Read.anUint[8]", RcMonitor.ReadItem.ReadItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.ReadItem.ReadItem.nErrorId); // Good
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcReadBlocks_ReadBlock_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcReadBlocks.BrbUaRcReadBlocks_ReadBlock_NulPtr", sizeof(sCurrentUnitTest));

	fbBrbUaRcReadBlock.pRunClient = 0;
	fbBrbUaRcReadBlock.nReadBlockIndex = 0;
	BrbUaRcReadBlock(&fbBrbUaRcReadBlock);
	TEST_BUSY_CONDITION(fbBrbUaRcReadBlock.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, fbBrbUaRcReadBlock.nStatus);
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcReadBlocks_ReadBlock_InvalidReadBlockIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcReadBlocks.BrbUaRcReadBlocks_ReadBlock_InvalidReadBlockIndex", sizeof(sCurrentUnitTest));

	fbBrbUaRcReadBlock.pRunClient = &RunClient;
	fbBrbUaRcReadBlock.nReadBlockIndex = 99;
	BrbUaRcReadBlock(&fbBrbUaRcReadBlock);
	TEST_BUSY_CONDITION(fbBrbUaRcReadBlock.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, fbBrbUaRcReadBlock.nStatus);
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcReadBlocks_ReadBlock_InvalidNamespaceIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcReadBlocks.BrbUaRcReadBlocks_ReadBlock_InvalidNamespaceIndex", sizeof(sCurrentUnitTest));

	fbBrbUaRcReadBlock.pRunClient = &RunClient;
	fbBrbUaRcReadBlock.nReadBlockIndex = eREADBLOCK_IDX_INV_NS;
	BrbUaRcReadBlock(&fbBrbUaRcReadBlock);
	TEST_BUSY_CONDITION(fbBrbUaRcReadBlock.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_ERROR, fbBrbUaRcReadBlock.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, fbBrbUaRcReadBlock.nErrorId); // Bad_NodeIdUnknown
	TEST_ASSERT_EQUAL_STRING("0x80340000 = Bad_NodeIdUnknown", fbBrbUaRcReadBlock.sErrorId);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcReadBlocks_ReadBlock_InvalidIdentifier(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcReadBlocks.BrbUaRcReadBlocks_ReadBlock_InvalidIdentifier", sizeof(sCurrentUnitTest));

	fbBrbUaRcReadBlock.pRunClient = &RunClient;
	fbBrbUaRcReadBlock.nReadBlockIndex = eREADBLOCK_IDX_INV_ID;
	BrbUaRcReadBlock(&fbBrbUaRcReadBlock);
	TEST_BUSY_CONDITION(fbBrbUaRcReadBlock.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_ERROR, fbBrbUaRcReadBlock.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, fbBrbUaRcReadBlock.nErrorId); // Bad_NodeIdUnknown
	TEST_ASSERT_EQUAL_STRING("0x80340000 = Bad_NodeIdUnknown", fbBrbUaRcReadBlock.sErrorId);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcReadBlocks_ReadBlock_InvalidVarName(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcReadBlocks.BrbUaRcReadBlocks_ReadBlock_InvalidVarName", sizeof(sCurrentUnitTest));

	fbBrbUaRcReadBlock.pRunClient = &RunClient;
	fbBrbUaRcReadBlock.nReadBlockIndex = eREADBLOCK_IDX_INV_VAR;
	BrbUaRcReadBlock(&fbBrbUaRcReadBlock);
	TEST_BUSY_CONDITION(fbBrbUaRcReadBlock.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_ERROR, fbBrbUaRcReadBlock.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0xB0040000, fbBrbUaRcReadBlock.nErrorId); // PlcOpen_BadVariableNameInvalid
	TEST_ASSERT_EQUAL_STRING("0xB0040000 = PlcOpen_BadVariableNameInvalid", fbBrbUaRcReadBlock.sErrorId);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcReadBlocks_ReadBlock_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcReadBlocks.BrbUaRcReadBlocks_ReadBlock_Ok", sizeof(sCurrentUnitTest));

	fbBrbUaRcReadBlock.pRunClient = &RunClient;
	fbBrbUaRcReadBlock.nReadBlockIndex = eREADBLOCK_IDX_OK;
	BrbUaRcReadBlock(&fbBrbUaRcReadBlock);
	TEST_BUSY_CONDITION(fbBrbUaRcReadBlock.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRcReadBlock.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, fbBrbUaRcReadBlock.nErrorId); // Good
	TEST_ASSERT_EQUAL_STRING("0x00000000 = Good", fbBrbUaRcReadBlock.sErrorId);
	TEST_ASSERT_EQUAL_INT(9, Data.Read.anUint[9]);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-03-18 15:15:45Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaRcReadBlocks_GetReadBlock_NulPtr", BrbUaRcReadBlocks_GetReadBlock_NulPtr), 
	new_TestFixture("BrbUaRcReadBlocks_GetReadBlock_InvalidReadBlockIndex", BrbUaRcReadBlocks_GetReadBlock_InvalidReadBlockIndex), 
	new_TestFixture("BrbUaRcReadBlocks_GetReadBlock_Ok", BrbUaRcReadBlocks_GetReadBlock_Ok), 
	new_TestFixture("BrbUaRcReadBlocks_GetReadItem_NulPtr", BrbUaRcReadBlocks_GetReadItem_NulPtr), 
	new_TestFixture("BrbUaRcReadBlocks_GetReadItem_InvalidReadBlockIndex", BrbUaRcReadBlocks_GetReadItem_InvalidReadBlockIndex), 
	new_TestFixture("BrbUaRcReadBlocks_GetReadItem_InvalidReadItemIndex", BrbUaRcReadBlocks_GetReadItem_InvalidReadItemIndex), 
	new_TestFixture("BrbUaRcReadBlocks_GetReadItem_InvalidNamespaceIndex", BrbUaRcReadBlocks_GetReadItem_InvalidNamespaceIndex), 
	new_TestFixture("BrbUaRcReadBlocks_GetReadItem_InvalidIdentifier", BrbUaRcReadBlocks_GetReadItem_InvalidIdentifier), 
	new_TestFixture("BrbUaRcReadBlocks_GetReadItem_InvalidVarName", BrbUaRcReadBlocks_GetReadItem_InvalidVarName), 
	new_TestFixture("BrbUaRcReadBlocks_GetReadItem_Ok", BrbUaRcReadBlocks_GetReadItem_Ok), 
	new_TestFixture("BrbUaRcReadBlocks_ReadBlock_NulPtr", BrbUaRcReadBlocks_ReadBlock_NulPtr), 
	new_TestFixture("BrbUaRcReadBlocks_ReadBlock_InvalidReadBlockIndex", BrbUaRcReadBlocks_ReadBlock_InvalidReadBlockIndex), 
	new_TestFixture("BrbUaRcReadBlocks_ReadBlock_InvalidNamespaceIndex", BrbUaRcReadBlocks_ReadBlock_InvalidNamespaceIndex), 
	new_TestFixture("BrbUaRcReadBlocks_ReadBlock_InvalidIdentifier", BrbUaRcReadBlocks_ReadBlock_InvalidIdentifier), 
	new_TestFixture("BrbUaRcReadBlocks_ReadBlock_InvalidVarName", BrbUaRcReadBlocks_ReadBlock_InvalidVarName), 
	new_TestFixture("BrbUaRcReadBlocks_ReadBlock_Ok", BrbUaRcReadBlocks_ReadBlock_Ok), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaRcReadBlocks, "Set_BrbUaRcReadBlocks", 0, 0, fixtures, setupSet, 0, cyclicSetCaller);

