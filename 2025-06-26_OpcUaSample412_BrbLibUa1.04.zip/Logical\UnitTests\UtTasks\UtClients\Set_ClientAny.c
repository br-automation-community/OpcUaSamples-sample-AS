#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

UDINT ClientAny_GetPointer(STRING* pPvName)
{
	UDINT nPvAdr = 0;
	UDINT nPvLen = 0;
	nPvXGetAdrStatus = PV_xgetadr(pPvName, &nPvAdr, &nPvLen);
	STRING sText[255];
	BrbStringCopy(sText, "Error on getting pointer of ", sizeof(sText));
	BrbStringCat(sText, pPvName, sizeof(sText));
	TEST_ABORT_CONDITION_MSG(nPvXGetAdrStatus != 0, sText)
	TEST_ABORT_CONDITION_MSG(nPvAdr == 0, sText)
	return nPvAdr;
}

_TEST ClientAny_GetLocalPointer(void)
{
	BrbStringCopy(sCurrentUnitTest, "ClientST.ClientAny_GetLocalPointer", sizeof(sCurrentUnitTest));

	pClientAnyReadClientUint	=	(UINT*)	ClientAny_GetPointer("OpcUaAny:Data.Read.Client.nUint");
	pClientAnyWriteServerUint	=	(UINT*)	ClientAny_GetPointer("OpcUaAny:Data.Write.Server.nUint");

	// Finished
	TEST_DONE;
}

_TEST ClientAny_Change_Values_Store(void)
{
	BrbStringCopy(sCurrentUnitTest, "ClientST.ClientAny_Change_Values_Store", sizeof(sCurrentUnitTest));

	memcpy(&nClientAnyReadClientUintStored, pClientAnyReadClientUint, sizeof(nClientAnyReadClientUintStored));
	memcpy(&nClientAnyWriteServerUintStored, pClientAnyWriteServerUint, sizeof(nClientAnyWriteServerUintStored));
	
	// Finished
	TEST_DONE;
}

_TEST ClientAny_Change_Values_Wait(void)
{
	BrbStringCopy(sCurrentUnitTest, "ClientST.ClientAny_Change_Values_Wait", sizeof(sCurrentUnitTest));

	// Zeit abwarten
	fbTonWait.IN = 1;
	fbTonWait.PT = 1000;
	TON(&fbTonWait);
	TEST_BUSY_CONDITION(fbTonWait.Q == 0)
	fbTonWait.IN = 0;
	TON(&fbTonWait);

	// Finished
	TEST_DONE;
}

_TEST ClientAny_Change_Values_Check(void)
{
	BrbStringCopy(sCurrentUnitTest, "ClientST.ClientAny_Change_Values_Check", sizeof(sCurrentUnitTest));

	// Werte testen. Achtung: Da der Update stark von Zeiten abh�ngt, die ArSim aber nicht deterministisch ist, kann hier manchmal ein Fehler registiert werden!
	
	// Read
	TEST_ASSERT_MESSAGE(nClientAnyReadClientUintStored != *pClientAnyReadClientUint, "ClientAny: Read was not updated!");
	
	// Write
	TEST_ASSERT_MESSAGE(nClientAnyWriteServerUintStored != *pClientAnyWriteServerUint, "ClientAny: Write was not updated!");
	
	// Finished
	TEST_DONE;
}


// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-03-20 13:10:20Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("ClientAny_GetLocalPointer", ClientAny_GetLocalPointer), 
	new_TestFixture("ClientAny_Change_Values_Store", ClientAny_Change_Values_Store), 
	new_TestFixture("ClientAny_Change_Values_Wait", ClientAny_Change_Values_Wait), 
	new_TestFixture("ClientAny_Change_Values_Check", ClientAny_Change_Values_Check), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_ClientAny, "Set_ClientAny", 0, 0, fixtures, 0, 0, 0);

