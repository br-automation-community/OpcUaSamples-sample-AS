/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (List of TestSets).
LastUpdated: 2024-03-20 13:10:20Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
#include "UnitTest.h"



UNITTEST_TESTSET_DECLARATION  Set_ClientC;
UNITTEST_TESTSET_DECLARATION  Set_ClientST;
UNITTEST_TESTSET_DECLARATION  Set_ClientAny;



UNITTEST_TESTSET_FIXTURES(utTestSets)
{
	new_TestSet(Set_ClientC),
	new_TestSet(Set_ClientST),
	new_TestSet(Set_ClientAny),
};
UNTITTEST_TESTSET_HANDLER();

