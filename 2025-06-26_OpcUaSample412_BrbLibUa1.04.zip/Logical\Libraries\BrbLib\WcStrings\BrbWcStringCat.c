#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLib.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/* Sicheres Anh�ngen an einen WcString */
unsigned long BrbWcStringCat(plcwstring* pDest, plcwstring* pSrc, unsigned long nDestSize)
{
	UDINT nTotalLen = 0;
	if(pDest != 0 && pSrc != 0 && nDestSize > 0)
	{
		// Quellstring anh�ngen
		UDINT nDestLen = brwcslen(pDest);
		UDINT nSrcLen = brwcslen(pSrc);
		if(nDestLen*2 < nDestSize-2)
		{
			nTotalLen = nDestLen + nSrcLen;
			UDINT nSrcLenMax = (nDestSize-2)/2-nDestLen;
			if(nSrcLen > nSrcLenMax)
			{
				nSrcLen = nSrcLenMax;
			}
			UDINT nCopySize = nSrcLen * 2;
			memcpy(pDest+nDestLen, pSrc, nCopySize);
			// Zielstring mit 0 auff�llen (gleichzeitig wird auf jeden Fall der Null-Terminator gesetzt)
			memset((USINT*)(pDest+nDestLen+nSrcLen), 0, nDestSize-nDestLen*2-nCopySize);
		}
	}
	return nTotalLen;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)
