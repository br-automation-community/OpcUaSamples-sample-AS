#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_SETUP_SET(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsGeneral._SETUP_SET", sizeof(sCurrentUnitTest));

	CyclicMonitor.bEnable = 1;

	// Finished
	TEST_DONE;
}

_TEST BrbUaRsGeneral_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsGeneral.BrbUaRsGeneral_NulPtr", sizeof(sCurrentUnitTest));

	// Init
	memset(&RunServer, 0, sizeof(RunServer));
	brsstrcpy((UDINT)&RunServer.Cfg.sCfgDataObjName, (UDINT)&"UtRsNs");
	memset(&fbBrbUaRunServerInit, 0, sizeof(fbBrbUaRunServerInit));
	do
	{
		fbBrbUaRunServerInit.pRunServer = 0;
		BrbUaRunServerInit(&fbBrbUaRunServerInit);
	} while(fbBrbUaRunServerInit.nStatus == eBRB_ERR_BUSY);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, fbBrbUaRunServerInit.nStatus);

	// Cyclic
	memset(&fbBrbUaRunServerCyclic, 0, sizeof(fbBrbUaRunServerCyclic));
	do
	{
		fbBrbUaRunServerCyclic.pRunServer = 0;
		BrbUaRunServerCyclic(&fbBrbUaRunServerCyclic);
	} while(fbBrbUaRunServerCyclic.nStatus == eBRB_ERR_OK);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, fbBrbUaRunServerCyclic.nStatus);

	// Exit
	memset(&fbBrbUaRunServerExit, 0, sizeof(fbBrbUaRunServerExit));
	do
	{
		fbBrbUaRunServerExit.pRunServer = 0;
		BrbUaRunServerExit(&fbBrbUaRunServerExit);
	} while(fbBrbUaRunServerExit.nStatus == eBRB_ERR_BUSY);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, fbBrbUaRunServerExit.nStatus);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRsGeneral_InvalidDataObjectName(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsGeneral.BrbUaRsGeneral_InvalidDataObjectName", sizeof(sCurrentUnitTest));

	// Init
	memset(&RunServer, 0, sizeof(RunServer));
	brsstrcpy((UDINT)&RunServer.Cfg.sCfgDataObjName, (UDINT)&"UtInvalid");
	memset(&fbBrbUaRunServerInit, 0, sizeof(fbBrbUaRunServerInit));
	do
	{
		fbBrbUaRunServerInit.pRunServer = &RunServer;
		BrbUaRunServerInit(&fbBrbUaRunServerInit);
	} while(fbBrbUaRunServerInit.nStatus == eBRB_ERR_BUSY);
	TEST_ASSERT_EQUAL_INT(doERR_MODULNOTFOUND, fbBrbUaRunServerInit.nStatus);
	TEST_ASSERT_EQUAL_INT(doERR_MODULNOTFOUND, RunServer.State.nErroId);
	TEST_ASSERT_EQUAL_STRING("Init error on getting data object info", RunServer.State.sErrorText);

	// Exit
	memset(&fbBrbUaRunServerExit, 0, sizeof(fbBrbUaRunServerExit));
	do
	{
		fbBrbUaRunServerExit.pRunServer = 0;
		BrbUaRunServerExit(&fbBrbUaRunServerExit);
	} while(fbBrbUaRunServerExit.nStatus == eBRB_ERR_BUSY);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRsGeneral_InitNotDone(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsGeneral.BrbUaRsGeneral_InitNotDone", sizeof(sCurrentUnitTest));

	memset(&RunServer, 0, sizeof(RunServer));
	// Cyclic
	memset(&fbBrbUaRunServerCyclic, 0, sizeof(fbBrbUaRunServerCyclic));
	do
	{
		fbBrbUaRunServerCyclic.pRunServer = &RunServer;
		BrbUaRunServerCyclic(&fbBrbUaRunServerCyclic);
	} while(fbBrbUaRunServerCyclic.nStatus == eBRB_ERR_OK);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_INVALID_PARAMETER, fbBrbUaRunServerCyclic.nStatus);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-03-15 11:42:36Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaRsGeneral_NulPtr", BrbUaRsGeneral_NulPtr), 
	new_TestFixture("BrbUaRsGeneral_InvalidDataObjectName", BrbUaRsGeneral_InvalidDataObjectName), 
	new_TestFixture("BrbUaRsGeneral_InitNotDone", BrbUaRsGeneral_InitNotDone), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaRsGeneral, "Set_BrbUaRsGeneral", 0, 0, fixtures, setupSet, 0, 0);

