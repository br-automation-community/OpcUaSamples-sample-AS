/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (List of TestSets).
LastUpdated: 2023-04-25 07:20:13Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
#include "UnitTest.h"



UNITTEST_TESTSET_DECLARATION  Set_BrbUaSetLocalizedText;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaGetRandomLocalizedText;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaAddLocalizedTextText;



UNITTEST_TESTSET_FIXTURES(utTestSets)
{
	new_TestSet(Set_BrbUaSetLocalizedText),
	new_TestSet(Set_BrbUaGetRandomLocalizedText),
	new_TestSet(Set_BrbUaAddLocalizedTextText),
};
UNTITTEST_TESTSET_HANDLER();

