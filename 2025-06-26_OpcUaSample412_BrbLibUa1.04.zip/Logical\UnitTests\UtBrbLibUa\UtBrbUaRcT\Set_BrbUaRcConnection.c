#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_SETUP_SET(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcConnection._SETUP_SET", sizeof(sCurrentUnitTest));

	bRunCyclic = 0;
	memset(&RunClient, 0, sizeof(RunClient));
	memset(&fbBrbUaRunClientInit, 0, sizeof(fbBrbUaRunClientInit));
	memset(&fbBrbUaRunClientCyclic, 0, sizeof(fbBrbUaRunClientCyclic));
	memset(&fbBrbUaRunClientExit, 0, sizeof(fbBrbUaRunClientExit));

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcConnection_Init(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcConnection.BrbUaRcConnection_Init", sizeof(sCurrentUnitTest));

	brsstrcpy((UDINT)&RunClient.Cfg.sCfgDataObjName, (UDINT)&"UtRc");
	fbBrbUaRunClientInit.pRunClient = &RunClient;
	BrbUaRunClientInit(&fbBrbUaRunClientInit);
	TEST_BUSY_CONDITION(fbBrbUaRunClientInit.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRunClientInit.nStatus);
	
	// Finished
	TEST_DONE;
}

_CYCLIC_SET(void)
{
	if(RunClient.State.eState >= eBRB_RCSTATE_INIT_DONE && RunClient.State.eState < eBRB_RCSTATE_EXITING)
	{
		if(bRunCyclic == 1)
		{
			fbBrbUaRunClientCyclic.pRunClient = &RunClient;
			BrbUaRunClientCyclic(&fbBrbUaRunClientCyclic);
		}
	}
	BrbUaRcMonitor(&RunClient, &CyclicMonitor);
	return;
}

_TEST BrbUaRcConnection_Connect_InvalidIp(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcConnection.BrbUaRcConnection_Connect_InvalidIp", sizeof(sCurrentUnitTest));

	bRunCyclic = 1;
	BrbStringCopy(RunClient.Cfg.sServerEndpointUrl, "opc.tcp://127.0.0.123:4840", sizeof(RunClient.Cfg.sServerEndpointUrl));
	RunClient.eCmd = eBRB_RCCLTCMD_CONNECT;
	TEST_ABORT_CONDITION_MSG(fbBrbUaRunClientCyclic.nStatus != eBRB_ERR_OK, "RunClient not connecting!")
	TEST_BUSY_CONDITION(RunClient.State.eState <= eBRB_RCSTATE_CONNECTING)
	TEST_ASSERT_EQUAL_INT(eBRB_RCSTATE_CONNECT_ERROR, RunClient.State.eState);
	BRB_ASSERT_EQUAL_UDINT(0x80050000, RunClient.State.nErrorId); // Bad_CommunicationError
	TEST_ASSERT_EQUAL_STRING("Error on connecting: 0x80050000 = Bad_CommunicationError", RunClient.State.sErrorText);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcConnection_Connect_InvalidPort(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcConnection.BrbUaRcConnection_Connect_InvalidPort", sizeof(sCurrentUnitTest));

	bRunCyclic = 1;
	BrbStringCopy(RunClient.Cfg.sServerEndpointUrl, "opc.tcp://127.0.0.1:4848", sizeof(RunClient.Cfg.sServerEndpointUrl));
	RunClient.eCmd = eBRB_RCCLTCMD_CONNECT;
	TEST_ABORT_CONDITION_MSG(fbBrbUaRunClientCyclic.nStatus != eBRB_ERR_OK, "RunClient not connecting!")
	TEST_BUSY_CONDITION(RunClient.State.eState <= eBRB_RCSTATE_CONNECTING)
	TEST_ASSERT_EQUAL_INT(eBRB_RCSTATE_CONNECT_ERROR, RunClient.State.eState);
	BRB_ASSERT_EQUAL_UDINT(0x80050000, RunClient.State.nErrorId); // Bad_CommunicationError
	TEST_ASSERT_EQUAL_STRING("Error on connecting: 0x80050000 = Bad_CommunicationError", RunClient.State.sErrorText);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcConnection_Connect_InvalidUsername(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcConnection.BrbUaRcConnection_Connect_InvalidUsername", sizeof(sCurrentUnitTest));

	bRunCyclic = 1;
	BrbStringCopy(RunClient.Cfg.sServerEndpointUrl, "opc.tcp://127.0.0.1:4840", sizeof(RunClient.Cfg.sServerEndpointUrl));
	BrbStringCopy(RunClient.Cfg.SessionConnectInfo.UserIdentityToken.TokenParam1, "UnknownUser", sizeof(RunClient.Cfg.SessionConnectInfo.UserIdentityToken.TokenParam1));
	RunClient.eCmd = eBRB_RCCLTCMD_CONNECT;
	TEST_ABORT_CONDITION_MSG(fbBrbUaRunClientCyclic.nStatus != eBRB_ERR_OK, "RunClient not connecting!")
	TEST_BUSY_CONDITION(RunClient.State.eState <= eBRB_RCSTATE_CONNECTING)
	TEST_ASSERT_EQUAL_INT(eBRB_RCSTATE_CONNECT_ERROR, RunClient.State.eState);
	BRB_ASSERT_EQUAL_UDINT(0x801F0000, RunClient.State.nErrorId); // Bad_UserAccessDenied
	TEST_ASSERT_EQUAL_STRING("Error on connecting: 0x801F0000 = Bad_UserAccessDenied", RunClient.State.sErrorText);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcConnection_Connect_InvalidPassword(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcConnection.BrbUaRcConnection_Connect_InvalidPassword", sizeof(sCurrentUnitTest));

	bRunCyclic = 1;
	BrbStringCopy(RunClient.Cfg.sServerEndpointUrl, "opc.tcp://127.0.0.1:4840", sizeof(RunClient.Cfg.sServerEndpointUrl));
	BrbStringCopy(RunClient.Cfg.SessionConnectInfo.UserIdentityToken.TokenParam1, "Admin", sizeof(RunClient.Cfg.SessionConnectInfo.UserIdentityToken.TokenParam1));
	BrbStringCopy(RunClient.Cfg.SessionConnectInfo.UserIdentityToken.TokenParam2, "Invalid", sizeof(RunClient.Cfg.SessionConnectInfo.UserIdentityToken.TokenParam2));
	RunClient.eCmd = eBRB_RCCLTCMD_CONNECT;
	TEST_ABORT_CONDITION_MSG(fbBrbUaRunClientCyclic.nStatus != eBRB_ERR_OK, "RunClient not connecting!")
	TEST_BUSY_CONDITION(RunClient.State.eState <= eBRB_RCSTATE_CONNECTING)
	TEST_ASSERT_EQUAL_INT(eBRB_RCSTATE_CONNECT_ERROR, RunClient.State.eState);
	BRB_ASSERT_EQUAL_UDINT(0x801F0000, RunClient.State.nErrorId); // Bad_UserAccessDenied
	TEST_ASSERT_EQUAL_STRING("Error on connecting: 0x801F0000 = Bad_UserAccessDenied", RunClient.State.sErrorText);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcConnection_Connect_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcConnection.BrbUaRcConnection_Connect_Ok", sizeof(sCurrentUnitTest));

	bRunCyclic = 1;
	BrbStringCopy(RunClient.Cfg.sServerEndpointUrl, "opc.tcp://127.0.0.1:4840", sizeof(RunClient.Cfg.sServerEndpointUrl));
	BrbStringCopy(RunClient.Cfg.SessionConnectInfo.UserIdentityToken.TokenParam1, "Admin", sizeof(RunClient.Cfg.SessionConnectInfo.UserIdentityToken.TokenParam1));
	BrbStringCopy(RunClient.Cfg.SessionConnectInfo.UserIdentityToken.TokenParam2, "admin", sizeof(RunClient.Cfg.SessionConnectInfo.UserIdentityToken.TokenParam2));
	RunClient.eCmd = eBRB_RCCLTCMD_CONNECT;
	TEST_ABORT_CONDITION_MSG(fbBrbUaRunClientCyclic.nStatus != eBRB_ERR_OK, "RunClient not connecting!")
	TEST_BUSY_CONDITION(RunClient.State.eState != eBRB_RCSTATE_CONNECTED)

	// Finished
	TEST_DONE;
}

_TEARDOWN_SET(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcConnection._TEARDOWN_SET", sizeof(sCurrentUnitTest));

	bRunCyclic = 0;
	// Exit
	fbBrbUaRunClientExit.pRunClient = &RunClient;
	BrbUaRunClientExit(&fbBrbUaRunClientExit);
	TEST_BUSY_CONDITION(fbBrbUaRunClientExit.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRunClientExit.nStatus);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-03-15 08:04:22Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaRcConnection_Init", BrbUaRcConnection_Init), 
	new_TestFixture("BrbUaRcConnection_Connect_InvalidIp", BrbUaRcConnection_Connect_InvalidIp), 
	new_TestFixture("BrbUaRcConnection_Connect_InvalidPort", BrbUaRcConnection_Connect_InvalidPort), 
	new_TestFixture("BrbUaRcConnection_Connect_InvalidUsername", BrbUaRcConnection_Connect_InvalidUsername), 
	new_TestFixture("BrbUaRcConnection_Connect_InvalidPassword", BrbUaRcConnection_Connect_InvalidPassword), 
	new_TestFixture("BrbUaRcConnection_Connect_Ok", BrbUaRcConnection_Connect_Ok), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaRcConnection, "Set_BrbUaRcConnection", 0, 0, fixtures, setupSet, teardownSet, cyclicSetCaller);

