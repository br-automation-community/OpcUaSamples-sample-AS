#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_SETUP_SET(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsEvents._SETUP_SET", sizeof(sCurrentUnitTest));

	bRunCyclic = 0;
	memset(&RunServer, 0, sizeof(RunServer));
	memset(&fbBrbUaRunServerInit, 0, sizeof(fbBrbUaRunServerInit));
	memset(&fbBrbUaRunServerCyclic, 0, sizeof(fbBrbUaRunServerCyclic));
	memset(&fbBrbUaRunServerExit, 0, sizeof(fbBrbUaRunServerExit));
	memset(&fbBrbUaRsFireEvent, 0, sizeof(fbBrbUaRsFireEvent));

	memset(&SrvTransitionEventData, 0, sizeof(SrvTransitionEventData));
	BrbUaSetLocalizedText(&SrvTransitionEventData.Message, "en", "UtRsMessage");
	SrvTransitionEventData.nSeverity = 500;
	BrbStringCopy(SrvTransitionEventData.sSourceName, "UtRsSourceName", sizeof(SrvTransitionEventData.sSourceName));
	BrbUaSetLocalizedText(&SrvTransitionEventData.FromState, "en", "UtRsFromState");
	SrvTransitionEventData.nFromStateId =  1;
	BrbUaSetLocalizedText(&SrvTransitionEventData.ToState, "en", "UtRsToState");
	SrvTransitionEventData.nToStateId =  2;
	BrbUaSetLocalizedText(&SrvTransitionEventData.Transition, "en", "UtRsTransition");
	SrvTransitionEventData.nTransitionId =  3;
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRsEvents_Init(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsEvents.BrbUaRsEvents_Init", sizeof(sCurrentUnitTest));

	brsstrcpy((UDINT)&RunServer.Cfg.sCfgDataObjName, (UDINT)&"UtRs");
	fbBrbUaRunServerInit.pRunServer = &RunServer;
	BrbUaRunServerInit(&fbBrbUaRunServerInit);
	TEST_BUSY_CONDITION(fbBrbUaRunServerInit.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRunServerInit.nStatus);

	// Finished
	TEST_DONE;
}

_CYCLIC_SET(void)
{
	if(RunServer.State.eState >= eBRB_RSSTATE_INIT_DONE && RunServer.State.eState < eBRB_RSSTATE_EXITING)
	{
		if(bRunCyclic == 1)
		{
			fbBrbUaRunServerCyclic.pRunServer = &RunServer;
			BrbUaRunServerCyclic(&fbBrbUaRunServerCyclic);
		}
	}
	BrbUaRsMonitor(&RunServer, &CyclicMonitor);
	return;
}

_TEST BrbUaRsEvents_GetEvent_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsEvents.BrbUaRsEvents_GetEvent_NulPtr", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRsGetEvent(0, 0, &Event, &EventIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);
	
	uintOut = BrbUaRsGetEvent(&RunServer, 0, 0, &EventIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRsEvents_GetEventField_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsEvents.BrbUaRsEvents_GetEventField_NulPtr", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRsGetEventField(0, 0, 0, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);
	
	uintOut = BrbUaRsGetEventField(&RunServer, 0, 0, 0);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRsEvents_FireEvent_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsEvents.BrbUaRsEvents_FireEvent_NulPtr", sizeof(sCurrentUnitTest));

	fbBrbUaRsFireEvent.pRunServer = 0;
	fbBrbUaRsFireEvent.nEventIndex = 0;
	BrbUaRsFireEvent(&fbBrbUaRsFireEvent);
	TEST_BUSY_CONDITION(fbBrbUaRsFireEvent.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, fbBrbUaRsFireEvent.nStatus);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRsEvents_FireEvent_NotRunning(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsEvents.BrbUaRsEvents_FireEvent_NotRunning", sizeof(sCurrentUnitTest));

	fbBrbUaRsFireEvent.pRunServer = &RunServer;
	fbBrbUaRsFireEvent.nEventIndex = 1;
	BrbUaRsFireEvent(&fbBrbUaRsFireEvent);
	TEST_BUSY_CONDITION(fbBrbUaRsFireEvent.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_NOT_RUNNING, fbBrbUaRsFireEvent.nStatus);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRsEvents_GetEvent_InvalidEventIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsEvents.BrbUaRsEvents_GetEvent_InvalidEventIndex", sizeof(sCurrentUnitTest));

	// Direkt
	uintOut = BrbUaRsGetEvent(&RunServer, 99, &Event, &EventIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);

	// Monitor
	memset(&RsMonitor, 0, sizeof(RsMonitor));
	RsMonitor.bEnable = 1;
	RsMonitor.Event.nEventIndex = 99;
	BrbUaRsMonitor(&RunServer, &RsMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RsMonitor.Event.nMonitorStatus);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRsEvents_GetEvent_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsEvents.BrbUaRsEvents_GetEvent_Ok", sizeof(sCurrentUnitTest));

	// Cyclic
	bRunCyclic = 1;
	TEST_ABORT_CONDITION_MSG(fbBrbUaRunServerCyclic.nStatus != eBRB_ERR_OK, "RunServer not running!")
	TEST_BUSY_CONDITION(RunServer.State.eState != eBRB_RSSTATE_RUNNING)
	
	// Direkt
	uintOut = BrbUaRsGetEvent(&RunServer, 3, &Event, &EventIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, Event.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, Event.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_Numeric, Event.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("2311", Event.TypeNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(9, Event.nFieldCount);
	TEST_ASSERT_EQUAL_INT(0, EventIntern.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventIntern.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_Numeric, EventIntern.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("2311", EventIntern.TypeNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(9, EventIntern.nFieldCount);

	// Monitor
	memset(&RsMonitor, 0, sizeof(RsMonitor));
	RsMonitor.bEnable = 1;
	RsMonitor.Event.nEventIndex = 3;
	BrbUaRsMonitor(&RunServer, &RsMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RsMonitor.Event.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(0, RsMonitor.Event.Event.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, RsMonitor.Event.Event.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_Numeric, RsMonitor.Event.Event.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("2311", RsMonitor.Event.Event.TypeNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(9, RsMonitor.Event.Event.nFieldCount);
	TEST_ASSERT_EQUAL_INT(0, RsMonitor.Event.EventIntern.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, RsMonitor.Event.EventIntern.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_Numeric, RsMonitor.Event.EventIntern.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("2311", RsMonitor.Event.EventIntern.TypeNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(9, RsMonitor.Event.EventIntern.nFieldCount);

	// Finished
	bRunCyclic = 0;
	TEST_DONE;
}

_TEST BrbUaRsEvents_GetEventField_InvalidEventFieldIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsEvents.BrbUaRsEvents_GetEventField_InvalidEventFieldIndex", sizeof(sCurrentUnitTest));

	// Direkt
	uintOut = BrbUaRsGetEventField(&RunServer, 3, 99, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);

	// Monitor
	memset(&RsMonitor, 0, sizeof(RsMonitor));
	RsMonitor.bEnable = 1;
	RsMonitor.EventField.nEventIndex = 3;
	RsMonitor.EventField.nEventFieldIndex = 99;
	BrbUaRsMonitor(&RunServer, &RsMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RsMonitor.EventField.nMonitorStatus);

	// Finished
	bRunCyclic = 0;
	TEST_DONE;
}

_TEST BrbUaRsEvents_GetEventField_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsEvents.BrbUaRsEvents_GetEventField_Ok", sizeof(sCurrentUnitTest));

	// Cyclic
	bRunCyclic = 1;
	TEST_ABORT_CONDITION_MSG(fbBrbUaRunServerCyclic.nStatus != eBRB_ERR_OK, "RunServer not running!")
	TEST_BUSY_CONDITION(RunServer.State.eState != eBRB_RSSTATE_RUNNING)
	
	// Direkt
	uintOut = BrbUaRsGetEventField(&RunServer, 3, 4, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_STRING("/FromState/Id", EventField.BrowsePath);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRsT:SrvTransitionEventData.nFromStateId", EventField.Variable);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventField.ErrorID);	// Good

	// Monitor
	memset(&RsMonitor, 0, sizeof(RsMonitor));
	RsMonitor.bEnable = 1;
	RsMonitor.EventField.nEventIndex = 3;
	RsMonitor.EventField.nEventFieldIndex = 4;
	BrbUaRsMonitor(&RunServer, &RsMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RsMonitor.Event.nMonitorStatus);
	TEST_ASSERT_EQUAL_STRING("/FromState/Id", RsMonitor.EventField.Field.BrowsePath);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRsT:SrvTransitionEventData.nFromStateId", RsMonitor.EventField.Field.Variable);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RsMonitor.EventField.Field.ErrorID);	// Good

	// Finished
	bRunCyclic = 0;
	TEST_DONE;
}

_TEST BrbUaRsEvents_FireEvent_InvalidTypeNodeId(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsEvents.BrbUaRsEvents_FireEvent_InvalidTypeNodeId", sizeof(sCurrentUnitTest));

	// Cyclic
	bRunCyclic = 1;
	TEST_ABORT_CONDITION_MSG(fbBrbUaRunServerCyclic.nStatus != eBRB_ERR_OK, "RunServer not running!")
	TEST_BUSY_CONDITION(RunServer.State.eState != eBRB_RSSTATE_RUNNING)

	// Fire Event
	fbBrbUaRsFireEvent.pRunServer = &RunServer;
	fbBrbUaRsFireEvent.nEventIndex = 0;
	BrbUaRsFireEvent(&fbBrbUaRsFireEvent);
	TEST_BUSY_CONDITION(fbBrbUaRsFireEvent.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_ERROR, fbBrbUaRsFireEvent.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, fbBrbUaRsFireEvent.nErrorId);	// Bad_NodeIdUnknown

	// Finished
	bRunCyclic = 0;
	TEST_DONE;
}

_TEST BrbUaRsEvents_FireEvent_InvalidFieldName(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsEvents.BrbUaRsEvents_FireEvent_InvalidFieldName", sizeof(sCurrentUnitTest));

	// Cyclic
	bRunCyclic = 1;
	TEST_ABORT_CONDITION_MSG(fbBrbUaRunServerCyclic.nStatus != eBRB_ERR_OK, "RunServer not running!")
	TEST_BUSY_CONDITION(RunServer.State.eState != eBRB_RSSTATE_RUNNING)

	// Fire Event
	fbBrbUaRsFireEvent.pRunServer = &RunServer;
	fbBrbUaRsFireEvent.nEventIndex = 1;
	BrbUaRsFireEvent(&fbBrbUaRsFireEvent);
	TEST_BUSY_CONDITION(fbBrbUaRsFireEvent.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_ERROR, fbBrbUaRsFireEvent.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x806F0000 , fbBrbUaRsFireEvent.nErrorId);	// Bad_NoMatch

	// Finished
	bRunCyclic = 0;
	TEST_DONE;
}

_TEST BrbUaRsEvents_FireEvent_InvalidVarName(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsEvents.BrbUaRsEvents_FireEvent_InvalidVarName", sizeof(sCurrentUnitTest));

	// Cyclic
	bRunCyclic = 1;
	TEST_ABORT_CONDITION_MSG(fbBrbUaRunServerCyclic.nStatus != eBRB_ERR_OK, "RunServer not running!")
	TEST_BUSY_CONDITION(RunServer.State.eState != eBRB_RSSTATE_RUNNING)

	// Fire Event
	fbBrbUaRsFireEvent.pRunServer = &RunServer;
	fbBrbUaRsFireEvent.nEventIndex = 2;
	BrbUaRsFireEvent(&fbBrbUaRsFireEvent);
	TEST_BUSY_CONDITION(fbBrbUaRsFireEvent.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_ERROR, fbBrbUaRsFireEvent.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0xB0040000 , fbBrbUaRsFireEvent.nErrorId);	// PlcOpen_BadVariableNameInvalid

	// Finished
	bRunCyclic = 0;
	TEST_DONE;
}

_TEST BrbUaRsEvents_FireEvent_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsEvents.BrbUaRsEvents_FireEvent_Ok", sizeof(sCurrentUnitTest));

	// Cyclic
	bRunCyclic = 1;
	TEST_ABORT_CONDITION_MSG(fbBrbUaRunServerCyclic.nStatus != eBRB_ERR_OK, "RunServer not running!")
	TEST_BUSY_CONDITION(RunServer.State.eState != eBRB_RSSTATE_RUNNING)

	// Fire Event
	fbBrbUaRsFireEvent.pRunServer = &RunServer;
	fbBrbUaRsFireEvent.nEventIndex = 3;
	BrbUaRsFireEvent(&fbBrbUaRsFireEvent);
	TEST_BUSY_CONDITION(fbBrbUaRsFireEvent.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRsFireEvent.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, fbBrbUaRsFireEvent.nErrorId);	// Good

	// Finished
	bRunCyclic = 0;
	TEST_DONE;
}

_TEARDOWN_SET(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsEvents._TEARDOWN_SET", sizeof(sCurrentUnitTest));

	bRunCyclic = 0;
	// Exit
	fbBrbUaRunServerExit.pRunServer = &RunServer;
	BrbUaRunServerExit(&fbBrbUaRunServerExit);
	TEST_BUSY_CONDITION(fbBrbUaRunServerExit.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRunServerExit.nStatus);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-03-12 07:18:20Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaRsEvents_Init", BrbUaRsEvents_Init), 
	new_TestFixture("BrbUaRsEvents_GetEvent_NulPtr", BrbUaRsEvents_GetEvent_NulPtr), 
	new_TestFixture("BrbUaRsEvents_GetEventField_NulPtr", BrbUaRsEvents_GetEventField_NulPtr), 
	new_TestFixture("BrbUaRsEvents_FireEvent_NulPtr", BrbUaRsEvents_FireEvent_NulPtr), 
	new_TestFixture("BrbUaRsEvents_FireEvent_NotRunning", BrbUaRsEvents_FireEvent_NotRunning), 
	new_TestFixture("BrbUaRsEvents_GetEvent_InvalidEventIndex", BrbUaRsEvents_GetEvent_InvalidEventIndex), 
	new_TestFixture("BrbUaRsEvents_GetEvent_Ok", BrbUaRsEvents_GetEvent_Ok), 
	new_TestFixture("BrbUaRsEvents_GetEventField_InvalidEventFieldIndex", BrbUaRsEvents_GetEventField_InvalidEventFieldIndex), 
	new_TestFixture("BrbUaRsEvents_GetEventField_Ok", BrbUaRsEvents_GetEventField_Ok), 
	new_TestFixture("BrbUaRsEvents_FireEvent_InvalidTypeNodeId", BrbUaRsEvents_FireEvent_InvalidTypeNodeId), 
	new_TestFixture("BrbUaRsEvents_FireEvent_InvalidFieldName", BrbUaRsEvents_FireEvent_InvalidFieldName), 
	new_TestFixture("BrbUaRsEvents_FireEvent_InvalidVarName", BrbUaRsEvents_FireEvent_InvalidVarName), 
	new_TestFixture("BrbUaRsEvents_FireEvent_Ok", BrbUaRsEvents_FireEvent_Ok), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaRsEvents, "Set_BrbUaRsEvents", 0, 0, fixtures, setupSet, teardownSet, cyclicSetCaller);

