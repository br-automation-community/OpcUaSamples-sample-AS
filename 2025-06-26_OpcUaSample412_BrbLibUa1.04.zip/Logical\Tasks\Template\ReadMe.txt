
Das ist nur ein Muster, um damit schnell die Grund-Struktur eines neuen Tasks zu erstellen.
Es wird f�r das Beispiel nicht ben�tigt.