In diesem Ordner sind die Dateien enthalten, welche f�r das externe Model-Tool 'UaModeler' ben�tigt werden:

	OpcUa_MyMachine.pdf								Exemplarische Anleitung zum Erzeugen eines eigenen Daten-Modells (Entwurf)
																		unter AS4.6.

	aircondmodel.tt2pro								Projekt-Datei f�r das Modeler-Tool 'UaModeler'.
	
	aircondmodel.xml									Vom Modeler exportierte Datei, welche das neue Modell enth�lt.
																			Sie wurde in die Configuration View	unter "Connectivity/OpcUa" kopiert und
																			in "*.uanodeset" umbenannt.
																			Damit wurde das neue Modell ins AS importiert.
	
	aircondmodel.ua										Vom Modeler erzeugte Datei, die intern ben�tigt wird.
	aircondmodel.bsd									Vom Modeler exportierte Datei, welche das Bin�r-Schema enth�lt.
	aircondmodel.xsd									Vom Modeler exportierte Datei, welche das XML-Schema enth�lt.
