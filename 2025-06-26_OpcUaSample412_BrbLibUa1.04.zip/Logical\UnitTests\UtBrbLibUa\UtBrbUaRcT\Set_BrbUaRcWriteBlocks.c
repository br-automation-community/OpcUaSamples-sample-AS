#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_SETUP_SET(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks._SETUP_SET", sizeof(sCurrentUnitTest));

	memset(&fbBrbUaRcWriteBlock, 0, sizeof(fbBrbUaRcWriteBlock));

	// Finished
	TEST_DONE;
}

_CYCLIC_SET(void)
{
	if(RunClient.State.eState >= eBRB_RCSTATE_INIT_DONE && RunClient.State.eState < eBRB_RCSTATE_EXITING)
	{
		if(bRunCyclic == 1)
		{
			fbBrbUaRunClientCyclic.pRunClient = &RunClient;
			BrbUaRunClientCyclic(&fbBrbUaRunClientCyclic);
		}
	}
	BrbUaRcMonitor(&RunClient, &CyclicMonitor);
	return;
}

_TEST BrbUaRcWriteBlocks_GetWriteBlock_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks.BrbUaRcWriteBlocks_GetWriteBlock_NulPtr", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRcGetWriteBlock(0, 0, &WriteBlock, &WriteBlockIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);
	
	uintOut = BrbUaRcGetWriteBlock(&RunClient, 0, 0, &WriteBlockIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcWriteBlocks_GetWriteBlock_InvalidWriteBlockIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks.BrbUaRcWriteBlocks_GetWriteBlock_InvalidWriteBlockIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&WriteBlock, 0, sizeof(WriteBlock));
	memset(&WriteBlockIntern, 0, sizeof(WriteBlockIntern));
	uintOut = BrbUaRcGetWriteBlock(&RunClient, 99, &WriteBlock, &WriteBlockIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);
	TEST_ASSERT_EQUAL_INT(0, WriteBlock.nWriteItemCount);
	TEST_ASSERT_EQUAL_INT(0, WriteBlockIntern.nWriteItemCount);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.WriteBlock.nWriteBlockIndex = 99;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.WriteBlock.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.WriteBlock.WriteBlock.nWriteItemCount);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.WriteBlock.WriteBlockIntern.nWriteItemCount);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcWriteBlocks_GetWriteBlock_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks.BrbUaRcWriteBlocks_GetWriteBlock_Ok", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&WriteBlock, 0, sizeof(WriteBlock));
	memset(&WriteBlockIntern, 0, sizeof(WriteBlockIntern));
	uintOut = BrbUaRcGetWriteBlock(&RunClient, eWRITEBLOCK_IDX_OK, &WriteBlock, &WriteBlockIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(5, WriteBlock.nWriteItemCount);
	TEST_ASSERT_EQUAL_INT(5, WriteBlockIntern.nWriteItemCount);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.WriteBlock.nWriteBlockIndex = eWRITEBLOCK_IDX_OK;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.WriteBlock.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(5, RcMonitor.WriteBlock.WriteBlock.nWriteItemCount);
	TEST_ASSERT_EQUAL_INT(5, RcMonitor.WriteBlock.WriteBlockIntern.nWriteItemCount);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcWriteBlocks_GetWriteItem_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks.BrbUaRcWriteBlocks_GetWriteItem_NulPtr", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRcGetWriteItem(0, 0, 0, &WriteItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);
	
	uintOut = BrbUaRcGetWriteItem(&RunClient, 0, 0, 0);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcWriteBlocks_GetWriteItem_InvalidWriteBlockIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks.BrbUaRcWriteBlocks_GetWriteItem_InvalidWriteBlockIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&WriteBlock, 0, sizeof(WriteBlock));
	memset(&WriteBlockIntern, 0, sizeof(WriteBlockIntern));
	uintOut = BrbUaRcGetWriteItem(&RunClient, 99, 0, &WriteItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);
	TEST_ASSERT_EQUAL_INT(0, WriteItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, WriteItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, WriteItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("", WriteItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, WriteItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("", WriteItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, WriteItem.nErrorId); // Good

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.WriteItem.nWriteBlockIndex = 99;
	RcMonitor.WriteItem.nWriteItemIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.WriteItem.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.WriteItem.WriteItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.WriteItem.WriteItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.WriteItem.WriteItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("", RcMonitor.WriteItem.WriteItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.WriteItem.WriteItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("", RcMonitor.WriteItem.WriteItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.WriteItem.WriteItem.nErrorId); // Good

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcWriteBlocks_GetWriteItem_InvalidWriteItemIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks.BrbUaRcWriteBlocks_GetWriteItem_InvalidWriteItemIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&WriteItem, 0, sizeof(WriteItem));
	uintOut = BrbUaRcGetWriteItem(&RunClient, 0, 99, &WriteItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);
	TEST_ASSERT_EQUAL_INT(0, WriteItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, WriteItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, WriteItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("", WriteItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, WriteItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("", WriteItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, WriteItem.nErrorId); // Good

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.WriteItem.nWriteBlockIndex = 0;
	RcMonitor.WriteItem.nWriteItemIndex = 99;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.WriteItem.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.WriteItem.WriteItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.WriteItem.WriteItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.WriteItem.WriteItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("", RcMonitor.WriteItem.WriteItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.WriteItem.WriteItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("", RcMonitor.WriteItem.WriteItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.WriteItem.WriteItem.nErrorId); // Good

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcWriteBlocks_GetWriteItem_InvalidNamespaceIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks.BrbUaRcWriteBlocks_GetWriteItem_InvalidNamespaceIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&WriteItem, 0, sizeof(WriteItem));
	uintOut = BrbUaRcGetWriteItem(&RunClient, eWRITEBLOCK_IDX_INV_NS, 3, &WriteItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(99, WriteItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, WriteItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, WriteItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Write.anUint[3]", WriteItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, WriteItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Write.anUint[3]", WriteItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, WriteItem.nErrorId); // Good (wird erst beim Lesen erkannt)

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.WriteItem.nWriteBlockIndex = eWRITEBLOCK_IDX_INV_NS;
	RcMonitor.WriteItem.nWriteItemIndex = 3;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.WriteItem.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(99, RcMonitor.WriteItem.WriteItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.WriteItem.WriteItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.WriteItem.WriteItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Write.anUint[3]", RcMonitor.WriteItem.WriteItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, RcMonitor.WriteItem.WriteItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Write.anUint[3]", RcMonitor.WriteItem.WriteItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.WriteItem.WriteItem.nErrorId); // Good (wird erst beim Lesen erkannt)
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcWriteBlocks_GetWriteItem_InvalidIdentifier(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks.BrbUaRcWriteBlocks_GetWriteItem_InvalidIdentifier", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&WriteItem, 0, sizeof(WriteItem));
	uintOut = BrbUaRcGetWriteItem(&RunClient, eWRITEBLOCK_IDX_INV_ID, 3, &WriteItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, WriteItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, WriteItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, WriteItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Write.UnknownNode", WriteItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, WriteItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Write.anUint[3]", WriteItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, WriteItem.nErrorId); // Good (wird erst beim Lesen erkannt)

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.WriteItem.nWriteBlockIndex = eWRITEBLOCK_IDX_INV_ID;
	RcMonitor.WriteItem.nWriteItemIndex = 3;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.WriteItem.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(3, RcMonitor.WriteItem.WriteItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.WriteItem.WriteItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.WriteItem.WriteItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Write.UnknownNode", RcMonitor.WriteItem.WriteItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, RcMonitor.WriteItem.WriteItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Write.anUint[3]", RcMonitor.WriteItem.WriteItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.WriteItem.WriteItem.nErrorId); // Good (wird erst beim Lesen erkannt)
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcWriteBlocks_GetWriteItem_InvalidVarName(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks.BrbUaRcWriteBlocks_GetWriteItem_InvalidVarName", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&WriteItem, 0, sizeof(WriteItem));
	uintOut = BrbUaRcGetWriteItem(&RunClient, eWRITEBLOCK_IDX_INV_VAR, 3, &WriteItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, WriteItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, WriteItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, WriteItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Write.anUint[3]", WriteItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, WriteItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Write.UnknownVar", WriteItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, WriteItem.nErrorId); // Good (wird erst beim Lesen erkannt)

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.WriteItem.nWriteBlockIndex = eWRITEBLOCK_IDX_INV_VAR;
	RcMonitor.WriteItem.nWriteItemIndex = 3;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.WriteItem.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(3, RcMonitor.WriteItem.WriteItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.WriteItem.WriteItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.WriteItem.WriteItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Write.anUint[3]", RcMonitor.WriteItem.WriteItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, RcMonitor.WriteItem.WriteItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Write.UnknownVar", RcMonitor.WriteItem.WriteItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.WriteItem.WriteItem.nErrorId); // Good (wird erst beim Lesen erkannt)
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcWriteBlocks_GetWriteItem_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks.BrbUaRcWriteBlocks_GetWriteItem_Ok", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&WriteItem, 0, sizeof(WriteItem));
	uintOut = BrbUaRcGetWriteItem(&RunClient, eWRITEBLOCK_IDX_OK, 3, &WriteItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, WriteItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, WriteItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, WriteItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Write.anUint[8]", WriteItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, WriteItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Write.anUint[8]", WriteItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, WriteItem.nErrorId); // Good

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.WriteItem.nWriteBlockIndex = eWRITEBLOCK_IDX_OK;
	RcMonitor.WriteItem.nWriteItemIndex = 3;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.WriteItem.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(3, RcMonitor.WriteItem.WriteItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.WriteItem.WriteItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.WriteItem.WriteItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Write.anUint[8]", RcMonitor.WriteItem.WriteItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, RcMonitor.WriteItem.WriteItem.AddInfo.AttributeId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Write.anUint[8]", RcMonitor.WriteItem.WriteItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.WriteItem.WriteItem.nErrorId); // Good
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcWriteBlocks_WriteBlock_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks.BrbUaRcWriteBlocks_WriteBlock_NulPtr", sizeof(sCurrentUnitTest));

	fbBrbUaRcWriteBlock.pRunClient = 0;
	fbBrbUaRcWriteBlock.nWriteBlockIndex = 0;
	BrbUaRcWriteBlock(&fbBrbUaRcWriteBlock);
	TEST_BUSY_CONDITION(fbBrbUaRcWriteBlock.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, fbBrbUaRcWriteBlock.nStatus);
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcWriteBlocks_WriteBlock_InvalidWriteBlockIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks.BrbUaRcWriteBlocks_WriteBlock_InvalidWriteBlockIndex", sizeof(sCurrentUnitTest));

	fbBrbUaRcWriteBlock.pRunClient = &RunClient;
	fbBrbUaRcWriteBlock.nWriteBlockIndex = 99;
	BrbUaRcWriteBlock(&fbBrbUaRcWriteBlock);
	TEST_BUSY_CONDITION(fbBrbUaRcWriteBlock.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, fbBrbUaRcWriteBlock.nStatus);
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcWriteBlocks_WriteBlock_InvalidNamespaceIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks.BrbUaRcWriteBlocks_WriteBlock_InvalidNamespaceIndex", sizeof(sCurrentUnitTest));

	fbBrbUaRcWriteBlock.pRunClient = &RunClient;
	fbBrbUaRcWriteBlock.nWriteBlockIndex = eWRITEBLOCK_IDX_INV_NS;
	BrbUaRcWriteBlock(&fbBrbUaRcWriteBlock);
	TEST_BUSY_CONDITION(fbBrbUaRcWriteBlock.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_ERROR, fbBrbUaRcWriteBlock.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, fbBrbUaRcWriteBlock.nErrorId); // Bad_NodeIdUnknown
	TEST_ASSERT_EQUAL_STRING("0x80340000 = Bad_NodeIdUnknown", fbBrbUaRcWriteBlock.sErrorId);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcWriteBlocks_WriteBlock_InvalidIdentifier(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks.BrbUaRcWriteBlocks_WriteBlock_InvalidIdentifier", sizeof(sCurrentUnitTest));

	fbBrbUaRcWriteBlock.pRunClient = &RunClient;
	fbBrbUaRcWriteBlock.nWriteBlockIndex = eWRITEBLOCK_IDX_INV_ID;
	BrbUaRcWriteBlock(&fbBrbUaRcWriteBlock);
	TEST_BUSY_CONDITION(fbBrbUaRcWriteBlock.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_ERROR, fbBrbUaRcWriteBlock.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, fbBrbUaRcWriteBlock.nErrorId); // Bad_NodeIdUnknown
	TEST_ASSERT_EQUAL_STRING("0x80340000 = Bad_NodeIdUnknown", fbBrbUaRcWriteBlock.sErrorId);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcWriteBlocks_WriteBlock_InvalidVarName(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks.BrbUaRcWriteBlocks_WriteBlock_InvalidVarName", sizeof(sCurrentUnitTest));

	fbBrbUaRcWriteBlock.pRunClient = &RunClient;
	fbBrbUaRcWriteBlock.nWriteBlockIndex = eWRITEBLOCK_IDX_INV_VAR;
	BrbUaRcWriteBlock(&fbBrbUaRcWriteBlock);
	TEST_BUSY_CONDITION(fbBrbUaRcWriteBlock.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_ERROR, fbBrbUaRcWriteBlock.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x80740000, fbBrbUaRcWriteBlock.nErrorId); // Bad_TypeMismatch (nicht PlcOpen_BadVariableNameInvalid)
	TEST_ASSERT_EQUAL_STRING("0x80740000 = Bad_TypeMismatch", fbBrbUaRcWriteBlock.sErrorId);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcWriteBlocks_WriteBlock_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks.BrbUaRcWriteBlocks_WriteBlock_Ok", sizeof(sCurrentUnitTest));

	Data.Read.anUint[9] = 0;
	fbBrbUaRcWriteBlock.pRunClient = &RunClient;
	fbBrbUaRcWriteBlock.nWriteBlockIndex = eWRITEBLOCK_IDX_OK;
	BrbUaRcWriteBlock(&fbBrbUaRcWriteBlock);
	TEST_BUSY_CONDITION(fbBrbUaRcWriteBlock.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRcWriteBlock.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, fbBrbUaRcWriteBlock.nErrorId); // Good
	TEST_ASSERT_EQUAL_STRING("0x00000000 = Good", fbBrbUaRcWriteBlock.sErrorId);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcWriteBlocks_WriteBlock_Ok_ReadBack(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcWriteBlocks.BrbUaRcWriteBlocks_WriteBlock_Ok_ReadBack", sizeof(sCurrentUnitTest));

	fbBrbUaRcReadBlock.pRunClient = &RunClient;
	fbBrbUaRcReadBlock.nReadBlockIndex = eWRITEBLOCK_IDX_OK_READ_BACK;
	BrbUaRcReadBlock(&fbBrbUaRcReadBlock);
	TEST_BUSY_CONDITION(fbBrbUaRcReadBlock.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRcReadBlock.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, fbBrbUaRcReadBlock.nErrorId); // Good
	TEST_ASSERT_EQUAL_STRING("0x00000000 = Good", fbBrbUaRcReadBlock.sErrorId);
	TEST_ASSERT_EQUAL_INT(Data.Write.anUint[9], Data.Read.anUint[9]);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-03-18 15:15:45Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaRcWriteBlocks_GetWriteBlock_NulPtr", BrbUaRcWriteBlocks_GetWriteBlock_NulPtr), 
	new_TestFixture("BrbUaRcWriteBlocks_GetWriteBlock_InvalidWriteBlockIndex", BrbUaRcWriteBlocks_GetWriteBlock_InvalidWriteBlockIndex), 
	new_TestFixture("BrbUaRcWriteBlocks_GetWriteBlock_Ok", BrbUaRcWriteBlocks_GetWriteBlock_Ok), 
	new_TestFixture("BrbUaRcWriteBlocks_GetWriteItem_NulPtr", BrbUaRcWriteBlocks_GetWriteItem_NulPtr), 
	new_TestFixture("BrbUaRcWriteBlocks_GetWriteItem_InvalidWriteBlockIndex", BrbUaRcWriteBlocks_GetWriteItem_InvalidWriteBlockIndex), 
	new_TestFixture("BrbUaRcWriteBlocks_GetWriteItem_InvalidWriteItemIndex", BrbUaRcWriteBlocks_GetWriteItem_InvalidWriteItemIndex), 
	new_TestFixture("BrbUaRcWriteBlocks_GetWriteItem_InvalidNamespaceIndex", BrbUaRcWriteBlocks_GetWriteItem_InvalidNamespaceIndex), 
	new_TestFixture("BrbUaRcWriteBlocks_GetWriteItem_InvalidIdentifier", BrbUaRcWriteBlocks_GetWriteItem_InvalidIdentifier), 
	new_TestFixture("BrbUaRcWriteBlocks_GetWriteItem_InvalidVarName", BrbUaRcWriteBlocks_GetWriteItem_InvalidVarName), 
	new_TestFixture("BrbUaRcWriteBlocks_GetWriteItem_Ok", BrbUaRcWriteBlocks_GetWriteItem_Ok), 
	new_TestFixture("BrbUaRcWriteBlocks_WriteBlock_NulPtr", BrbUaRcWriteBlocks_WriteBlock_NulPtr), 
	new_TestFixture("BrbUaRcWriteBlocks_WriteBlock_InvalidWriteBlockIndex", BrbUaRcWriteBlocks_WriteBlock_InvalidWriteBlockIndex), 
	new_TestFixture("BrbUaRcWriteBlocks_WriteBlock_InvalidNamespaceIndex", BrbUaRcWriteBlocks_WriteBlock_InvalidNamespaceIndex), 
	new_TestFixture("BrbUaRcWriteBlocks_WriteBlock_InvalidIdentifier", BrbUaRcWriteBlocks_WriteBlock_InvalidIdentifier), 
	new_TestFixture("BrbUaRcWriteBlocks_WriteBlock_InvalidVarName", BrbUaRcWriteBlocks_WriteBlock_InvalidVarName), 
	new_TestFixture("BrbUaRcWriteBlocks_WriteBlock_Ok", BrbUaRcWriteBlocks_WriteBlock_Ok), 
	new_TestFixture("BrbUaRcWriteBlocks_WriteBlock_Ok_ReadBack", BrbUaRcWriteBlocks_WriteBlock_Ok_ReadBack), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaRcWriteBlocks, "Set_BrbUaRcWriteBlocks", 0, 0, fixtures, setupSet, 0, cyclicSetCaller);

