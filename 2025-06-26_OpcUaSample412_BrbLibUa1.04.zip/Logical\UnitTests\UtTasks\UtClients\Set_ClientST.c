#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

UDINT ClientST_GetPointer(STRING* pPvName)
{
	UDINT nPvAdr = 0;
	UDINT nPvLen = 0;
	nPvXGetAdrStatus = PV_xgetadr(pPvName, &nPvAdr, &nPvLen);
	STRING sText[255];
	BrbStringCopy(sText, "Error on getting pointer of ", sizeof(sText));
	BrbStringCat(sText, pPvName, sizeof(sText));
	TEST_ABORT_CONDITION_MSG(nPvXGetAdrStatus != 0, sText)
	TEST_ABORT_CONDITION_MSG(nPvAdr == 0, sText)
	return nPvAdr;
}

_TEST ClientST_GetLocalPointer(void)
{
	BrbStringCopy(sCurrentUnitTest, "ClientST.ClientST_GetLocalPointer", sizeof(sCurrentUnitTest));

	pClientStepErrorId				=	(DWORD*)											ClientST_GetPointer("ClientST:Step.nErrorId");
	pClientConnectionStatus		=	(ClientConnectionStatus_TYP*)	ClientST_GetPointer("ClientST:ConnectionStatus");
	pClientVarsSubscription		=	(OpcUaTestDatatypes_TYP*)			ClientST_GetPointer("ClientST:ClientVarsSubscription");
	pClientReceivedEvent			=	(ProgressEvent_TYP*)					ClientST_GetPointer("ClientST:ReceivedEvent");
	pFbUA_ReadListErrorId			=	(DWORD*)											ClientST_GetPointer("ClientST:fbUA_ReadList.ErrorID");
	pClientVarsRead						=	(OpcUaTestDatatypes_TYP*)			ClientST_GetPointer("ClientST:ClientVarsRead");
	pFbUA_WriteListErrorId		=	(DWORD*)											ClientST_GetPointer("ClientST:fbUA_WriteList.ErrorID");
	pServerVarsWrite					=	(OpcUaTestDatatypes_TYP*)			ClientST_GetPointer("ServerData:WriteC");
	pFbUA_MethodCallErrorId		=	(DWORD*)											ClientST_GetPointer("ClientST:fbUA_MethodCall.ErrorID");

	// Finished
	TEST_DONE;
}

_TEST ClientST_Check_ClientStepErrorId(void)
{
	BrbStringCopy(sCurrentUnitTest, "ClientST.ClientST_Check_ClientStepErrorId", sizeof(sCurrentUnitTest));

	BRB_ASSERT_EQUAL_UDINT(0x00000000, *pClientStepErrorId); // Good
	TEST_ABORT_CONDITION_MSG(0x00000000 != *pClientStepErrorId, "Error in step sequencer")

	// Finished
	TEST_DONE;
}

_TEST ClientST_Check_ClientConnectionStatus(void)
{
	BrbStringCopy(sCurrentUnitTest, "ClientST.ClientST_Check_ClientConnectionStatus", sizeof(sCurrentUnitTest));

	BRB_ASSERT_EQUAL_DINT(UACS_Connected, pClientConnectionStatus->eConnectionStatus);
	TEST_ABORT_CONDITION_MSG(UACS_Connected != pClientConnectionStatus->eConnectionStatus, "Client not connected")

	// Finished
	TEST_DONE;
}

_TEST ClientST_Change_Values_Store(void)
{
	BrbStringCopy(sCurrentUnitTest, "ClientST.ClientST_Change_Values_Store", sizeof(sCurrentUnitTest));

	memcpy(&ClientVarsSubscriptionStored, pClientVarsSubscription, sizeof(ClientVarsSubscriptionStored));
	memcpy(&ClientReceivedEventStored, pClientReceivedEvent, sizeof(ClientReceivedEventStored));
	memcpy(&ClientVarsReadStored, pClientVarsRead, sizeof(ClientVarsReadStored));
	memcpy(&ServerVarsWriteStored, pServerVarsWrite, sizeof(ServerVarsWriteStored));
	
	// Finished
	TEST_DONE;
}

_TEST ClientST_Change_Values_Wait(void)
{
	BrbStringCopy(sCurrentUnitTest, "ClientST.ClientST_Change_Values_Wait", sizeof(sCurrentUnitTest));

	// Zeit abwarten
	fbTonWait.IN = 1;
	fbTonWait.PT = 7000;
	TON(&fbTonWait);
	TEST_BUSY_CONDITION(fbTonWait.Q == 0)
	fbTonWait.IN = 0;
	TON(&fbTonWait);

	// Finished
	TEST_DONE;
}

_TEST ClientST_Change_Values_Check(void)
{
	BrbStringCopy(sCurrentUnitTest, "ClientST.ClientST_Change_Values_Check", sizeof(sCurrentUnitTest));

	// Werte testen. Achtung: Da der Update stark von Zeiten abh�ngt, die ArSim aber nicht deterministisch ist, kann hier manchmal ein Fehler registiert werden!
	
	BRB_ASSERT_EQUAL_UDINT(0x00000000, *pClientStepErrorId); // Good

	// SubscriptionVar
	TEST_ASSERT_MESSAGE(ClientVarsSubscriptionStored.nUint != pClientVarsSubscription->nUint, "Subscription: nUint was not updated!");
	TEST_ASSERT_MESSAGE(ClientVarsSubscriptionStored.nInt != pClientVarsSubscription->nInt, "Subscription: nInt was not updated!");
	TEST_ASSERT_MESSAGE(ClientVarsSubscriptionStored.tTime != pClientVarsSubscription->tTime, "Subscription: tTime was not updated!");
	
	// Event
	TEST_ASSERT_MESSAGE(ClientReceivedEventStored.nReceivedCount != pClientReceivedEvent->nReceivedCount, "Event: nReceivedCount was not incremented!");
	
	// Read
	TEST_ASSERT_MESSAGE(0x00000000 != pFbUA_ReadListErrorId, "Read: ErrorId was not Good!");
	TEST_ASSERT_MESSAGE(ClientVarsReadStored.nUdint != pClientVarsRead->nUdint, "Read: nUdint was not updated!");
	TEST_ASSERT_MESSAGE(ClientVarsReadStored.nDint != pClientVarsRead->nDint, "Read: nDint was not updated!");
	TEST_ASSERT_MESSAGE(ClientVarsReadStored.anInt[0] != pClientVarsRead->anInt[0], "Read: anInt[0] was not updated!");

	// Write
	TEST_ASSERT_MESSAGE(0x00000000 != pFbUA_WriteListErrorId, "Read: ErrorId was not Good!");
	TEST_ASSERT_MESSAGE(ServerVarsWriteStored.nUdint != pServerVarsWrite->nUdint, "Write: nUdint was not updated!");
	TEST_ASSERT_MESSAGE(ServerVarsWriteStored.nDint != pServerVarsWrite->nDint, "Write: nDint was not updated!");
	TEST_ASSERT_MESSAGE(ServerVarsWriteStored.anInt[0] != pServerVarsWrite->anInt[0], "Write: anInt[0] was not updated!");

	//Method
	TEST_ASSERT_MESSAGE(0x00000000 != pFbUA_MethodCallErrorId, "Method: ErrorId was not Good!");

	// Finished
	TEST_DONE;
}


// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-03-20 12:32:40Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("ClientST_GetLocalPointer", ClientST_GetLocalPointer), 
	new_TestFixture("ClientST_Check_ClientStepErrorId", ClientST_Check_ClientStepErrorId), 
	new_TestFixture("ClientST_Check_ClientConnectionStatus", ClientST_Check_ClientConnectionStatus), 
	new_TestFixture("ClientST_Change_Values_Store", ClientST_Change_Values_Store), 
	new_TestFixture("ClientST_Change_Values_Wait", ClientST_Change_Values_Wait), 
	new_TestFixture("ClientST_Change_Values_Check", ClientST_Change_Values_Check), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_ClientST, "Set_ClientST", 0, 0, fixtures, 0, 0, 0);

