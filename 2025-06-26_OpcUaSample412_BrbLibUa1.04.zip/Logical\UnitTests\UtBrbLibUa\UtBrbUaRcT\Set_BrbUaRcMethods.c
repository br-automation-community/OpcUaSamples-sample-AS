#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_SETUP_SET(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods._SETUP_SET", sizeof(sCurrentUnitTest));

	nCallCount = 0;
	nDatatypeMismatch = 0;
	nArgIn10 = 0;
	nArgOut10 = 0;
	memset(&fbBrbUaRcCallMethod, 0, sizeof(fbBrbUaRcCallMethod));

	// Finished
	TEST_DONE;
}

_CYCLIC_SET(void)
{
	if(RunClient.State.eState >= eBRB_RCSTATE_INIT_DONE && RunClient.State.eState < eBRB_RCSTATE_EXITING)
	{
		if(bRunCyclic == 1)
		{
			fbBrbUaRunClientCyclic.pRunClient = &RunClient;
			BrbUaRunClientCyclic(&fbBrbUaRunClientCyclic);
		}
	}
	BrbUaRcMonitor(&RunClient, &CyclicMonitor);
	return;
}

_TEST BrbUaRcMethods_GetMethod_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_GetMethod_NulPtr", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRcGetMethod(0, 0, &Method, &MethodIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);
	
	uintOut = BrbUaRcGetMethod(&RunClient, 0, 0, &MethodIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_GetMethod_InvalidMethodIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_GetMethod_InvalidMethodIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Method, 0, sizeof(Method));
	memset(&MethodIntern, 0, sizeof(MethodIntern));
	uintOut = BrbUaRcGetMethod(&RunClient, 99, &Method, &MethodIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Method.nMethodIndex = 99;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.Method.nMonitorStatus);
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_GetMethod_InvalidNamespaceIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_GetMethod_InvalidNamespaceIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Method, 0, sizeof(Method));
	memset(&MethodIntern, 0, sizeof(MethodIntern));
	uintOut = BrbUaRcGetMethod(&RunClient, METHOD_IDX_INV_NS, &Method, &MethodIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(99, Method.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, Method.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, Method.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs", Method.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, Method.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, Method.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Calculate", Method.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, Method.tTimeout);
	TEST_ASSERT_EQUAL_INT(2, Method.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(2, Method.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, Method.nErrorId); // Bad_NodeIdUnknown
	TEST_ASSERT_EQUAL_INT(99, MethodIntern.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, MethodIntern.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, MethodIntern.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs", MethodIntern.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, MethodIntern.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, MethodIntern.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Calculate", MethodIntern.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, MethodIntern.tTimeout);
	TEST_ASSERT_EQUAL_INT(2, MethodIntern.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(2, MethodIntern.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, MethodIntern.nErrorId); // Bad_NodeIdUnknown

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Method.nMethodIndex = METHOD_IDX_INV_NS;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.Method.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(99, RcMonitor.Method.Method.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.Method.Method.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.Method.Method.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs", RcMonitor.Method.Method.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.Method.Method.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.Method.Method.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Calculate", RcMonitor.Method.Method.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, RcMonitor.Method.Method.tTimeout);
	TEST_ASSERT_EQUAL_INT(2, RcMonitor.Method.Method.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(2, RcMonitor.Method.Method.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, Method.nErrorId); // Bad_NodeIdUnknown
	TEST_ASSERT_EQUAL_INT(99, RcMonitor.Method.MethodIntern.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.Method.MethodIntern.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.Method.MethodIntern.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs", RcMonitor.Method.MethodIntern.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.Method.MethodIntern.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.Method.MethodIntern.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Calculate", RcMonitor.Method.MethodIntern.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, RcMonitor.Method.MethodIntern.tTimeout);
	TEST_ASSERT_EQUAL_INT(2, RcMonitor.Method.MethodIntern.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(2, RcMonitor.Method.MethodIntern.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, RcMonitor.Method.Method.nErrorId); // Bad_NodeIdUnknown

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_GetMethod_InvalidObjectIdentifier(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_GetMethod_InvalidObjectIdentifier", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Method, 0, sizeof(Method));
	memset(&MethodIntern, 0, sizeof(MethodIntern));
	uintOut = BrbUaRcGetMethod(&RunClient, METHOD_IDX_INV_OBJ_ID, &Method, &MethodIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, Method.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, Method.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, Method.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRsXXX", Method.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(7, Method.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, Method.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Calculate", Method.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, Method.tTimeout);
	TEST_ASSERT_EQUAL_INT(2, Method.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(2, Method.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Method.nErrorId); // Good (wird erst beim Aufruf erkannt)
	TEST_ASSERT_EQUAL_INT(3, MethodIntern.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, MethodIntern.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, MethodIntern.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRsXXX", MethodIntern.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(7, MethodIntern.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, MethodIntern.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Calculate", MethodIntern.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, MethodIntern.tTimeout);
	TEST_ASSERT_EQUAL_INT(2, MethodIntern.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(2, MethodIntern.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MethodIntern.nErrorId); // Good (wird erst beim Aufruf erkannt)

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Method.nMethodIndex = METHOD_IDX_INV_OBJ_ID;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.Method.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(3, RcMonitor.Method.Method.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.Method.Method.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.Method.Method.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRsXXX", RcMonitor.Method.Method.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.Method.Method.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.Method.Method.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Calculate", RcMonitor.Method.Method.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, RcMonitor.Method.Method.tTimeout);
	TEST_ASSERT_EQUAL_INT(2, RcMonitor.Method.Method.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(2, RcMonitor.Method.Method.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Method.nErrorId);  // Good (wird erst beim Aufruf erkannt)
	TEST_ASSERT_EQUAL_INT(3, RcMonitor.Method.MethodIntern.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.Method.MethodIntern.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.Method.MethodIntern.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRsXXX", RcMonitor.Method.MethodIntern.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.Method.MethodIntern.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.Method.MethodIntern.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Calculate", RcMonitor.Method.MethodIntern.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, RcMonitor.Method.MethodIntern.tTimeout);
	TEST_ASSERT_EQUAL_INT(2, RcMonitor.Method.MethodIntern.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(2, RcMonitor.Method.MethodIntern.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.Method.Method.nErrorId);  // Good (wird erst beim Aufruf erkannt)

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_GetMethod_InvalidMethodIdentifier(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_GetMethod_InvalidMethodIdentifier", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Method, 0, sizeof(Method));
	memset(&MethodIntern, 0, sizeof(MethodIntern));
	uintOut = BrbUaRcGetMethod(&RunClient, METHOD_IDX_INV_METH_ID, &Method, &MethodIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, Method.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, Method.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, Method.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs", Method.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(7, Method.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, Method.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:CalculateXXX", Method.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, Method.tTimeout);
	TEST_ASSERT_EQUAL_INT(2, Method.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(2, Method.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, Method.nErrorId); // Bad_NodeIdUnknown
	TEST_ASSERT_EQUAL_INT(3, MethodIntern.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, MethodIntern.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, MethodIntern.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs", MethodIntern.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(7, MethodIntern.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, MethodIntern.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:CalculateXXX", MethodIntern.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, MethodIntern.tTimeout);
	TEST_ASSERT_EQUAL_INT(2, MethodIntern.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(2, MethodIntern.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, MethodIntern.nErrorId); // Bad_NodeIdUnknown

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Method.nMethodIndex = METHOD_IDX_INV_METH_ID;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.Method.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(3, RcMonitor.Method.Method.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.Method.Method.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.Method.Method.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs", RcMonitor.Method.Method.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.Method.Method.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.Method.Method.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:CalculateXXX", RcMonitor.Method.Method.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, RcMonitor.Method.Method.tTimeout);
	TEST_ASSERT_EQUAL_INT(2, RcMonitor.Method.Method.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(2, RcMonitor.Method.Method.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, Method.nErrorId);  // Bad_NodeIdUnknown
	TEST_ASSERT_EQUAL_INT(3, RcMonitor.Method.MethodIntern.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.Method.MethodIntern.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.Method.MethodIntern.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs", RcMonitor.Method.MethodIntern.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.Method.MethodIntern.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.Method.MethodIntern.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:CalculateXXX", RcMonitor.Method.MethodIntern.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, RcMonitor.Method.MethodIntern.tTimeout);
	TEST_ASSERT_EQUAL_INT(2, RcMonitor.Method.MethodIntern.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(2, RcMonitor.Method.MethodIntern.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, RcMonitor.Method.Method.nErrorId);  // Bad_NodeIdUnknown

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_GetMethod_OK(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_GetMethod_OK", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Method, 0, sizeof(Method));
	memset(&MethodIntern, 0, sizeof(MethodIntern));
	uintOut = BrbUaRcGetMethod(&RunClient, METHOD_IDX_CALCULATE_OK, &Method, &MethodIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, Method.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, Method.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, Method.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs", Method.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(7, Method.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, Method.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Calculate", Method.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, Method.tTimeout);
	TEST_ASSERT_EQUAL_INT(2, Method.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(2, Method.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Method.nErrorId); // Good
	TEST_ASSERT_EQUAL_INT(3, MethodIntern.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, MethodIntern.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, MethodIntern.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs", MethodIntern.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(7, MethodIntern.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, MethodIntern.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Calculate", MethodIntern.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, MethodIntern.tTimeout);
	TEST_ASSERT_EQUAL_INT(2, MethodIntern.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(2, MethodIntern.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MethodIntern.nErrorId); // Good

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Method.nMethodIndex = METHOD_IDX_CALCULATE_OK;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.Method.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(3, RcMonitor.Method.Method.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.Method.Method.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.Method.Method.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs", RcMonitor.Method.Method.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.Method.Method.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.Method.Method.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Calculate", RcMonitor.Method.Method.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, RcMonitor.Method.Method.tTimeout);
	TEST_ASSERT_EQUAL_INT(2, RcMonitor.Method.Method.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(2, RcMonitor.Method.Method.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Method.nErrorId);  // Good
	TEST_ASSERT_EQUAL_INT(3, RcMonitor.Method.MethodIntern.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.Method.MethodIntern.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.Method.MethodIntern.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs", RcMonitor.Method.MethodIntern.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(7, RcMonitor.Method.MethodIntern.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIdentifierType_String, RcMonitor.Method.MethodIntern.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Calculate", RcMonitor.Method.MethodIntern.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, RcMonitor.Method.MethodIntern.tTimeout);
	TEST_ASSERT_EQUAL_INT(2, RcMonitor.Method.MethodIntern.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(2, RcMonitor.Method.MethodIntern.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.Method.Method.nErrorId);  // Good

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_GetArgumentIn_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_GetArgumentIn_NulPtr", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRcGetArgument(0, 0, 0, 0, &Argument);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);
	
	uintOut = BrbUaRcGetArgument(&RunClient, 0, 0, 0, 0);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_GetArgumentIn_InvalidArgIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_GetArgumentIn_InvalidArgIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Argument, 0, sizeof(Argument));
	uintOut = BrbUaRcGetArgument(&RunClient, 0, 0, 99, &Argument);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Argument.nMethodIndex = 0;
	RcMonitor.Argument.bOutput = 0;
	RcMonitor.Argument.nArgumentIndex = 99;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.Argument.nMonitorStatus);
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_GetArgumentIn_InvalidArgName(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_GetArgumentIn_InvalidArgName", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Argument, 0, sizeof(Argument));
	uintOut = BrbUaRcGetArgument(&RunClient, METHOD_IDX_INV_ARG_NAME, 0, 0, &Argument);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_STRING("InvalidArg", Argument.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Methods.Calculate.nIn0", Argument.Value);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Argument.nMethodIndex = METHOD_IDX_INV_ARG_NAME;
	RcMonitor.Argument.bOutput = 0;
	RcMonitor.Argument.nArgumentIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.Argument.nMonitorStatus);
	TEST_ASSERT_EQUAL_STRING("InvalidArg", RcMonitor.Argument.Argument.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Methods.Calculate.nIn0", RcMonitor.Argument.Argument.Value);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_GetArgumentIn_InvalidVarName(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_GetArgumentIn_InvalidVarName", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Argument, 0, sizeof(Argument));
	uintOut = BrbUaRcGetArgument(&RunClient, METHOD_IDX_INV_VAR_NAME, 0, 1, &Argument);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_STRING("nIn1", Argument.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Methods.Calculate.InvalidVar", Argument.Value);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Argument.nMethodIndex = METHOD_IDX_INV_VAR_NAME;
	RcMonitor.Argument.bOutput = 0;
	RcMonitor.Argument.nArgumentIndex = 1;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.Argument.nMonitorStatus);
	TEST_ASSERT_EQUAL_STRING("nIn1", RcMonitor.Argument.Argument.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Methods.Calculate.InvalidVar", RcMonitor.Argument.Argument.Value);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_GetArgumentIn_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_GetArgumentIn_Ok", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Argument, 0, sizeof(Argument));
	uintOut = BrbUaRcGetArgument(&RunClient, METHOD_IDX_CALCULATE_OK, 0, 1, &Argument);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_STRING("nIn1", Argument.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Methods.Calculate.nIn1", Argument.Value);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Argument.nMethodIndex = METHOD_IDX_CALCULATE_OK;
	RcMonitor.Argument.bOutput = 0;
	RcMonitor.Argument.nArgumentIndex = 1;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.Argument.nMonitorStatus);
	TEST_ASSERT_EQUAL_STRING("nIn1", RcMonitor.Argument.Argument.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Methods.Calculate.nIn1", RcMonitor.Argument.Argument.Value);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_GetArgumentOut_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_GetArgumentOut_NulPtr", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRcGetArgument(0, 0, 1, 0, &Argument);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);
	
	uintOut = BrbUaRcGetArgument(&RunClient, 0, 1, 0, 0);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_GetArgumentOut_InvalidArgIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_GetArgumentOut_InvalidArgIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Argument, 0, sizeof(Argument));
	uintOut = BrbUaRcGetArgument(&RunClient, 0, 1, 99, &Argument);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Argument.nMethodIndex = 0;
	RcMonitor.Argument.bOutput = 1;
	RcMonitor.Argument.nArgumentIndex = 99;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.Argument.nMonitorStatus);
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_GetArgumentOut_InvalidArgName(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_GetArgumentOut_InvalidArgName", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Argument, 0, sizeof(Argument));
	uintOut = BrbUaRcGetArgument(&RunClient, METHOD_IDX_INV_ARG_NAME, 1, 0, &Argument);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_STRING("InvalidArg", Argument.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Methods.Calculate.nOut0", Argument.Value);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Argument.nMethodIndex = METHOD_IDX_INV_ARG_NAME;
	RcMonitor.Argument.bOutput = 1;
	RcMonitor.Argument.nArgumentIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.Argument.nMonitorStatus);
	TEST_ASSERT_EQUAL_STRING("InvalidArg", RcMonitor.Argument.Argument.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Methods.Calculate.nOut0", RcMonitor.Argument.Argument.Value);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_GetArgumentOut_InvalidVarName(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_GetArgumentOut_InvalidVarName", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Argument, 0, sizeof(Argument));
	uintOut = BrbUaRcGetArgument(&RunClient, METHOD_IDX_INV_VAR_NAME, 1, 1, &Argument);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_STRING("nOut1", Argument.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Methods.Calculate.InvalidVar", Argument.Value);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Argument.nMethodIndex = METHOD_IDX_INV_VAR_NAME;
	RcMonitor.Argument.bOutput = 1;
	RcMonitor.Argument.nArgumentIndex = 1;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.Argument.nMonitorStatus);
	TEST_ASSERT_EQUAL_STRING("nOut1", RcMonitor.Argument.Argument.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Methods.Calculate.InvalidVar", RcMonitor.Argument.Argument.Value);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_GetArgumentOut_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_GetArgumentOut_Ok", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Argument, 0, sizeof(Argument));
	uintOut = BrbUaRcGetArgument(&RunClient, METHOD_IDX_CALCULATE_OK, 1, 1, &Argument);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_STRING("nOut1", Argument.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Methods.Calculate.nOut1", Argument.Value);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Argument.nMethodIndex = METHOD_IDX_CALCULATE_OK;
	RcMonitor.Argument.bOutput = 1;
	RcMonitor.Argument.nArgumentIndex = 1;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.Argument.nMonitorStatus);
	TEST_ASSERT_EQUAL_STRING("nOut1", RcMonitor.Argument.Argument.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.Methods.Calculate.nOut1", RcMonitor.Argument.Argument.Value);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_CallMethod_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_CallMethod_NulPtr", sizeof(sCurrentUnitTest));

	fbBrbUaRcCallMethod.pRunClient = 0;
	fbBrbUaRcCallMethod.nMethodIndex = 4;
	BrbUaRcCallMethod(&fbBrbUaRcCallMethod);
	TEST_BUSY_CONDITION(fbBrbUaRcCallMethod.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, fbBrbUaRcCallMethod.nStatus);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_CallMethod_InvalidMethodIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_CallMethod_InvalidMethodIndex", sizeof(sCurrentUnitTest));

	fbBrbUaRcCallMethod.pRunClient = &RunClient;
	fbBrbUaRcCallMethod.nMethodIndex = 99;
	BrbUaRcCallMethod(&fbBrbUaRcCallMethod);
	TEST_BUSY_CONDITION(fbBrbUaRcCallMethod.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, fbBrbUaRcCallMethod.nStatus);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_CallMethod_InvalidNamespaceIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_CallMethod_InvalidNamespaceIndex", sizeof(sCurrentUnitTest));

	fbBrbUaRcCallMethod.pRunClient = &RunClient;
	fbBrbUaRcCallMethod.nMethodIndex = METHOD_IDX_INV_NS;
	BrbUaRcCallMethod(&fbBrbUaRcCallMethod);
	if(fbBrbUaRcCallMethod.bInit == 1)
	{
		// Eing�nge besetzen
		memset(&Data.Methods.Calculate, 0, sizeof(Data.Methods.Calculate));
		Data.Methods.Calculate.nIn0 = 4;
		Data.Methods.Calculate.nIn1 = 6;
	}
	TEST_BUSY_CONDITION(fbBrbUaRcCallMethod.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_ERROR, fbBrbUaRcCallMethod.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0xA00D0000, fbBrbUaRcCallMethod.nErrorId); // PlcOpen_BadMethodInvalidHdl
	TEST_ASSERT_EQUAL_STRING("0xA00D0000 = PlcOpen_BadMethodInvalidHdl", fbBrbUaRcCallMethod.sErrorId);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_CallMethod_InvalidObjectIdentifier(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_CallMethod_InvalidObjectIdentifier", sizeof(sCurrentUnitTest));

	fbBrbUaRcCallMethod.pRunClient = &RunClient;
	fbBrbUaRcCallMethod.nMethodIndex = METHOD_IDX_INV_OBJ_ID;
	BrbUaRcCallMethod(&fbBrbUaRcCallMethod);
	if(fbBrbUaRcCallMethod.bInit == 1)
	{
		// Eing�nge besetzen
		memset(&Data.Methods.Calculate, 0, sizeof(Data.Methods.Calculate));
		Data.Methods.Calculate.nIn0 = 4;
		Data.Methods.Calculate.nIn1 = 6;
	}
	TEST_BUSY_CONDITION(fbBrbUaRcCallMethod.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_ERROR, fbBrbUaRcCallMethod.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x80750000, fbBrbUaRcCallMethod.nErrorId); // Bad_MethodInvalid
	TEST_ASSERT_EQUAL_STRING("0x80750000 = Bad_MethodInvalid", fbBrbUaRcCallMethod.sErrorId);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_CallMethod_InvalidMethodIdentifier(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_CallMethod_InvalidMethodIdentifier", sizeof(sCurrentUnitTest));

	fbBrbUaRcCallMethod.pRunClient = &RunClient;
	fbBrbUaRcCallMethod.nMethodIndex = METHOD_IDX_INV_METH_ID;
	BrbUaRcCallMethod(&fbBrbUaRcCallMethod);
	if(fbBrbUaRcCallMethod.bInit == 1)
	{
		// Eing�nge besetzen
		memset(&Data.Methods.Calculate, 0, sizeof(Data.Methods.Calculate));
		Data.Methods.Calculate.nIn0 = 4;
		Data.Methods.Calculate.nIn1 = 6;
	}
	TEST_BUSY_CONDITION(fbBrbUaRcCallMethod.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_ERROR, fbBrbUaRcCallMethod.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0xA00D0000, fbBrbUaRcCallMethod.nErrorId); // PlcOpen_BadMethodInvalidHdl
	TEST_ASSERT_EQUAL_STRING("0xA00D0000 = PlcOpen_BadMethodInvalidHdl", fbBrbUaRcCallMethod.sErrorId);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_CallMethod_InvalidArgName(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_CallMethod_InvalidArgName", sizeof(sCurrentUnitTest));

	fbBrbUaRcCallMethod.pRunClient = &RunClient;
	fbBrbUaRcCallMethod.nMethodIndex = METHOD_IDX_INV_ARG_NAME;
	BrbUaRcCallMethod(&fbBrbUaRcCallMethod);
	if(fbBrbUaRcCallMethod.bInit == 1)
	{
		// Eing�nge besetzen
		memset(&Data.Methods.Calculate, 0, sizeof(Data.Methods.Calculate));
		Data.Methods.Calculate.nIn0 = 4;
		Data.Methods.Calculate.nIn1 = 6;
	}
	TEST_BUSY_CONDITION(fbBrbUaRcCallMethod.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_ERROR, fbBrbUaRcCallMethod.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x80AB0000, fbBrbUaRcCallMethod.nErrorId); // Bad_InvalidArgument
	TEST_ASSERT_EQUAL_STRING("0x80AB0000 = Bad_InvalidArgument", fbBrbUaRcCallMethod.sErrorId);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_CallMethod_InvalidVarName(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_CallMethod_InvalidVarName", sizeof(sCurrentUnitTest));

	fbBrbUaRcCallMethod.pRunClient = &RunClient;
	fbBrbUaRcCallMethod.nMethodIndex = METHOD_IDX_INV_VAR_NAME;
	BrbUaRcCallMethod(&fbBrbUaRcCallMethod);
	if(fbBrbUaRcCallMethod.bInit == 1)
	{
		// Eing�nge besetzen
		memset(&Data.Methods.Calculate, 0, sizeof(Data.Methods.Calculate));
		Data.Methods.Calculate.nIn0 = 4;
		Data.Methods.Calculate.nIn1 = 6;
	}
	TEST_BUSY_CONDITION(fbBrbUaRcCallMethod.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_ERROR, fbBrbUaRcCallMethod.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x80040000, fbBrbUaRcCallMethod.nErrorId); // Bad_ResourceUnavailable
	TEST_ASSERT_EQUAL_STRING("0x80040000 = Bad_ResourceUnavailable", fbBrbUaRcCallMethod.sErrorId);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_CallMethod_DatatypeMismatch(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_CallMethod_DatatypeMismatch", sizeof(sCurrentUnitTest));

	fbBrbUaRcCallMethod.pRunClient = &RunClient;
	fbBrbUaRcCallMethod.nMethodIndex = METHOD_IDX_INV_DATATYPE;
	BrbUaRcCallMethod(&fbBrbUaRcCallMethod);
	if(fbBrbUaRcCallMethod.bInit == 1)
	{
		// Eing�nge besetzen
		memset(&Data.Methods.Calculate, 0, sizeof(Data.Methods.Calculate));
		Data.Methods.Calculate.nIn0 = 4;
		Data.Methods.Calculate.nIn1 = 6;
	}
	TEST_BUSY_CONDITION(fbBrbUaRcCallMethod.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_ERROR, fbBrbUaRcCallMethod.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x80740000, fbBrbUaRcCallMethod.nErrorId); // Bad_TypeMismatch
	TEST_ASSERT_EQUAL_STRING("0x80740000 = Bad_TypeMismatch", fbBrbUaRcCallMethod.sErrorId);
	TEST_ASSERT_EQUAL_INT(nCallCount, fbBrbUaRcCallMethod.nCallCount);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_CallMethod_InputArgs11(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_CallMethod_InputArgs11", sizeof(sCurrentUnitTest));

	// Wenn mehr als 10 Argumente angegeben sind, wird auf 10 korrigiert
	fbBrbUaRcCallMethod.pRunClient = &RunClient;
	fbBrbUaRcCallMethod.nMethodIndex = METHOD_IDX_INPUTARGS_11;
	BrbUaRcCallMethod(&fbBrbUaRcCallMethod);
	if(fbBrbUaRcCallMethod.bInit == 1)
	{
		// Eing�nge besetzen
		memset(&Data.Methods.Calculate, 0, sizeof(Data.Methods.Calculate));
		Data.Methods.Args10.nIn0 = (UINT)BrbGetRandomUdint(0,65535);
	}
	TEST_BUSY_CONDITION(fbBrbUaRcCallMethod.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRcCallMethod.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, fbBrbUaRcCallMethod.nErrorId); // Good
	TEST_ASSERT_EQUAL_STRING("0x00000000 = Good", fbBrbUaRcCallMethod.sErrorId);
	nCallCount++;
	TEST_ASSERT_EQUAL_INT(nCallCount, fbBrbUaRcCallMethod.nCallCount);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_CallMethod_OutputArgs11(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_CallMethod_OutputArgs11", sizeof(sCurrentUnitTest));

	// Wenn mehr als 10 Argumente angegeben sind, wird auf 10 korrigiert
	fbBrbUaRcCallMethod.pRunClient = &RunClient;
	fbBrbUaRcCallMethod.nMethodIndex = METHOD_IDX_OUTPUTARGS11;
	BrbUaRcCallMethod(&fbBrbUaRcCallMethod);
	if(fbBrbUaRcCallMethod.bInit == 1)
	{
		// Eing�nge besetzen
		memset(&Data.Methods.Calculate, 0, sizeof(Data.Methods.Calculate));
		Data.Methods.Args10.nIn0 = (UINT)BrbGetRandomUdint(0,65535);
	}
	TEST_BUSY_CONDITION(fbBrbUaRcCallMethod.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRcCallMethod.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, fbBrbUaRcCallMethod.nErrorId); // Good
	TEST_ASSERT_EQUAL_STRING("0x00000000 = Good", fbBrbUaRcCallMethod.sErrorId);
	nCallCount++;
	TEST_ASSERT_EQUAL_INT(nCallCount, fbBrbUaRcCallMethod.nCallCount);

	// Finished
	TEST_DONE;
}

// Komischerweise wird manchmal nicht mit "0x800A0000 = Bad_Timeout" geantwortet, sondern mit "0x80AD0000 = Bad_Disconnect"!
// Deshalb ist dieser Test deaktiviert
_TEST BrbUaRcMethods_CallMethod_Wait_Timeout(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_CallMethod_Wait_Timeout", sizeof(sCurrentUnitTest));

	/*
	fbBrbUaRcCallMethod.pRunClient = &RunClient;
	fbBrbUaRcCallMethod.nMethodIndex = METHOD_IDX_WAIT_OK;
	BrbUaRcCallMethod(&fbBrbUaRcCallMethod);
	if(fbBrbUaRcCallMethod.bInit == 1)
	{
		// Eing�nge besetzen
		memset(&Data.Methods.Wait, 0, sizeof(Data.Methods.Wait));
		Data.Methods.Wait.nWaitMs = 600;
	}
	TEST_BUSY_CONDITION(fbBrbUaRcCallMethod.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_ERROR, fbBrbUaRcCallMethod.nStatus);
	// Komischerweise wird manchmal nicht mit "0x800A0000 = Bad_Timeout" geantwortet, sondern mit "0x80AD0000 = Bad_Disconnect"!
	//BRB_ASSERT_EQUAL_UDINT(0x80AD0000, fbBrbUaRcCallMethod.nErrorId); // Bad_Disconnect
	//TEST_ASSERT_EQUAL_STRING("0x80AD0000 = Bad_Disconnect", fbBrbUaRcCallMethod.sErrorId);
	BRB_ASSERT_EQUAL_UDINT(0x800A0000, fbBrbUaRcCallMethod.nErrorId); // Bad_Timeout
	TEST_ASSERT_EQUAL_STRING("0x800A0000 = Bad_Timeout", fbBrbUaRcCallMethod.sErrorId);
	TEST_ASSERT_EQUAL_INT(nCallCount, fbBrbUaRcCallMethod.nCallCount);
	*/

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_CallMethod_Wait_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_CallMethod_Wait_Ok", sizeof(sCurrentUnitTest));

	fbBrbUaRcCallMethod.pRunClient = &RunClient;
	fbBrbUaRcCallMethod.nMethodIndex = METHOD_IDX_WAIT_OK;
	BrbUaRcCallMethod(&fbBrbUaRcCallMethod);
	if(fbBrbUaRcCallMethod.bInit == 1)
	{
		// Eing�nge besetzen
		memset(&Data.Methods.Wait, 0, sizeof(Data.Methods.Wait));
		Data.Methods.Wait.nWaitMs = 200;
	}
	TEST_BUSY_CONDITION(fbBrbUaRcCallMethod.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRcCallMethod.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, fbBrbUaRcCallMethod.nErrorId); // Good
	TEST_ASSERT_EQUAL_STRING("0x00000000 = Good", fbBrbUaRcCallMethod.sErrorId);
	nCallCount++;
	TEST_ASSERT_EQUAL_INT(nCallCount, fbBrbUaRcCallMethod.nCallCount);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_CallMethod_Calculate_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_CallMethod_Calculate_Ok", sizeof(sCurrentUnitTest));

	fbBrbUaRcCallMethod.pRunClient = &RunClient;
	fbBrbUaRcCallMethod.nMethodIndex = METHOD_IDX_CALCULATE_OK;
	BrbUaRcCallMethod(&fbBrbUaRcCallMethod);
	if(fbBrbUaRcCallMethod.bInit == 1)
	{
		// Eing�nge besetzen
		memset(&Data.Methods.Calculate, 0, sizeof(Data.Methods.Calculate));
		Data.Methods.Calculate.nIn0 = 4;
		Data.Methods.Calculate.nIn1 = 6;
	}
	TEST_BUSY_CONDITION(fbBrbUaRcCallMethod.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRcCallMethod.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, fbBrbUaRcCallMethod.nErrorId); // Good
	TEST_ASSERT_EQUAL_STRING("0x00000000 = Good", fbBrbUaRcCallMethod.sErrorId);
	nCallCount++;
	TEST_ASSERT_EQUAL_INT(nCallCount, fbBrbUaRcCallMethod.nCallCount);
	TEST_ASSERT_EQUAL_INT(10, Data.Methods.Calculate.nOut0);
	TEST_ASSERT_EQUAL_INT(24, Data.Methods.Calculate.nOut1);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_CallMethod_Args0_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_CallMethod_Args0_Ok", sizeof(sCurrentUnitTest));

	fbBrbUaRcCallMethod.pRunClient = &RunClient;
	fbBrbUaRcCallMethod.nMethodIndex = METHOD_IDX_ARGS0_OK;
	BrbUaRcCallMethod(&fbBrbUaRcCallMethod);
	if(fbBrbUaRcCallMethod.bInit == 1)
	{
		// Eing�nge besetzen
	}
	TEST_BUSY_CONDITION(fbBrbUaRcCallMethod.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRcCallMethod.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, fbBrbUaRcCallMethod.nErrorId); // Good
	TEST_ASSERT_EQUAL_STRING("0x00000000 = Good", fbBrbUaRcCallMethod.sErrorId);
	nCallCount++;
	TEST_ASSERT_EQUAL_INT(nCallCount, fbBrbUaRcCallMethod.nCallCount);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcMethods_CallMethod_Args10_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcMethods.BrbUaRcMethods_CallMethod_Args10_Ok", sizeof(sCurrentUnitTest));

	fbBrbUaRcCallMethod.pRunClient = &RunClient;
	fbBrbUaRcCallMethod.nMethodIndex = METHOD_IDX_ARGS10_OK;
	BrbUaRcCallMethod(&fbBrbUaRcCallMethod);
	if(fbBrbUaRcCallMethod.bInit == 1)
	{
		// Eing�nge besetzen
		memset(&Data.Methods.Args10, 0, sizeof(Data.Methods.Args10));
		Data.Methods.Args10.nIn0 = (UINT)BrbGetRandomUdint(0,65535);
	}
	TEST_BUSY_CONDITION(fbBrbUaRcCallMethod.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRcCallMethod.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, fbBrbUaRcCallMethod.nErrorId); // Good
	TEST_ASSERT_EQUAL_STRING("0x00000000 = Good", fbBrbUaRcCallMethod.sErrorId);
	nCallCount++;
	TEST_ASSERT_EQUAL_INT(nCallCount, fbBrbUaRcCallMethod.nCallCount);
	TEST_ASSERT_EQUAL_INT(Data.Methods.Args10.nIn0, Data.Methods.Args10.nOut0);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-03-18 15:16:33Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaRcMethods_GetMethod_NulPtr", BrbUaRcMethods_GetMethod_NulPtr), 
	new_TestFixture("BrbUaRcMethods_GetMethod_InvalidMethodIndex", BrbUaRcMethods_GetMethod_InvalidMethodIndex), 
	new_TestFixture("BrbUaRcMethods_GetMethod_InvalidNamespaceIndex", BrbUaRcMethods_GetMethod_InvalidNamespaceIndex), 
	new_TestFixture("BrbUaRcMethods_GetMethod_InvalidObjectIdentifier", BrbUaRcMethods_GetMethod_InvalidObjectIdentifier), 
	new_TestFixture("BrbUaRcMethods_GetMethod_InvalidMethodIdentifier", BrbUaRcMethods_GetMethod_InvalidMethodIdentifier), 
	new_TestFixture("BrbUaRcMethods_GetMethod_OK", BrbUaRcMethods_GetMethod_OK), 
	new_TestFixture("BrbUaRcMethods_GetArgumentIn_NulPtr", BrbUaRcMethods_GetArgumentIn_NulPtr), 
	new_TestFixture("BrbUaRcMethods_GetArgumentIn_InvalidArgIndex", BrbUaRcMethods_GetArgumentIn_InvalidArgIndex), 
	new_TestFixture("BrbUaRcMethods_GetArgumentIn_InvalidArgName", BrbUaRcMethods_GetArgumentIn_InvalidArgName), 
	new_TestFixture("BrbUaRcMethods_GetArgumentIn_InvalidVarName", BrbUaRcMethods_GetArgumentIn_InvalidVarName), 
	new_TestFixture("BrbUaRcMethods_GetArgumentIn_Ok", BrbUaRcMethods_GetArgumentIn_Ok), 
	new_TestFixture("BrbUaRcMethods_GetArgumentOut_NulPtr", BrbUaRcMethods_GetArgumentOut_NulPtr), 
	new_TestFixture("BrbUaRcMethods_GetArgumentOut_InvalidArgIndex", BrbUaRcMethods_GetArgumentOut_InvalidArgIndex), 
	new_TestFixture("BrbUaRcMethods_GetArgumentOut_InvalidArgName", BrbUaRcMethods_GetArgumentOut_InvalidArgName), 
	new_TestFixture("BrbUaRcMethods_GetArgumentOut_InvalidVarName", BrbUaRcMethods_GetArgumentOut_InvalidVarName), 
	new_TestFixture("BrbUaRcMethods_GetArgumentOut_Ok", BrbUaRcMethods_GetArgumentOut_Ok), 
	new_TestFixture("BrbUaRcMethods_CallMethod_NulPtr", BrbUaRcMethods_CallMethod_NulPtr), 
	new_TestFixture("BrbUaRcMethods_CallMethod_InvalidMethodIndex", BrbUaRcMethods_CallMethod_InvalidMethodIndex), 
	new_TestFixture("BrbUaRcMethods_CallMethod_InvalidNamespaceIndex", BrbUaRcMethods_CallMethod_InvalidNamespaceIndex), 
	new_TestFixture("BrbUaRcMethods_CallMethod_InvalidObjectIdentifier", BrbUaRcMethods_CallMethod_InvalidObjectIdentifier), 
	new_TestFixture("BrbUaRcMethods_CallMethod_InvalidMethodIdentifier", BrbUaRcMethods_CallMethod_InvalidMethodIdentifier), 
	new_TestFixture("BrbUaRcMethods_CallMethod_InvalidArgName", BrbUaRcMethods_CallMethod_InvalidArgName), 
	new_TestFixture("BrbUaRcMethods_CallMethod_InvalidVarName", BrbUaRcMethods_CallMethod_InvalidVarName), 
	new_TestFixture("BrbUaRcMethods_CallMethod_DatatypeMismatch", BrbUaRcMethods_CallMethod_DatatypeMismatch), 
	new_TestFixture("BrbUaRcMethods_CallMethod_InputArgs11", BrbUaRcMethods_CallMethod_InputArgs11), 
	new_TestFixture("BrbUaRcMethods_CallMethod_OutputArgs11", BrbUaRcMethods_CallMethod_OutputArgs11), 
	new_TestFixture("BrbUaRcMethods_CallMethod_Wait_Timeout", BrbUaRcMethods_CallMethod_Wait_Timeout), 
	new_TestFixture("BrbUaRcMethods_CallMethod_Wait_Ok", BrbUaRcMethods_CallMethod_Wait_Ok), 
	new_TestFixture("BrbUaRcMethods_CallMethod_Calculate_Ok", BrbUaRcMethods_CallMethod_Calculate_Ok), 
	new_TestFixture("BrbUaRcMethods_CallMethod_Args0_Ok", BrbUaRcMethods_CallMethod_Args0_Ok), 
	new_TestFixture("BrbUaRcMethods_CallMethod_Args10_Ok", BrbUaRcMethods_CallMethod_Args10_Ok), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaRcMethods, "Set_BrbUaRcMethods", 0, 0, fixtures, setupSet, 0, cyclicSetCaller);

