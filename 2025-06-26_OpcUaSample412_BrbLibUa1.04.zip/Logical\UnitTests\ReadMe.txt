Die AS-Solution 'UnitTest' ist eine Unterst�tzung f�r wiederholbare Aufruf-Tests.
Dabei sind Test-Routinen implementiert, welche ihrerseits Bibliotheks-Funktionen mit definierten Eingangs-Werten aufrufen,
die zur�ckgegebenen Ausg�nge pr�fen und so einen Bericht erstellen. Entspricht ein Ausgang nicht dem erwarteten Ergebnis,
wird dies im Bericht vermerkt.
Das Aufrufen aller Test-Routinen kann mit wenigen Mausklicks ausgef�hrt werden. So kann nach �nderung oder Erweiterung einer
Funktion sehr schnell deren Kompatibilit�t und Funktionst�chtigkeit gepr�ft werden, was zu einer Erh�hung der SW-Qualit�t f�hrt.
F�r das Beispiel zur Nutzung der gepr�ften Bibliothek sind die UnitTests nicht von Belang.