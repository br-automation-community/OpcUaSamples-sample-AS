/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer
 ********************************************************************
 * Library: BrbLib
 * File: BrbStringConvertRealToExp.c
 * Author: niedermeierr
 * Created: December 03, 2013
 ********************************************************************
 * Implementation of library BrbLib
 ********************************************************************/

#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLib.h"
#include <string.h>
#include <stdlib.h>

#ifdef __cplusplus
	};
#endif

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/* Konvertiert einen Real-Wert in eine exponentielle Notation */
unsigned short BrbStringConvertRealToExp(plcstring* pValue, plcstring* pResult, unsigned long nResultSize) // NOLINT(readability-function-cognitive-complexity)
{
	memset(pResult, 0, nResultSize);
	UDINT nValueLen = strlen(pValue);
	STRING* pExpStart = BrbStringGetAdrOf(pValue, "e", nValueLen);
	if(pExpStart == 0)
	{
		// "e" nicht enthalten
		brsstrcpy((UDINT)pResult, (UDINT)pValue);
		// Vorzeichen l�schen
		BrbStringTrimLeft(pResult, "+");
		BOOL bMinus = 0;
		if(BrbStringStartsWith(pResult, "-") == 1)
		{
			bMinus = 1;
			BrbStringTrimLeft(pResult, "-");
		}
		// F�hrende Nullen l�schen
		BrbStringTrimLeft(pResult, "0");
		// Null vor dem Punkt wieder einf�gen
		if(BrbStringStartsWith(pResult, ".") == 1)
		{
			BrbStringInsert(pResult, 0, "0");
		}
		else if(brsstrlen((UDINT)pResult) == 0)
		{
			brsstrcat((UDINT)pResult, (UDINT)&"0.0");
		}
		// Folgende Nullen nach dem Punkt l�schen
		UDINT nLen = strlen(pResult);
		STRING* pDot = BrbStringGetAdrOf(pResult, ".", nLen);
		if(pDot > pResult)
		{
			BrbStringTrimRight(pResult, "0");
			if(BrbStringEndsWith(pResult, ".") == 1)
			{
				brsstrcat((UDINT)pResult, (UDINT)&"0");
			}
			nLen = strlen(pResult);
			pDot = BrbStringGetAdrOf(pResult, ".", nLen);
		}
		// Vorzeichen des Exponenten feststellen
		BOOL bExpMinus = 0;
		if(BrbStringStartsWith(pResult, "0") == 1)
		{
			// 0.0012345
			// Erstes Zeichen ist "0" -> Exponent negativ
			bExpMinus = 1;
		}
		else
		{
			// 123.45
			// Erstes Zeichen ist keine "0" -> Exponent positiv
			bExpMinus = 0;
		}
		// Exponent feststellen
		DINT nExp = 0;
		if(bExpMinus == 1)
		{
			// Negativer Exponent
			if(pDot > pResult)
			{
				// Punkt enthalten
				nExp = 1;
				USINT* pChar = 0;
				USINT* pEnd =(USINT*)pResult + nLen - 1;
				// Anzahl der Nullen vom Punkt bis zur ersten relevanten Ziffer
				for(pChar=(USINT*)pDot+1; pChar<=pEnd; pChar++)
				{
					if(*pChar == 48)
					{
						nExp += 1;
					}
					else
					{
						break;
					}
				}
				UDINT nDotDigit = (UDINT)pDot - (UDINT)pResult;
				UDINT nCutLen = nDotDigit + (UDINT)nExp;
				// Alle Zeichen bis zur ersten relevanten Ziffer l�schen
				BrbStringCut(pResult, 0, nCutLen, 0);
			}
			else
			{
				// Punkt nicht enthalten
				nExp = 0;
			}
		}
		else
		{
			// Positiver Exponent
			if(pDot > pResult)
			{
				// Punkt enthalten
				DINT nDotDigit = (DINT)((UDINT)pDot - (UDINT)pResult);
				nExp = nDotDigit - 1;
				// Punkt l�schen
				BrbStringReplace(pResult, ".", "");
			}
			else
			{
				// Punkt nicht enthalten
				nExp = (DINT)nLen - 1;
			}
		}
		if(brsstrlen((UDINT)pResult) == 0)
		{
			brsstrcat((UDINT)pResult, (UDINT)&"0.0e+000");
		}
		else
		{
			// Punkt an 2. Stelle einf�gen (1 Vorkomma-Stelle)
			BrbStringInsert(pResult, 1, ".");
			// Folgende Nullen l�schen
			BrbStringTrimRight(pResult, "0");
			// "e" anh�ngen
			brsstrcat((UDINT)pResult, (UDINT)&"e");
			// Exponent-Vorzeichen
			if(bExpMinus == 0)
			{
				brsstrcat((UDINT)pResult, (UDINT)&"+");
			}
			else
			{
				brsstrcat((UDINT)pResult, (UDINT)&"-");
			}
			// Exponent mit mindestens 3 Stellen anh�ngen
			STRING sExp[50];
			brsitoa(nExp, (UDINT)&sExp);
			BrbStringPadLeft(sExp, "0", 3);
			brsstrcat((UDINT)pResult, (UDINT)&sExp);
			// Vorzeichen einf�gen
			if(bMinus == 1)
			{
				BrbStringInsert(pResult, 0, "-");
			}
		}
	}
	else
	{
		// "e" enthalten
		STRING sTemp[nResultSize];
		BrbStringConvertRealFromExp(pValue, sTemp, sizeof(sTemp));
		BrbStringConvertRealToExp(sTemp, pResult, nResultSize);
	}
	return eBRB_ERR_OK;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)
