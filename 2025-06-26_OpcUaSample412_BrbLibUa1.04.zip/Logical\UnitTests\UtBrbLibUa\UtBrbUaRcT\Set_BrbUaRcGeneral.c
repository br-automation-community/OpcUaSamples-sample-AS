#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_SETUP_SET(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcGeneral._SETUP_SET", sizeof(sCurrentUnitTest));

	CyclicMonitor.bEnable = 1;

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcGeneral_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcGeneral.BrbUaRcGeneral_NulPtr", sizeof(sCurrentUnitTest));

	// Init
	memset(&RunClient, 0, sizeof(RunClient));
	brsstrcpy((UDINT)&RunClient.Cfg.sCfgDataObjName, (UDINT)&"UtRc");
	memset(&fbBrbUaRunClientInit, 0, sizeof(fbBrbUaRunClientInit));
	do
	{
		fbBrbUaRunClientInit.pRunClient = 0;
		BrbUaRunClientInit(&fbBrbUaRunClientInit);
	} while(fbBrbUaRunClientInit.nStatus == eBRB_ERR_BUSY);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, fbBrbUaRunClientInit.nStatus);

	// Cyclic
	memset(&fbBrbUaRunClientCyclic, 0, sizeof(fbBrbUaRunClientCyclic));
	do
	{
		fbBrbUaRunClientCyclic.pRunClient = 0;
		BrbUaRunClientCyclic(&fbBrbUaRunClientCyclic);
	} while(fbBrbUaRunClientCyclic.nStatus == eBRB_ERR_OK);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, fbBrbUaRunClientCyclic.nStatus);

	// Exit
	memset(&fbBrbUaRunClientExit, 0, sizeof(fbBrbUaRunClientExit));
	do
	{
		fbBrbUaRunClientExit.pRunClient = 0;
		BrbUaRunClientExit(&fbBrbUaRunClientExit);
	} while(fbBrbUaRunClientExit.nStatus == eBRB_ERR_BUSY);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, fbBrbUaRunClientExit.nStatus);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcGeneral_InvalidDataObjectName(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcGeneral.BrbUaRcGeneral_InvalidDataObjectName", sizeof(sCurrentUnitTest));

	// Init
	memset(&RunClient, 0, sizeof(RunClient));
	brsstrcpy((UDINT)&RunClient.Cfg.sCfgDataObjName, (UDINT)&"UtInvalid");
	memset(&fbBrbUaRunClientInit, 0, sizeof(fbBrbUaRunClientInit));
	do
	{
		fbBrbUaRunClientInit.pRunClient = &RunClient;
		BrbUaRunClientInit(&fbBrbUaRunClientInit);
	} while(fbBrbUaRunClientInit.nStatus == eBRB_ERR_BUSY);
	TEST_ASSERT_EQUAL_INT(doERR_MODULNOTFOUND, fbBrbUaRunClientInit.nStatus);
	TEST_ASSERT_EQUAL_INT(doERR_MODULNOTFOUND, RunClient.State.nErrorId);
	TEST_ASSERT_EQUAL_STRING("Init error on getting data object info", RunClient.State.sErrorText);

	// Exit
	memset(&fbBrbUaRunClientExit, 0, sizeof(fbBrbUaRunClientExit));
	do
	{
		fbBrbUaRunClientExit.pRunClient = 0;
		BrbUaRunClientExit(&fbBrbUaRunClientExit);
	} while(fbBrbUaRunClientExit.nStatus == eBRB_ERR_BUSY);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcGeneral_InitNotDone(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcGeneral.BrbUaRcGeneral_InitNotDone", sizeof(sCurrentUnitTest));

	memset(&RunClient, 0, sizeof(RunClient));
	// Cyclic
	memset(&fbBrbUaRunClientCyclic, 0, sizeof(fbBrbUaRunClientCyclic));
	do
	{
		fbBrbUaRunClientCyclic.pRunClient = &RunClient;
		BrbUaRunClientCyclic(&fbBrbUaRunClientCyclic);
	} while(fbBrbUaRunClientCyclic.nStatus == eBRB_ERR_OK);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_INVALID_PARAMETER, fbBrbUaRunClientCyclic.nStatus);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-03-15 11:38:32Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaRcGeneral_NulPtr", BrbUaRcGeneral_NulPtr), 
	new_TestFixture("BrbUaRcGeneral_InvalidDataObjectName", BrbUaRcGeneral_InvalidDataObjectName), 
	new_TestFixture("BrbUaRcGeneral_InitNotDone", BrbUaRcGeneral_InitNotDone), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaRcGeneral, "Set_BrbUaRcGeneral", 0, 0, fixtures, setupSet, 0, 0);

