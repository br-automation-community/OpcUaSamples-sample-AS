/* Automation Studio generated header file */
/* Do not edit ! */

#ifndef _FXPUBSUB_
#define _FXPUBSUB_
#ifdef __cplusplus
extern "C" 
{
#endif

#include <bur/plctypes.h>

#ifndef _BUR_PUBLIC
#define _BUR_PUBLIC
#endif
/* Datatypes and datatypes of function blocks */
typedef enum FxPubSubCtlStateEnum
{	fxPUBSUB_CTL_STATE_STOPPED = 0,
	fxPUBSUB_CTL_STATE_RUNNING = 1,
	fxPUBSUB_CTL_STATE_UNINITIALIZED = 2
} FxPubSubCtlStateEnum;

typedef struct FxPubSubControlStart
{
	/* VAR_OUTPUT (analog) */
	signed long StatusID;
	/* VAR (analog) */
	unsigned long Internal[32];
	/* VAR_INPUT (digital) */
	plcbit Execute;
	/* VAR_OUTPUT (digital) */
	plcbit Done;
	plcbit Busy;
	plcbit Error;
} FxPubSubControlStart_typ;

typedef struct FxPubSubControlStop
{
	/* VAR_OUTPUT (analog) */
	signed long StatusID;
	/* VAR (analog) */
	unsigned long Internal[32];
	/* VAR_INPUT (digital) */
	plcbit Execute;
	/* VAR_OUTPUT (digital) */
	plcbit Done;
	plcbit Busy;
	plcbit Error;
} FxPubSubControlStop_typ;



/* Prototyping of functions and function blocks */
_BUR_PUBLIC void FxPubSubControlStart(struct FxPubSubControlStart* inst);
_BUR_PUBLIC void FxPubSubControlStop(struct FxPubSubControlStop* inst);
_BUR_PUBLIC unsigned long FxPubSubMessagesSent(void);
_BUR_PUBLIC unsigned long FxPubSubMessagesSentFailed(void);
_BUR_PUBLIC unsigned long FxPubSubMessagesReceived(void);
_BUR_PUBLIC unsigned long FxPubSubMessagesReceivedInvalid(void);
_BUR_PUBLIC unsigned long FxPubSubDataSetWriterFailed(void);
_BUR_PUBLIC unsigned long FxPubSubDataSetReaderFailed(void);
_BUR_PUBLIC FxPubSubCtlStateEnum FxPubSubControlGetState(void);


/* Constants */
#ifdef _REPLACE_CONST
 #define fxPUBSUB_ERR_IN_PROGRESS (-1038015704)
 #define fxPUBSUB_ERR_NO_TASK (-1038015703)
 #define fxPUBSUB_ERR_STARTUP_FAILED (-1038015702)
 #define fxPUBSUB_ERR_TRANSFER (-1038015701)
 #define fxPUBSUB_WRN_NO_STATE_CHANGE (-2111757524)
#else
 _GLOBAL_CONST signed long fxPUBSUB_ERR_IN_PROGRESS;
 _GLOBAL_CONST signed long fxPUBSUB_ERR_NO_TASK;
 _GLOBAL_CONST signed long fxPUBSUB_ERR_STARTUP_FAILED;
 _GLOBAL_CONST signed long fxPUBSUB_ERR_TRANSFER;
 _GLOBAL_CONST signed long fxPUBSUB_WRN_NO_STATE_CHANGE;
#endif




#ifdef __cplusplus
};
#endif
#endif /* _FXPUBSUB_ */

