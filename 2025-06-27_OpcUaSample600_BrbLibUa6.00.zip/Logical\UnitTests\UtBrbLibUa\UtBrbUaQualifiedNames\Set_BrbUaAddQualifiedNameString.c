#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_TEST BrbUaAddQualifedNameString_NulPtr(void)
{
	dwordOut = BrbUaAddQualifiedNameString(0, stringIn, sizeof(stringIn));
	BRB_ASSERT_EQUAL_UDINT(0x80460000, dwordOut); // = Bad_StructureMissing

	dwordOut = BrbUaAddQualifiedNameString(&qualifiedNameIn, 0, sizeof(stringIn));
	BRB_ASSERT_EQUAL_UDINT(0x80460000, dwordOut); // = Bad_StructureMissing

	// Finished
	TEST_DONE;
}

_TEST BrbUaAddQualifedNameString_Add(void)
{
	strcpy(stringIn, "Test ");
	BrbUaSetQualifedName(&qualifiedNameIn, 0, "Root");
	dwordOut = BrbUaAddQualifiedNameString(&qualifiedNameIn, stringIn, sizeof(stringIn));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test 0:Root", stringIn);

	strcpy(stringIn, "Test ");
	BrbUaSetQualifedName(&qualifiedNameIn, 4, "PLC");
	dwordOut = BrbUaAddQualifiedNameString(&qualifiedNameIn, stringIn, sizeof(stringIn));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test 4:PLC", stringIn);

	strcpy(stringIn, "Test ");
	BrbUaSetQualifedName(&qualifiedNameIn, 6, "bBool");
	dwordOut = BrbUaAddQualifiedNameString(&qualifiedNameIn, stringIn, sizeof(stringIn));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test 6:bBool", stringIn);

	strcpy(stringIn, "Test ");
	BrbUaSetQualifedName(&qualifiedNameIn, 65535, "nUsint");
	dwordOut = BrbUaAddQualifiedNameString(&qualifiedNameIn, stringIn, sizeof(stringIn));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test 65535:nUsint", stringIn);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-11-19 10:25:46Z
By B+R UnitTest Helper Version: 6.0.0.173
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaAddQualifedNameString_NulPtr", BrbUaAddQualifedNameString_NulPtr), 
	new_TestFixture("BrbUaAddQualifedNameString_Add", BrbUaAddQualifedNameString_Add), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaAddQualifiedNameString, "Set_BrbUaAddQualifiedNameString", 0, 0, fixtures, 0, 0, 0);

