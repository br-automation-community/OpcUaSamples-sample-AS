/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer
 ********************************************************************
 * Library: BrbLib
 * File: BrbStepHandler.c
 * Author: niedermeierr
 * Created: June 11, 2013
 ********************************************************************
 * Implementation of library BrbLib
 ********************************************************************/

#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLib.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

 // NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/* Behandelt Schrittketten (Protokollierung, Timeout usw.) */
signed long BrbStepHandler2(struct BrbStepHandling2_TYP* pStepHandling2)
{
	// Muss der Schritt protokolliert werden?
	if(pStepHandling2->Intern.bLogOnNextCycle == 1)
	{
		pStepHandling2->Intern.bLogOnNextCycle = 0;
		// Ist Protokollierung gestoppt?
		if(pStepHandling2->Log.bStop == 0)
		{
			// Zyklusz�hler merken
			pStepHandling2->Log.Steps[0].nCycleCount = pStepHandling2->Intern.nCycleCount;
			// Zeiten eintragen
			TIME_OF_DAY todNow = BrbGetTimeOfDay();
			pStepHandling2->Log.Steps[0].Time.todLeave = todNow;
			pStepHandling2->Log.Steps[0].Time.tPeriod = (TIME)pStepHandling2->Log.Steps[0].Time.todLeave - (TIME)pStepHandling2->Log.Steps[0].Time.todEnter;
			// Eintr�ge um eins nach unten schieben
			memmove(&pStepHandling2->Log.Steps[1], &pStepHandling2->Log.Steps[0], sizeof(BrbStepHandlingStep2_TYP)*(nBRB_STEPLOG_STEPS_MAX));
			// Aktuellen Eintrag reinkopieren
			pStepHandling2->Log.Steps[0].nStepNr = pStepHandling2->Intern.nStepNrOld;
			pStepHandling2->Log.Steps[0].Time.todEnter = todNow;
			pStepHandling2->Log.Steps[0].Time.todLeave = 0;
			pStepHandling2->Log.Steps[0].Time.tPeriod = 0;
			BrbStringCopy(pStepHandling2->Log.Steps[0].sStepText, pStepHandling2->Current.sStepText, sizeof(pStepHandling2->Log.Steps[0].sStepText));
			pStepHandling2->Log.Steps[0].nCycleCount = 0;
		}
		// Zyklusz�hler wieder auf 0 setzen
		pStepHandling2->Intern.nCycleCount = 0;
	}
	// Hat sich der Schritt ge�ndert?
	if(pStepHandling2->Current.nStepNr != pStepHandling2->Intern.nStepNrOld)
	{
		// Flags l�schen
		memset(&pStepHandling2->Flags, 0, sizeof(pStepHandling2->Flags));
		// Schritt beim n�chsten Durchlauf protokollieren, weil dann erst der richtige Schritttext gesetzt ist
		pStepHandling2->Intern.bLogOnNextCycle = 1;
	}
	// Zyklusz�hler erh�hen
	pStepHandling2->Intern.nCycleCount++;
	// Aktuellen Schritt �bernehmen
	pStepHandling2->Intern.nStepNrOld = pStepHandling2->Current.nStepNr;
	// Kommando zum L�schen der Protokollierung
	if(pStepHandling2->Log.bClear == 1)
	{
		pStepHandling2->Log.bClear = 0;
		// Den gesamten Aufzeichnungspuffer l�schen
		memset(&pStepHandling2->Log.Steps[0], 0, sizeof(pStepHandling2->Log.Steps));
		pStepHandling2->Intern.bLogOnNextCycle = 1;
	}
	// StepTimeout
	TON(&pStepHandling2->Intern.fbTimeout);
	if(pStepHandling2->Intern.fbTimeout.Q == 1)
	{
		// Timeout abgelaufen
		pStepHandling2->Intern.fbTimeout.IN = 0;
		pStepHandling2->Current.bTimeoutElapsed = 1;
	}	
	return eBRB_ERR_OK;
}

 // NOLINTEND(readability-*, bugprone-easily-swappable-parameters, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)
