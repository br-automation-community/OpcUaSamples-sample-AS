#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

void AssertEventItem(BrbUaRcEventItem_TYP* pEiExpected, BrbUaRcEventItem_TYP* pEiActual)
{
	TEST_ASSERT_EQUAL_INT(		pEiExpected->nEventDatObjNamespaceIndex,	pEiActual->nEventDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(		pEiExpected->EventNodeId.NamespaceIndex,	pEiActual->EventNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(		pEiExpected->EventNodeId.IdentifierType,	pEiActual->EventNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING(	pEiExpected->EventNodeId.Identifier,			pEiActual->EventNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(		pEiExpected->nEventNodeHandleErrorId,			pEiActual->nEventNodeHandleErrorId);
	TEST_ASSERT_EQUAL_INT(		pEiExpected->nTypeDatObjNamespaceIndex,		pEiActual->nTypeDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(		pEiExpected->TypeNodeId.NamespaceIndex,		pEiActual->TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(		pEiExpected->TypeNodeId.IdentifierType,		pEiActual->TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING(	pEiExpected->TypeNodeId.Identifier,				pEiActual->TypeNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(		pEiExpected->nEventItemErrorId,						pEiActual->nEventItemErrorId);
	BRB_ASSERT_EQUAL_DINT(		pEiExpected->tTimeout,										pEiActual->tTimeout);
	BRB_ASSERT_EQUAL_BOOL(		pEiExpected->bCallOperate,								pEiActual->bCallOperate);
	BRB_ASSERT_EQUAL_UDINT(		pEiExpected->nOperateErrorId,							pEiActual->nOperateErrorId);
	BRB_ASSERT_EQUAL_UDINT(		pEiExpected->nEventFieldCount,						pEiActual->nEventFieldCount);
}

void AssertEventItemIntern(BrbUaRcEventItem_TYP* pEiExpected, BrbUaRcEventItemIntern_TYP* pEiActual)
{
	TEST_ASSERT_EQUAL_INT(		pEiExpected->nEventDatObjNamespaceIndex,	pEiActual->nEventDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(		pEiExpected->EventNodeId.NamespaceIndex,	pEiActual->EventNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(		pEiExpected->EventNodeId.IdentifierType,	pEiActual->EventNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING(	pEiExpected->EventNodeId.Identifier,			pEiActual->EventNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(		pEiExpected->nEventNodeHandleErrorId,			pEiActual->nEventNodeHandleErrorId);
	TEST_ASSERT_EQUAL_INT(		pEiExpected->nTypeDatObjNamespaceIndex,		pEiActual->nTypeDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(		pEiExpected->TypeNodeId.NamespaceIndex,		pEiActual->TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(		pEiExpected->TypeNodeId.IdentifierType,		pEiActual->TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING(	pEiExpected->TypeNodeId.Identifier,				pEiActual->TypeNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(		pEiExpected->nEventItemErrorId,						pEiActual->nEventItemErrorId);
	BRB_ASSERT_EQUAL_DINT(		pEiExpected->tTimeout,										pEiActual->tTimeout);
	BRB_ASSERT_EQUAL_BOOL(		pEiExpected->bCallOperate,								pEiActual->bCallOperate);
	BRB_ASSERT_EQUAL_UDINT(		pEiExpected->nOperateErrorId,							pEiActual->nOperateErrorId);
	BRB_ASSERT_EQUAL_UDINT(		pEiExpected->nEventFieldCount,						pEiActual->nEventFieldCount);
}

void AssertEventFieldItem(BrbUaRcEventField_TYP* pEfExpected, BrbUaRcEventField_TYP* pEfActual)
{
	TEST_ASSERT_EQUAL_INT(pEfExpected->nDatObjNamespaceIndex,																	pEfActual->nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(pEfExpected->FieldSelection.NoOfElements,													pEfActual->FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(pEfExpected->FieldSelection.Elements[0].TargetName.NamespaceIndex,	pEfActual->FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING(pEfExpected->FieldSelection.Elements[0].TargetName.Name,					pEfActual->FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING(pEfExpected->sVar,																								pEfActual->sVar);
	BRB_ASSERT_EQUAL_UDINT(pEfExpected->nAddErrorId,																					pEfActual->nAddErrorId);
}

_SETUP_SET(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent._SETUP_SET", sizeof(sCurrentUnitTest));

	memset(&Data, 0, sizeof(Data));
	memset(&SubscriptionEventDataStored, 0, sizeof(SubscriptionEventDataStored));

	// Finished
	TEST_DONE;
}

_CYCLIC_SET(void)
{
	if(RunClient.State.eState >= eBRB_RCSTATE_INIT_DONE && RunClient.State.eState < eBRB_RCSTATE_EXITING)
	{
		if(bRunCyclic == 1)
		{
			fbBrbUaRunClientCyclic.pRunClient = &RunClient;
			BrbUaRunClientCyclic(&fbBrbUaRunClientCyclic);
		}
	}
	BrbUaRcMonitor(&RunClient, &CyclicMonitor);
	return;
}

_TEST SubscriptionEvent_GetEventItem_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItem_NulPtr", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRcGetEventItem(0, SUBEVT_IDX_OK_0, 0, &EventItem, &EventItemIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);
	
	uintOut = BrbUaRcGetEventItem(&RunClient, SUBEVT_IDX_OK_0, 0, 0, &EventItemIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItem_InvalidSubscriptionIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItem_InvalidSubscriptionIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventItem, 0, sizeof(EventItem));
	memset(&EventItemIntern, 0, sizeof(EventItemIntern));
	uintOut = BrbUaRcGetEventItem(&RunClient, 99, 0, &EventItem, &EventItemIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.EventItem.nSubscriptionIndex = 99;
	RcMonitor.EventItem.nEventItemIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.EventItem.nMonitorStatus);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItem_InvalidEventItemIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItem_InvalidEventItemIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventItem, 0, sizeof(EventItem));
	memset(&EventItemIntern, 0, sizeof(EventItemIntern));
	uintOut = BrbUaRcGetEventItem(&RunClient, SUBEVT_IDX_OK_0, 99, &EventItem, &EventItemIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.EventItem.nSubscriptionIndex = SUBEVT_IDX_OK_0;
	RcMonitor.EventItem.nEventItemIndex = 99;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.EventItem.nMonitorStatus);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItem_InvalidEventItemEventNs(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItem_InvalidEventItemEventNs", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventItem, 0, sizeof(EventItem));
	memset(&EventItemIntern, 0, sizeof(EventItemIntern));
	uintOut = BrbUaRcGetEventItem(&RunClient, SUBEVT_IDX_INV_EI_EVT_NS, 0, &EventItem, &EventItemIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(99, EventItem.nEventDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.EventNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.EventNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("2253", EventItem.EventNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	TEST_ASSERT_EQUAL_INT(0, EventItem.nTypeDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("11446", EventItem.TypeNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventItemErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(1000, EventItem.tTimeout);
	BRB_ASSERT_EQUAL_BOOL(0, EventItem.bCallOperate);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nOperateErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(1, EventItem.nEventFieldCount);
	AssertEventItemIntern(&EventItem, &EventItemIntern);
	
	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.EventItem.nSubscriptionIndex = SUBEVT_IDX_INV_EI_EVT_NS;
	RcMonitor.EventItem.nEventItemIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.EventItem.nMonitorStatus);
	AssertEventItem(&EventItem, &RcMonitor.EventItem.EventItem);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItem_InvalidEventItemEventId(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItem_InvalidEventItemEventId", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventItem, 0, sizeof(EventItem));
	memset(&EventItemIntern, 0, sizeof(EventItemIntern));
	uintOut = BrbUaRcGetEventItem(&RunClient, SUBEVT_IDX_INV_EI_EVT_ID, 0, &EventItem, &EventItemIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventItem.nEventDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.EventNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.EventNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("1234", EventItem.EventNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, EventItem.nEventNodeHandleErrorId); // Bad_NodeIdUnknown
	TEST_ASSERT_EQUAL_INT(0, EventItem.nTypeDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("11446", EventItem.TypeNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, EventItem.nEventNodeHandleErrorId); // Bad_NodeIdUnknown
	BRB_ASSERT_EQUAL_UDINT(0xA0000302, EventItem.nEventItemErrorId); // PlcOpen_BadNodeInvalidHdl
	BRB_ASSERT_EQUAL_DINT(1000, EventItem.tTimeout);
	BRB_ASSERT_EQUAL_BOOL(0, EventItem.bCallOperate);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nOperateErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(1, EventItem.nEventFieldCount);
	AssertEventItemIntern(&EventItem, &EventItemIntern);
	
	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.EventItem.nSubscriptionIndex = SUBEVT_IDX_INV_EI_EVT_ID;
	RcMonitor.EventItem.nEventItemIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.EventItem.nMonitorStatus);
	AssertEventItem(&EventItem, &RcMonitor.EventItem.EventItem);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItem_InvalidEventItemTypeNs(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItem_InvalidEventItemTypeNs", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventItem, 0, sizeof(EventItem));
	memset(&EventItemIntern, 0, sizeof(EventItemIntern));
	uintOut = BrbUaRcGetEventItem(&RunClient, SUBEVT_IDX_INV_EI_TYPE_NS, 0, &EventItem, &EventItemIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventItem.nEventDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.EventNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.EventNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("2253", EventItem.EventNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	TEST_ASSERT_EQUAL_INT(99, EventItem.nTypeDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("11446", EventItem.TypeNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventItemErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(1000, EventItem.tTimeout);
	BRB_ASSERT_EQUAL_BOOL(0, EventItem.bCallOperate);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nOperateErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(1, EventItem.nEventFieldCount);
	AssertEventItemIntern(&EventItem, &EventItemIntern);
	
	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.EventItem.nSubscriptionIndex = SUBEVT_IDX_INV_EI_TYPE_NS;
	RcMonitor.EventItem.nEventItemIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.EventItem.nMonitorStatus);
	AssertEventItem(&EventItem, &RcMonitor.EventItem.EventItem);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItem_InvalidEventItemTypeId(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItem_InvalidEventItemTypeId", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventItem, 0, sizeof(EventItem));
	memset(&EventItemIntern, 0, sizeof(EventItemIntern));
	uintOut = BrbUaRcGetEventItem(&RunClient, SUBEVT_IDX_INV_EI_TYPE_ID, 0, &EventItem, &EventItemIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventItem.nEventDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.EventNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.EventNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("2253", EventItem.EventNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	TEST_ASSERT_EQUAL_INT(0, EventItem.nTypeDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("1234", EventItem.TypeNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventItemErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(1000, EventItem.tTimeout);
	BRB_ASSERT_EQUAL_BOOL(0, EventItem.bCallOperate);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nOperateErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(1, EventItem.nEventFieldCount);
	AssertEventItemIntern(&EventItem, &EventItemIntern);
	
	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.EventItem.nSubscriptionIndex = SUBEVT_IDX_INV_EI_TYPE_ID;
	RcMonitor.EventItem.nEventItemIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.EventItem.nMonitorStatus);
	AssertEventItem(&EventItem, &RcMonitor.EventItem.EventItem);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItem_InvalidEventItemTimeout(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItem_InvalidEventItemTimeout", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventItem, 0, sizeof(EventItem));
	memset(&EventItemIntern, 0, sizeof(EventItemIntern));
	uintOut = BrbUaRcGetEventItem(&RunClient, SUBEVT_IDX_INV_EI_TIMEOUT, 0, &EventItem, &EventItemIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventItem.nEventDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.EventNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.EventNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("2253", EventItem.EventNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	TEST_ASSERT_EQUAL_INT(0, EventItem.nTypeDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("11446", EventItem.TypeNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventItemErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(0, EventItem.tTimeout); // Wird nicht korrigiert
	BRB_ASSERT_EQUAL_BOOL(0, EventItem.bCallOperate);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nOperateErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(1, EventItem.nEventFieldCount);
	AssertEventItemIntern(&EventItem, &EventItemIntern);
	
	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.EventItem.nSubscriptionIndex = SUBEVT_IDX_INV_EI_TIMEOUT;
	RcMonitor.EventItem.nEventItemIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.EventItem.nMonitorStatus);
	AssertEventItem(&EventItem, &RcMonitor.EventItem.EventItem);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItem_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItem_Ok", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventItem, 0, sizeof(EventItem));
	memset(&EventItemIntern, 0, sizeof(EventItemIntern));
	uintOut = BrbUaRcGetEventItem(&RunClient, SUBEVT_IDX_OK_0, 0, &EventItem, &EventItemIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventItem.nEventDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.EventNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.EventNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("2253", EventItem.EventNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	TEST_ASSERT_EQUAL_INT(0, EventItem.nTypeDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("11446", EventItem.TypeNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventItemErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(1000, EventItem.tTimeout);
	BRB_ASSERT_EQUAL_BOOL(1, EventItem.bCallOperate);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nOperateErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(5, EventItem.nEventFieldCount);
	AssertEventItemIntern(&EventItem, &EventItemIntern);
	
	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.EventItem.nSubscriptionIndex = SUBEVT_IDX_OK_0;
	RcMonitor.EventItem.nEventItemIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.EventItem.nMonitorStatus);
	AssertEventItem(&EventItem, &RcMonitor.EventItem.EventItem);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_NulPtr", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRcGetEventField(0, SUBEVT_IDX_OK_0, 0, 0, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);
	
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_0, 0, 0, 0);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_InvalidSubscriptionIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_InvalidSubscriptionIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, 99, 0, 0, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.EventField.nSubscriptionIndex = 99;
	RcMonitor.EventField.nEventItemIndex = 0;
	RcMonitor.EventField.nEventFieldIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.EventField.nMonitorStatus);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_InvalidEventItemIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_InvalidEventItemIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_0, 99, 0, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.EventField.nSubscriptionIndex = SUBEVT_IDX_OK_0;
	RcMonitor.EventField.nEventItemIndex = 99;
	RcMonitor.EventField.nEventFieldIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.EventField.nMonitorStatus);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_InvalidEventFieldIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_InvalidEventFieldIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_0, 0, 99, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.EventField.nSubscriptionIndex = SUBEVT_IDX_OK_0;
	RcMonitor.EventField.nEventItemIndex = 0;
	RcMonitor.EventField.nEventFieldIndex = 99;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.EventField.nMonitorStatus);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_InvalidEventFieldNs(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_InvalidEventFieldNs", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_INV_EF_NS, 0, 0, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(99, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("Message", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[0].Message", EventField.sVar);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.EventField.nSubscriptionIndex = SUBEVT_IDX_INV_EF_NS;
	RcMonitor.EventField.nEventItemIndex = 0;
	RcMonitor.EventField.nEventFieldIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.EventField.nMonitorStatus);
	AssertEventFieldItem(&EventField, &RcMonitor.EventField.EventField);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_InvalidEventFieldPath(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_InvalidEventFieldPath", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_INV_EF_PATH, 0, 0, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("Invalid", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[0].Message", EventField.sVar);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.EventField.nSubscriptionIndex = SUBEVT_IDX_INV_EF_PATH;
	RcMonitor.EventField.nEventItemIndex = 0;
	RcMonitor.EventField.nEventFieldIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.EventField.nMonitorStatus);
	AssertEventFieldItem(&EventField, &RcMonitor.EventField.EventField);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_InvalidEventFieldVar(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_InvalidEventFieldVar", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_INV_EF_VAR, 0, 0, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("Message", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[0].Invalid", EventField.sVar);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.EventField.nSubscriptionIndex = SUBEVT_IDX_INV_EF_VAR;
	RcMonitor.EventField.nEventItemIndex = 0;
	RcMonitor.EventField.nEventFieldIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.EventField.nMonitorStatus);
	AssertEventFieldItem(&EventField, &RcMonitor.EventField.EventField);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_0, 0, 0, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("Message", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[0].Message", EventField.sVar);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.EventField.nSubscriptionIndex = SUBEVT_IDX_OK_0;
	RcMonitor.EventField.nEventItemIndex = 0;
	RcMonitor.EventField.nEventFieldIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.EventField.nMonitorStatus);
	AssertEventFieldItem(&EventField, &RcMonitor.EventField.EventField);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItemProcessed_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItemProcessed_NulPtr", sizeof(sCurrentUnitTest));

	boolOut = BrbUaRcGetEventItemProcessed(0, SUBEVT_IDX_OK_0, 0);
	BRB_ASSERT_EQUAL_BOOL(0, boolOut);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItemProcessed_InvalidSubscriptionIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItemProcessed_InvalidSubscriptionIndex", sizeof(sCurrentUnitTest));

	boolOut = BrbUaRcGetEventItemProcessed(&RunClient, 99, 0);
	BRB_ASSERT_EQUAL_BOOL(0, boolOut);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItemProcessed_InvalidEventItemIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItemProcessed_InvalidEventItemIndex", sizeof(sCurrentUnitTest));

	boolOut = BrbUaRcGetEventItemProcessed(&RunClient, SUBEVT_IDX_OK_0, 99);
	BRB_ASSERT_EQUAL_BOOL(0, boolOut);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItemRemainingCnt_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItemRemainingCnt_NulPtr", sizeof(sCurrentUnitTest));

	udintOut = BrbUaRcGetEventItemRemainingCnt(0, SUBEVT_IDX_OK_0, 0);
	BRB_ASSERT_EQUAL_UDINT(0, udintOut);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItemRemainingCnt_InvalidSubscriptionIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItemRemainingCnt_InvalidSubscriptionIndex", sizeof(sCurrentUnitTest));

	udintOut = BrbUaRcGetEventItemRemainingCnt(&RunClient, 99, 0);
	BRB_ASSERT_EQUAL_UDINT(0, udintOut);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItemRemainingCnt_InvalidEventItemIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItemRemainingCnt_InvalidEventItemIndex", sizeof(sCurrentUnitTest));

	udintOut = BrbUaRcGetEventItemRemainingCnt(&RunClient, SUBEVT_IDX_OK_0, 99);
	BRB_ASSERT_EQUAL_UDINT(0, udintOut);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItemReceived_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItemReceived_NulPtr", sizeof(sCurrentUnitTest));

	boolOut = BrbUaRcGetEventItemReceived(0, SUBEVT_IDX_OK_0, 0);
	BRB_ASSERT_EQUAL_BOOL(0, boolOut);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItemReceived_InvalidSubscriptionIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItemReceived_InvalidSubscriptionIndex", sizeof(sCurrentUnitTest));

	boolOut = BrbUaRcGetEventItemReceived(&RunClient, 99, 0);
	BRB_ASSERT_EQUAL_BOOL(0, boolOut);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItemReceived_InvalidEventItemIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItemReceived_InvalidEventItemIndex", sizeof(sCurrentUnitTest));

	boolOut = BrbUaRcGetEventItemReceived(&RunClient, SUBEVT_IDX_OK_0, 99);
	BRB_ASSERT_EQUAL_BOOL(0, boolOut);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItemReceiveCount_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItemReceiveCount_NulPtr", sizeof(sCurrentUnitTest));

	udintOut = BrbUaRcGetEventItemReceiveCount(0, SUBEVT_IDX_OK_0, 0);
	BRB_ASSERT_EQUAL_UDINT(0, udintOut);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItemReceiveCount_InvalidSubscriptionIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItemReceiveCount_InvalidSubscriptionIndex", sizeof(sCurrentUnitTest));

	udintOut = BrbUaRcGetEventItemReceiveCount(&RunClient, 99, 0);
	BRB_ASSERT_EQUAL_UDINT(0, udintOut);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItemReceiveCount_InvalidEventItemIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItemReceiveCount_InvalidEventItemIndex", sizeof(sCurrentUnitTest));

	udintOut = BrbUaRcGetEventItemReceiveCount(&RunClient, SUBEVT_IDX_OK_0, 99);
	BRB_ASSERT_EQUAL_UDINT(0, udintOut);

	// Finished
	TEST_DONE;
}

// Test der Parameter ---------------------------------------------------------------------------------------------

_TEST SubscriptionEvent_GetEventItem_Ok_0_0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItem_Ok_0_0", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventItem, 0, sizeof(EventItem));
	memset(&EventItemIntern, 0, sizeof(EventItemIntern));
	uintOut = BrbUaRcGetEventItem(&RunClient, SUBEVT_IDX_OK_0, 0, &EventItem, &EventItemIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventItem.nEventDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.EventNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.EventNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("2253", EventItem.EventNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	TEST_ASSERT_EQUAL_INT(0, EventItem.nTypeDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("11446", EventItem.TypeNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventItemErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(1000, EventItem.tTimeout);
	BRB_ASSERT_EQUAL_BOOL(1, EventItem.bCallOperate);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nOperateErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(5, EventItem.nEventFieldCount);
	AssertEventItemIntern(&EventItem, &EventItemIntern);
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_0_0_0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_0_0_0", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_0, 0, 0, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("Message", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[0].Message", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_0_0_1(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_0_0_1", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_0, 0, 1, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("Severity", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[0].nSeverity", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_0_0_2(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_0_0_2", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_0, 0, 2, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("SourceName", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[0].sSourceName", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_0_0_3(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_0_0_3", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_0, 0, 3, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("SourceNode", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[0].SourceNode", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_0_0_4(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_0_0_4", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_0, 0, 4, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("SystemState", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[0].eSystemState", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItem_Ok_0_1(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItem_Ok_0_1", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventItem, 0, sizeof(EventItem));
	memset(&EventItemIntern, 0, sizeof(EventItemIntern));
	uintOut = BrbUaRcGetEventItem(&RunClient, SUBEVT_IDX_OK_0, 1, &EventItem, &EventItemIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventItem.nEventDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.EventNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.EventNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("2253", EventItem.EventNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	TEST_ASSERT_EQUAL_INT(0, EventItem.nTypeDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("11446", EventItem.TypeNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventItemErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(1000, EventItem.tTimeout);
	BRB_ASSERT_EQUAL_BOOL(1, EventItem.bCallOperate);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nOperateErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(5, EventItem.nEventFieldCount);
	AssertEventItemIntern(&EventItem, &EventItemIntern);
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_0_1_0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_0_1_0", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_0, 1, 0, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("Message", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[1].Message", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_0_1_1(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_0_1_1", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_0, 1, 1, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("Severity", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[1].nSeverity", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_0_1_2(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_0_1_2", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_0, 1, 2, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("SourceName", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[1].sSourceName", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_0_1_3(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_0_1_3", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_0, 1, 3, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("SourceNode", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[1].SourceNode", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_0_1_4(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_0_1_4", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_0, 1, 4, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("SystemState", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[1].eSystemState", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItem_Ok_1_0(void)
{
	// Direkt
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItem_Ok_1_0", sizeof(sCurrentUnitTest));

	memset(&EventItem, 0, sizeof(EventItem));
	memset(&EventItemIntern, 0, sizeof(EventItemIntern));
	uintOut = BrbUaRcGetEventItem(&RunClient, SUBEVT_IDX_OK_1, 0, &EventItem, &EventItemIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventItem.nEventDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.EventNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.EventNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("2253", EventItem.EventNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	TEST_ASSERT_EQUAL_INT(0, EventItem.nTypeDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("11446", EventItem.TypeNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventItemErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(1000, EventItem.tTimeout);
	BRB_ASSERT_EQUAL_BOOL(1, EventItem.bCallOperate);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nOperateErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(5, EventItem.nEventFieldCount);
	AssertEventItemIntern(&EventItem, &EventItemIntern);
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_1_0_0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_1_0_0", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_1, 0, 0, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("Message", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[2].Message", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_1_0_1(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_1_0_1", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_1, 0, 1, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("Severity", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[2].nSeverity", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_1_0_2(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_1_0_2", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_1, 0, 2, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("SourceName", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[2].sSourceName", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_1_0_3(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_1_0_3", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_1, 0, 3, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("SourceNode", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[2].SourceNode", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_1_0_4(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_1_0_4", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_1, 0, 4, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("SystemState", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[2].eSystemState", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventItem_Ok_1_1(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventItem_Ok_1_1", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventItem, 0, sizeof(EventItem));
	memset(&EventItemIntern, 0, sizeof(EventItemIntern));
	uintOut = BrbUaRcGetEventItem(&RunClient, SUBEVT_IDX_OK_1, 1, &EventItem, &EventItemIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventItem.nEventDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.EventNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.EventNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("2253", EventItem.EventNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	TEST_ASSERT_EQUAL_INT(0, EventItem.nTypeDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("11446", EventItem.TypeNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventItemErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(1000, EventItem.tTimeout);
	BRB_ASSERT_EQUAL_BOOL(1, EventItem.bCallOperate);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nOperateErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(5, EventItem.nEventFieldCount);
	AssertEventItemIntern(&EventItem, &EventItemIntern);
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_1_1_0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_1_1_0", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_1, 1, 0, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("Message", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[3].Message", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_1_1_1(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_1_1_1", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_1, 1, 1, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("Severity", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[3].nSeverity", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_1_1_2(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_1_1_2", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_1, 1, 2, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("SourceName", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[3].sSourceName", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_1_1_3(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_1_1_3", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_1, 1, 3, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("SourceNode", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[3].SourceNode", EventField.sVar);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_GetEventField_Ok_1_1_4(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_GetEventField_Ok_1_1_4", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventField, 0, sizeof(EventField));
	uintOut = BrbUaRcGetEventField(&RunClient, SUBEVT_IDX_OK_1, 1, 4, &EventField);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventField.nDatObjNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(1, EventField.FieldSelection.NoOfElements);
	BRB_ASSERT_EQUAL_UDINT(0, EventField.FieldSelection.Elements[0].TargetName.NamespaceIndex);
	TEST_ASSERT_EQUAL_STRING("SystemState", EventField.FieldSelection.Elements[0].TargetName.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcT:Data.SubscriptionEvent.SysStatusChangeEventClt[3].eSystemState", EventField.sVar);

	// Finished
	TEST_DONE;
}

// Test des Empfangs -------------------------------------------------------------------------------------------------------------------

_TEST SubscriptionEvent_Receive_Store(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_Receive_Store", sizeof(sCurrentUnitTest));

	// Werte speichern
	memcpy(&SubscriptionEventDataStored, &Data.SubscriptionEvent, sizeof(SubscriptionEventDataStored));
	memset(&nSubEventReceiveCountStored, 0, sizeof(nSubEventReceiveCountStored));
	nSubEventReceiveCountStored[0] = BrbUaRcGetEventItemReceiveCount(&RunClient,SUBEVT_IDX_OK_0, 0);
	nSubEventReceiveCountStored[1] = BrbUaRcGetEventItemReceiveCount(&RunClient,SUBEVT_IDX_OK_0, 1);
	nSubEventReceiveCountStored[2] = BrbUaRcGetEventItemReceiveCount(&RunClient,SUBEVT_IDX_OK_1, 0);
	nSubEventReceiveCountStored[3] = BrbUaRcGetEventItemReceiveCount(&RunClient,SUBEVT_IDX_OK_1, 1);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_Receive_Wait(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_Receive_Wait", sizeof(sCurrentUnitTest));

	// Zeit abwarten
	fbTonWait.IN = 1;
	fbTonWait.PT = 2000;
	TON(&fbTonWait);
	TEST_BUSY_CONDITION(fbTonWait.Q == 0)
	fbTonWait.IN = 0;
	TON(&fbTonWait);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionEvent_Receive_Check(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionEvent.SubscriptionEvent_Receive_Check", sizeof(sCurrentUnitTest));

	// Werte testen. Achtung: Da der Update stark von Zeiten abh�ngt, die ArSim aber nicht deterministisch ist, kann hier manchmal ein Fehler registiert werden!
	
	// Sub 0 Evt0
	udintOut = BrbUaRcGetEventItemReceiveCount(&RunClient, SUBEVT_IDX_OK_0, 0);
	TEST_ASSERT_MESSAGE(nSubEventReceiveCountStored[0] != udintOut, "SubscriptionEvent Sub0, Evt0: ReceiveCount was not updated!");
	
	// Sub 0 Evt1
	udintOut = BrbUaRcGetEventItemReceiveCount(&RunClient, SUBEVT_IDX_OK_0, 1);
	TEST_ASSERT_MESSAGE(nSubEventReceiveCountStored[1] != udintOut, "SubscriptionEvent Sub0, Evt1: ReceiveCount was not updated!");
	
	// Sub 1 Evt0
	udintOut = BrbUaRcGetEventItemReceiveCount(&RunClient, SUBEVT_IDX_OK_1, 0);
	TEST_ASSERT_MESSAGE(nSubEventReceiveCountStored[2] != udintOut, "SubscriptionEvent Sub1, Evt0: ReceiveCount was not updated!");
	
	// Sub 1 Evt1
	udintOut = BrbUaRcGetEventItemReceiveCount(&RunClient, SUBEVT_IDX_OK_1, 1);
	TEST_ASSERT_MESSAGE(nSubEventReceiveCountStored[3] != udintOut, "SubscriptionEvent Sub1, Evt1: ReceiveCount was not updated!");
	
	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-12-05 10:38:44Z
By B+R UnitTest Helper Version: 6.0.0.173
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("SubscriptionEvent_GetEventItem_NulPtr", SubscriptionEvent_GetEventItem_NulPtr), 
	new_TestFixture("SubscriptionEvent_GetEventItem_InvalidSubscriptionIndex", SubscriptionEvent_GetEventItem_InvalidSubscriptionIndex), 
	new_TestFixture("SubscriptionEvent_GetEventItem_InvalidEventItemIndex", SubscriptionEvent_GetEventItem_InvalidEventItemIndex), 
	new_TestFixture("SubscriptionEvent_GetEventItem_InvalidEventItemEventNs", SubscriptionEvent_GetEventItem_InvalidEventItemEventNs), 
	new_TestFixture("SubscriptionEvent_GetEventItem_InvalidEventItemEventId", SubscriptionEvent_GetEventItem_InvalidEventItemEventId), 
	new_TestFixture("SubscriptionEvent_GetEventItem_InvalidEventItemTypeNs", SubscriptionEvent_GetEventItem_InvalidEventItemTypeNs), 
	new_TestFixture("SubscriptionEvent_GetEventItem_InvalidEventItemTypeId", SubscriptionEvent_GetEventItem_InvalidEventItemTypeId), 
	new_TestFixture("SubscriptionEvent_GetEventItem_InvalidEventItemTimeout", SubscriptionEvent_GetEventItem_InvalidEventItemTimeout), 
	new_TestFixture("SubscriptionEvent_GetEventItem_Ok", SubscriptionEvent_GetEventItem_Ok), 
	new_TestFixture("SubscriptionEvent_GetEventField_NulPtr", SubscriptionEvent_GetEventField_NulPtr), 
	new_TestFixture("SubscriptionEvent_GetEventField_InvalidSubscriptionIndex", SubscriptionEvent_GetEventField_InvalidSubscriptionIndex), 
	new_TestFixture("SubscriptionEvent_GetEventField_InvalidEventItemIndex", SubscriptionEvent_GetEventField_InvalidEventItemIndex), 
	new_TestFixture("SubscriptionEvent_GetEventField_InvalidEventFieldIndex", SubscriptionEvent_GetEventField_InvalidEventFieldIndex), 
	new_TestFixture("SubscriptionEvent_GetEventField_InvalidEventFieldNs", SubscriptionEvent_GetEventField_InvalidEventFieldNs), 
	new_TestFixture("SubscriptionEvent_GetEventField_InvalidEventFieldPath", SubscriptionEvent_GetEventField_InvalidEventFieldPath), 
	new_TestFixture("SubscriptionEvent_GetEventField_InvalidEventFieldVar", SubscriptionEvent_GetEventField_InvalidEventFieldVar), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok", SubscriptionEvent_GetEventField_Ok), 
	new_TestFixture("SubscriptionEvent_GetEventItemProcessed_NulPtr", SubscriptionEvent_GetEventItemProcessed_NulPtr), 
	new_TestFixture("SubscriptionEvent_GetEventItemProcessed_InvalidSubscriptionIndex", SubscriptionEvent_GetEventItemProcessed_InvalidSubscriptionIndex), 
	new_TestFixture("SubscriptionEvent_GetEventItemProcessed_InvalidEventItemIndex", SubscriptionEvent_GetEventItemProcessed_InvalidEventItemIndex), 
	new_TestFixture("SubscriptionEvent_GetEventItemRemainingCnt_NulPtr", SubscriptionEvent_GetEventItemRemainingCnt_NulPtr), 
	new_TestFixture("SubscriptionEvent_GetEventItemRemainingCnt_InvalidSubscriptionIndex", SubscriptionEvent_GetEventItemRemainingCnt_InvalidSubscriptionIndex), 
	new_TestFixture("SubscriptionEvent_GetEventItemRemainingCnt_InvalidEventItemIndex", SubscriptionEvent_GetEventItemRemainingCnt_InvalidEventItemIndex), 
	new_TestFixture("SubscriptionEvent_GetEventItemReceived_NulPtr", SubscriptionEvent_GetEventItemReceived_NulPtr), 
	new_TestFixture("SubscriptionEvent_GetEventItemReceived_InvalidSubscriptionIndex", SubscriptionEvent_GetEventItemReceived_InvalidSubscriptionIndex), 
	new_TestFixture("SubscriptionEvent_GetEventItemReceived_InvalidEventItemIndex", SubscriptionEvent_GetEventItemReceived_InvalidEventItemIndex), 
	new_TestFixture("SubscriptionEvent_GetEventItemReceiveCount_NulPtr", SubscriptionEvent_GetEventItemReceiveCount_NulPtr), 
	new_TestFixture("SubscriptionEvent_GetEventItemReceiveCount_InvalidSubscriptionIndex", SubscriptionEvent_GetEventItemReceiveCount_InvalidSubscriptionIndex), 
	new_TestFixture("SubscriptionEvent_GetEventItemReceiveCount_InvalidEventItemIndex", SubscriptionEvent_GetEventItemReceiveCount_InvalidEventItemIndex), 
	new_TestFixture("SubscriptionEvent_GetEventItem_Ok_0_0", SubscriptionEvent_GetEventItem_Ok_0_0), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_0_0_0", SubscriptionEvent_GetEventField_Ok_0_0_0), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_0_0_1", SubscriptionEvent_GetEventField_Ok_0_0_1), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_0_0_2", SubscriptionEvent_GetEventField_Ok_0_0_2), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_0_0_3", SubscriptionEvent_GetEventField_Ok_0_0_3), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_0_0_4", SubscriptionEvent_GetEventField_Ok_0_0_4), 
	new_TestFixture("SubscriptionEvent_GetEventItem_Ok_0_1", SubscriptionEvent_GetEventItem_Ok_0_1), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_0_1_0", SubscriptionEvent_GetEventField_Ok_0_1_0), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_0_1_1", SubscriptionEvent_GetEventField_Ok_0_1_1), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_0_1_2", SubscriptionEvent_GetEventField_Ok_0_1_2), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_0_1_3", SubscriptionEvent_GetEventField_Ok_0_1_3), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_0_1_4", SubscriptionEvent_GetEventField_Ok_0_1_4), 
	new_TestFixture("SubscriptionEvent_GetEventItem_Ok_1_0", SubscriptionEvent_GetEventItem_Ok_1_0), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_1_0_0", SubscriptionEvent_GetEventField_Ok_1_0_0), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_1_0_1", SubscriptionEvent_GetEventField_Ok_1_0_1), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_1_0_2", SubscriptionEvent_GetEventField_Ok_1_0_2), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_1_0_3", SubscriptionEvent_GetEventField_Ok_1_0_3), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_1_0_4", SubscriptionEvent_GetEventField_Ok_1_0_4), 
	new_TestFixture("SubscriptionEvent_GetEventItem_Ok_1_1", SubscriptionEvent_GetEventItem_Ok_1_1), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_1_1_0", SubscriptionEvent_GetEventField_Ok_1_1_0), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_1_1_1", SubscriptionEvent_GetEventField_Ok_1_1_1), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_1_1_2", SubscriptionEvent_GetEventField_Ok_1_1_2), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_1_1_3", SubscriptionEvent_GetEventField_Ok_1_1_3), 
	new_TestFixture("SubscriptionEvent_GetEventField_Ok_1_1_4", SubscriptionEvent_GetEventField_Ok_1_1_4), 
	new_TestFixture("SubscriptionEvent_Receive_Store", SubscriptionEvent_Receive_Store), 
	new_TestFixture("SubscriptionEvent_Receive_Wait", SubscriptionEvent_Receive_Wait), 
	new_TestFixture("SubscriptionEvent_Receive_Check", SubscriptionEvent_Receive_Check), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaRcSubscriptionEvent, "Set_BrbUaRcSubscriptionEvent", 0, 0, fixtures, setupSet, 0, cyclicSetCaller);

