#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

UDINT ServerGeneral_GetPointer(STRING* pPvName)
{
	UDINT nPvAdr = 0;
	UDINT nPvLen = 0;
	nPvXGetAdrStatus = PV_xgetadr(pPvName, &nPvAdr, &nPvLen);
	STRING sText[255];
	BrbStringCopy(sText, "Error on getting pointer of ", sizeof(sText));
	BrbStringCat(sText, pPvName, sizeof(sText));
	TEST_ABORT_CONDITION_MSG(nPvXGetAdrStatus != 0, sText)
	TEST_ABORT_CONDITION_MSG(nPvAdr == 0, sText)
	return nPvAdr;
}

_TEST ServerGeneral_GetLocalPointer(void)
{
	BrbStringCopy(sCurrentUnitTest, "ServerGeneral.ServerGeneral_GetLocalPointer", sizeof(sCurrentUnitTest));

	pServerVarsGlobal							=	(OpcUaServerVars_TYP*)		ServerGeneral_GetPointer("gVarsGlobal");
	pServerVarsLocal							=	(OpcUaServerVars_TYP*)		ServerGeneral_GetPointer("ServerData:VarsLocal");

	// Finished
	TEST_DONE;
}

_TEST ServerGeneral_Change_Values_Store(void)
{
	BrbStringCopy(sCurrentUnitTest, "ServerGeneral.ServerGeneral_Change_Values_Store", sizeof(sCurrentUnitTest));

	memcpy(&ServerVarsGlobalStored, pServerVarsGlobal, sizeof(ServerVarsGlobalStored));
	memcpy(&ServerVarsLocalStored, pServerVarsLocal, sizeof(ServerVarsLocalStored));

	// Finished
	TEST_DONE;
}

_TEST ServerGeneral_Change_Values_Wait(void)
{
	BrbStringCopy(sCurrentUnitTest, "ServerGeneral.ServerGeneral_Change_Values_Wait", sizeof(sCurrentUnitTest));

	// Zeit abwarten
	fbTonWait.IN = 1;
	fbTonWait.PT = 1000;
	TON(&fbTonWait);
	TEST_BUSY_CONDITION(fbTonWait.Q == 0)
	fbTonWait.IN = 0;
	TON(&fbTonWait);

	// Finished
	TEST_DONE;
}

_TEST ServerGeneral_Change_Values_Check(void)
{
	BrbStringCopy(sCurrentUnitTest, "ServerGeneral.ServerGeneral_Change_Values_Check", sizeof(sCurrentUnitTest));

	// Werte testen. Achtung: Da der Update stark von Zeiten abh�ngt, die ArSim aber nicht deterministisch ist, kann hier manchmal ein Fehler registiert werden!
	
	// VarsGlobal
	TEST_ASSERT_MESSAGE(ServerVarsGlobalStored.ReadOnly.nUdint != pServerVarsGlobal->ReadOnly.nUdint, "VarsGlobal: nUdint was not updated!");
	
	// VarsGlobal
	TEST_ASSERT_MESSAGE(ServerVarsLocalStored.ReadOnly.nUdint != pServerVarsLocal->ReadOnly.nUdint, "VarsLocal: nUdint was not updated!");
	
	// Finished
	TEST_DONE;
}


// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-03-20 12:35:46Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("ServerGeneral_GetLocalPointer", ServerGeneral_GetLocalPointer), 
	new_TestFixture("ServerGeneral_Change_Values_Store", ServerGeneral_Change_Values_Store), 
	new_TestFixture("ServerGeneral_Change_Values_Wait", ServerGeneral_Change_Values_Wait), 
	new_TestFixture("ServerGeneral_Change_Values_Check", ServerGeneral_Change_Values_Check), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_ServerGeneral, "Set_ServerC", 0, 0, fixtures, 0, 0, 0);

