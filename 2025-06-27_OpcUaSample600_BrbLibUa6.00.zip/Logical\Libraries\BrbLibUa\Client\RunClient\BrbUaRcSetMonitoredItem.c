#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>
#include <stdlib.h>

#ifdef __cplusplus
	};
#endif

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

// Eigene Enums und Typen
enum Steps_ENUM
{
	eSTEP_INIT,
	eSTEP_MODIFY,
	eSTEP_MODIFY_WAIT,
};

/* �ndert die Parameter eines MonitoredItems */
void BrbUaRcSetMonitoredItem(struct BrbUaRcSetMonitoredItem* inst)
{
	switch(inst->eStep)
	{
		case eSTEP_INIT:
			// Fub initialisieren
			inst->nStatus =  eBRB_ERR_BUSY;
			inst->bValueChanged = 0;
			inst->dtTimestamp = 0;
			inst->nErrorId = 0x00000000; // Good
			BrbUaGetStatusCodeText(inst->nErrorId, inst->sErrorId, sizeof(inst->sErrorId));
			memset(&inst->fbUA_MonitoredItemModifyList, 0, sizeof(inst->fbUA_MonitoredItemModifyList));
			// Parameter pr�fen
			if(inst->pRunClient != 0 && inst->pMonitoringParameter != 0)
			{
				if(inst->pRunClient->State.eState == eBRB_RCSTATE_CONNECTED && inst->pRunClient->Connection.nConnectionHandle != 0)
				{
					if(inst->pRunClient->Subscriptions.nSubscriptionCount > 0 && inst->pRunClient->Subscriptions.pSubscriptions != 0)
					{
						if(inst->nSubscriptionIndex < inst->pRunClient->Subscriptions.nSubscriptionCount)
						{
							BrbUaRcSubscriptionIntern_TYP* pSubscriptionIntern = ((BrbUaRcSubscriptionIntern_TYP*)inst->pRunClient->Subscriptions.pSubscriptions) + inst->nSubscriptionIndex;
							if(pSubscriptionIntern->nMonitoredItemCount > 0 && 
								pSubscriptionIntern->pMiDatObjNamespaceIndices != 0 && pSubscriptionIntern->pMiNodeIds != 0 && 
								pSubscriptionIntern->pMiNodeHandleErrorIds != 0 && pSubscriptionIntern->pMiNodeHandles != 0 && 
								pSubscriptionIntern->pMiNodeAddInfos != 0 && pSubscriptionIntern->pMiVariables != 0 && 
								pSubscriptionIntern->pMiQueueSizeOri != 0 && pSubscriptionIntern->pMiMonitoringParameter != 0 &&
								pSubscriptionIntern->pMiValuesChanged != 0 && pSubscriptionIntern->pMiMinLostValueCounts != 0 &&
								pSubscriptionIntern->pMiMonitoredItemErrorIds != 0 && pSubscriptionIntern->pMiMonitoredItemHandles != 0)
							{
								if(inst->nMonitoredItemIndex < pSubscriptionIntern->nMonitoredItemCount)
								{
									inst->eStep = eSTEP_MODIFY;
								}
								else
								{
									inst->nStatus = eBRB_ERR_UA_INVALID_INDEX;
								}
							}
							else
							{
								inst->nStatus = eBRB_ERR_UA_NO_ELEMENTS;
							}
						}
						else
						{
							inst->nStatus = eBRB_ERR_UA_INVALID_INDEX;
						}
					}
					else
					{
						inst->nStatus = eBRB_ERR_UA_NO_ELEMENTS;
					}
				}
				else
				{
					inst->nStatus = eBRB_ERR_UA_NOT_CONNECTED;
				}
			}
			else
			{
				inst->nStatus = eBRB_ERR_NULL_POINTER;
			}
			break;

		case eSTEP_MODIFY:
			// MonitoredItem �ndern
			inst->nStatus  = eBRB_ERR_BUSY;
			{
				BrbUaRcSubscriptionIntern_TYP* pSubscriptionIntern = ((BrbUaRcSubscriptionIntern_TYP*)inst->pRunClient->Subscriptions.pSubscriptions) + inst->nSubscriptionIndex;
				BrbUaRcGetMonitoredItem(inst->pRunClient, inst->nSubscriptionIndex, inst->nMonitoredItemIndex, &inst->MonitoredItemIntern);
				inst->fbUA_MonitoredItemModifyList.Execute = 1;
				inst->fbUA_MonitoredItemModifyList.SubscriptionHdl = pSubscriptionIntern->nSubscriptionHandle;
				inst->fbUA_MonitoredItemModifyList.MonitoredItemHdlCount = 1;
				inst->fbUA_MonitoredItemModifyList.MonitoredItemHdls[0] = inst->MonitoredItemIntern.nMonitoredItemHandle;
				inst->fbUA_MonitoredItemModifyList.Timeout = inst->pRunClient->Cfg.tAccessTimeout;
				memset(&inst->MonitoringParameter, 0, sizeof(inst->MonitoringParameter));
				memcpy((USINT*)&inst->MonitoringParameter[0], (USINT*)inst->pMonitoringParameter, sizeof(UAMonitoringParameter));
				inst->MonitoringParameter[0].QueueSize = inst->MonitoredItemIntern.nQueueSizeOri; // QueueSize nicht �ndern
				inst->fbUA_MonitoredItemModifyList.MonitoringParameters = &inst->MonitoringParameter;
			}
			inst->eStep = eSTEP_MODIFY_WAIT;
			break;

		case eSTEP_MODIFY_WAIT:
			// Warten, bis MonitoredItem ge�ndert wurde
			inst->nStatus  = eBRB_ERR_BUSY;
			if(inst->fbUA_MonitoredItemModifyList.Done == 1)
			{
				inst->fbUA_MonitoredItemModifyList.Execute = 0;
				// Ge�nderte Werte in interne Daten �bernehmen
				BrbUaRcSubscriptionIntern_TYP* pSubscriptionIntern = ((BrbUaRcSubscriptionIntern_TYP*)inst->pRunClient->Subscriptions.pSubscriptions) + inst->nSubscriptionIndex;
				UAMonitoringParameter* pMonitoringParameterIntern = ((UAMonitoringParameter*)pSubscriptionIntern->pMiMonitoringParameter) + inst->nMonitoredItemIndex;
				pMonitoringParameterIntern->SamplingInterval = inst->pMonitoringParameter->SamplingInterval = inst->MonitoringParameter[0].SamplingInterval;
				//pMonitoringParameterIntern->QueueSize = inst->pMonitoringParameter->QueueSize = inst->MonitoringParameter[0].QueueSize; Wird nicht ge�ndert
				pMonitoringParameterIntern->DiscardOldest = inst->pMonitoringParameter->DiscardOldest = inst->MonitoringParameter[0].DiscardOldest;
				pMonitoringParameterIntern->DeadbandType = inst->pMonitoringParameter->DeadbandType = inst->MonitoringParameter[0].DeadbandType;
				pMonitoringParameterIntern->Deadband = inst->pMonitoringParameter->Deadband = inst->MonitoringParameter[0].Deadband;
				inst->nStatus  = eBRB_ERR_OK;
				if(inst->fbUA_MonitoredItemModifyList.NodeErrorIDs[0] != 0)
				{
					inst->nErrorId = inst->fbUA_MonitoredItemModifyList.NodeErrorIDs[0];
				}
				else
				{
					inst->nErrorId = inst->fbUA_MonitoredItemModifyList.ErrorID;
				}
				BrbUaGetStatusCodeText(inst->nErrorId, inst->sErrorId, sizeof(inst->sErrorId));
				inst->eStep = eSTEP_INIT;
			}
			else if(inst->fbUA_MonitoredItemModifyList.Error == 1)
			{
				inst->fbUA_MonitoredItemModifyList.Execute = 0;
				inst->nStatus  = eBRB_ERR_UA_ERROR;
				if(inst->fbUA_MonitoredItemModifyList.NodeErrorIDs[0] != 0)
				{
					inst->nErrorId = inst->fbUA_MonitoredItemModifyList.NodeErrorIDs[0];
				}
				else
				{
					inst->nErrorId = inst->fbUA_MonitoredItemModifyList.ErrorID;
				}
				BrbUaGetStatusCodeText(inst->nErrorId, inst->sErrorId, sizeof(inst->sErrorId));
				inst->eStep = eSTEP_INIT;
			}
			break;

	}

	// Aufruf aller FB's
	UA_MonitoredItemModifyList(&inst->fbUA_MonitoredItemModifyList);
	
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)
