#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_TEST BrbUaIsNodeIdNull_NulPtr(void)
{
	boolOut = BrbUaIsNodeIdNull(0);
	BRB_ASSERT_EQUAL_BOOL(1, boolOut);

	// Finished
	TEST_DONE;
}

_TEST BrbUaIsNodeIdNull_Test(void)
{
	nodeIdIn0.NamespaceIndex = 0;
	nodeIdIn0.IdentifierType = UAIT_Numeric;
	strcpy(nodeIdIn0.Identifier, "");
	boolOut = BrbUaIsNodeIdNull(&nodeIdIn0);
	BRB_ASSERT_EQUAL_BOOL(1, boolOut);

	nodeIdIn0.NamespaceIndex = 1;
	nodeIdIn0.IdentifierType = UAIT_String;
	strcpy(nodeIdIn0.Identifier, "");
	boolOut = BrbUaIsNodeIdNull(&nodeIdIn0);
	BRB_ASSERT_EQUAL_BOOL(1, boolOut);

	nodeIdIn0.NamespaceIndex = 1;
	nodeIdIn0.IdentifierType = UAIT_GUID;
	strcpy(nodeIdIn0.Identifier, "");
	boolOut = BrbUaIsNodeIdNull(&nodeIdIn0);
	BRB_ASSERT_EQUAL_BOOL(1, boolOut);

	nodeIdIn0.NamespaceIndex = 1;
	nodeIdIn0.IdentifierType = UAIT_Opaque;
	strcpy(nodeIdIn0.Identifier, "");
	boolOut = BrbUaIsNodeIdNull(&nodeIdIn0);
	BRB_ASSERT_EQUAL_BOOL(1, boolOut);

	
	BrbUaSetNodeId(&nodeIdIn0, "0", 0);
	boolOut = BrbUaIsNodeIdNull(&nodeIdIn0);
	BRB_ASSERT_EQUAL_BOOL(1, boolOut);

	BrbUaSetNodeId(&nodeIdIn0, "a", 0);
	boolOut = BrbUaIsNodeIdNull(&nodeIdIn0);
	BRB_ASSERT_EQUAL_BOOL(0, boolOut);

	nodeIdIn0.NamespaceIndex = 0;
	nodeIdIn0.IdentifierType = UAIT_Numeric;
	strcpy(nodeIdIn0.Identifier, "1234567890");
	strcpy(nodeIdIn0.Identifier, "0");
	boolOut = BrbUaIsNodeIdNull(&nodeIdIn0);
	BRB_ASSERT_EQUAL_BOOL(1, boolOut);

	strcpy(nodeIdIn0.Identifier, "1");
	boolOut = BrbUaIsNodeIdNull(&nodeIdIn0);
	BRB_ASSERT_EQUAL_BOOL(0, boolOut);
	
	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-12-02 13:41:11Z
By B+R UnitTest Helper Version: 6.0.0.173
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaIsNodeIdNull_NulPtr", BrbUaIsNodeIdNull_NulPtr), 
	new_TestFixture("BrbUaIsNodeIdNull_Test", BrbUaIsNodeIdNull_Test), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaIsNodeIdNull, "Set_BrbUaIsNodeIdNull", 0, 0, fixtures, 0, 0, 0);

