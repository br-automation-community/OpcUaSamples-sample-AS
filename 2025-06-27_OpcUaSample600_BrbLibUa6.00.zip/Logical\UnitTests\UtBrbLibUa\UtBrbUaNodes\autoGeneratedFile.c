/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (List of TestSets).
LastUpdated: 2024-12-02 13:41:11Z
By B+R UnitTest Helper Version: 6.0.0.173
*/
#include "UnitTest.h"



UNITTEST_TESTSET_DECLARATION  Set_BrbUaSetNodeId;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaSetNodeIdNum;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaGetRandomNodeId;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaIsNodeIdNull;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaAreNodeIdsEqual;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaAddNodeIdText;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaAddNodeIdBrowseNameText;



UNITTEST_TESTSET_FIXTURES(utTestSets)
{
	new_TestSet(Set_BrbUaSetNodeId),
	new_TestSet(Set_BrbUaSetNodeIdNum),
	new_TestSet(Set_BrbUaGetRandomNodeId),
	new_TestSet(Set_BrbUaIsNodeIdNull),
	new_TestSet(Set_BrbUaAreNodeIdsEqual),
	new_TestSet(Set_BrbUaAddNodeIdText),
	new_TestSet(Set_BrbUaAddNodeIdBrowseNameText),
};
UNTITTEST_TESTSET_HANDLER();

