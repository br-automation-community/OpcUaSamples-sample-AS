#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/* Gibt zur�ck, ob zwei NodeIds gleich sind */
plcbit BrbUaAreNodeIdsEqual(struct UANodeID* pNodeId1, struct UANodeID* pNodeId2)
{
	if(pNodeId1 == 0)
	{
		return 0;
	}
	if(pNodeId2 == 0)
	{
		return 0;
	}	
	if(pNodeId1->NamespaceIndex == pNodeId2->NamespaceIndex)
	{
		if(pNodeId1->IdentifierType == pNodeId2->IdentifierType)
		{
			if(strcmp(pNodeId1->Identifier, pNodeId2->Identifier) == 0)
			{
				return 1;
			}
		}
	}
	return 0;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)
