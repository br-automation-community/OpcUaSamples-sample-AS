#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_TEST BrbUaGetAttributeList_NulPtr(void)
{
	dwordOut = BrbUaGetAttributeList(0, &nodeInfoAttributesIn);
	BRB_ASSERT_EQUAL_UDINT(0x80460000, dwordOut); // = Bad_StructureMissing

	dwordOut = BrbUaGetAttributeList(&nodeInfoIn, 0);
	BRB_ASSERT_EQUAL_UDINT(0x80460000, dwordOut); // = Bad_StructureMissing

	// Finished
	TEST_DONE;
}

_TEST BrbUaGetAttributeList_Get(void)
{
	memset(&nodeInfoIn, 0, sizeof(nodeInfoIn));
	nodeInfoIn.AccessLevel = eBrbUaAccessLevel_CurrentRead + eBrbUaAccessLevel_CurrentWrite + eBrbUaAccessLevel_HistoryRead + eBrbUaAccessLevel_HistoryWrite + eBrbUaAccessLevel_SemanticChange + eBrbUaAccessLevel_StatusWrite + eBrbUaAccessLevel_TimestampWrite;
	nodeInfoIn.ArrayDimension[0] = 1;
	nodeInfoIn.ArrayDimension[1] = 2;
	nodeInfoIn.ArrayDimension[2] = 3;
	strcpy(nodeInfoIn.BrowseName, "6:BrowseName");
	nodeInfoIn.ContainsNoLoops = 1;
	BrbUaSetNodeId(&nodeInfoIn.DataType, "7", 0);
	BrbUaSetLocalizedTextString(&nodeInfoIn.Description, "en", "Description");
	BrbUaSetLocalizedTextString(&nodeInfoIn.DisplayName, "en", "DisplayName");
	nodeInfoIn.EventNotifier = eBrbUaEvtNotif_SubscribeToEvents + eBrbUaEvtNotif_HistoryRead + eBrbUaEvtNotif_HistoryWrite;
	nodeInfoIn.Executable = 1;
	nodeInfoIn.Historizing = 1;
	strcpy(nodeInfoIn.InverseName, "InverseName");
	nodeInfoIn.IsAbstract = 1;
	nodeInfoIn.MinimumSamplingInterval = 123;
	nodeInfoIn.NodeClass = UANodeClass_Variable;
	BrbUaSetNodeId(&nodeInfoIn.NodeID, "NodeId", 6);
	nodeInfoIn.Symmetric = 1;
	nodeInfoIn.UserAccessLevel = eBrbUaAccessLevel_CurrentRead + eBrbUaAccessLevel_CurrentWrite + eBrbUaAccessLevel_HistoryRead + eBrbUaAccessLevel_HistoryWrite + eBrbUaAccessLevel_SemanticChange + eBrbUaAccessLevel_StatusWrite + eBrbUaAccessLevel_TimestampWrite;
	nodeInfoIn.UserExecutable = 1;
	nodeInfoIn.UserWriteMask = eBrbUaWriteMask_AccessLevel + eBrbUaWriteMask_ArrayDimensions + eBrbUaWriteMask_EventNotifier;
	nodeInfoIn.ValueRank = 3;
	nodeInfoIn.WriteMask = eBrbUaWriteMask_BrowseName + eBrbUaWriteMask_DisplayName + eBrbUaWriteMask_Description;

	memset(&nodeInfoAttributesIn, 0, sizeof(nodeInfoAttributesIn));
	dwordOut = BrbUaGetAttributeList(&nodeInfoIn, &nodeInfoAttributesIn);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("AccessLevel", nodeInfoAttributesIn.Attribute[UAAI_AccessLevel].sName);
	TEST_ASSERT_EQUAL_STRING("127= Read, Write, HistoryRead, HistoryWrite, SemanticChange, StatusWrite, TimestampWrite", nodeInfoAttributesIn.Attribute[UAAI_AccessLevel].sValue);
	TEST_ASSERT_EQUAL_STRING("ArrayDimensions", nodeInfoAttributesIn.Attribute[UAAI_ArrayDimensions].sName);
	TEST_ASSERT_EQUAL_STRING("1;2;3", nodeInfoAttributesIn.Attribute[UAAI_ArrayDimensions].sValue);
	TEST_ASSERT_EQUAL_STRING("BrowseName", nodeInfoAttributesIn.Attribute[UAAI_BrowseName].sName);
	TEST_ASSERT_EQUAL_STRING("6:BrowseName", nodeInfoAttributesIn.Attribute[UAAI_BrowseName].sValue);
	TEST_ASSERT_EQUAL_STRING("ContainsNoLoops", nodeInfoAttributesIn.Attribute[UAAI_ContainsNoLoops].sName);
	TEST_ASSERT_EQUAL_STRING("True", nodeInfoAttributesIn.Attribute[UAAI_ContainsNoLoops].sValue);
	TEST_ASSERT_EQUAL_STRING("DataType", nodeInfoAttributesIn.Attribute[UAAI_DataType].sName);
	TEST_ASSERT_EQUAL_STRING("7=UInt32", nodeInfoAttributesIn.Attribute[UAAI_DataType].sValue);
	TEST_ASSERT_EQUAL_STRING("Description", nodeInfoAttributesIn.Attribute[UAAI_Description].sName);
	TEST_ASSERT_EQUAL_STRING("en:Description", nodeInfoAttributesIn.Attribute[UAAI_Description].sValue);
	TEST_ASSERT_EQUAL_STRING("DisplayName", nodeInfoAttributesIn.Attribute[UAAI_DisplayName].sName);
	TEST_ASSERT_EQUAL_STRING("en:DisplayName", nodeInfoAttributesIn.Attribute[UAAI_DisplayName].sValue);
	TEST_ASSERT_EQUAL_STRING("EventNotifier", nodeInfoAttributesIn.Attribute[UAAI_EventNotifier].sName);
	TEST_ASSERT_EQUAL_STRING("13= Subscribe, HistoryRead, HistoryWrite", nodeInfoAttributesIn.Attribute[UAAI_EventNotifier].sValue);
	TEST_ASSERT_EQUAL_STRING("Executable", nodeInfoAttributesIn.Attribute[UAAI_Executable].sName);
	TEST_ASSERT_EQUAL_STRING("True", nodeInfoAttributesIn.Attribute[UAAI_Executable].sValue);
	TEST_ASSERT_EQUAL_STRING("Historizing", nodeInfoAttributesIn.Attribute[UAAI_Historizing].sName);
	TEST_ASSERT_EQUAL_STRING("True", nodeInfoAttributesIn.Attribute[UAAI_Historizing].sValue);
	TEST_ASSERT_EQUAL_STRING("InverseName", nodeInfoAttributesIn.Attribute[UAAI_InverseName].sName);
	TEST_ASSERT_EQUAL_STRING("InverseName", nodeInfoAttributesIn.Attribute[UAAI_InverseName].sValue);
	TEST_ASSERT_EQUAL_STRING("IsAbstract", nodeInfoAttributesIn.Attribute[UAAI_IsAbstract].sName);
	TEST_ASSERT_EQUAL_STRING("True", nodeInfoAttributesIn.Attribute[UAAI_IsAbstract].sValue);
	TEST_ASSERT_EQUAL_STRING("MinimumSamplingInterval", nodeInfoAttributesIn.Attribute[UAAI_MinimumSamplingInterval].sName);
	TEST_ASSERT_EQUAL_STRING("123", nodeInfoAttributesIn.Attribute[UAAI_MinimumSamplingInterval].sValue);
	TEST_ASSERT_EQUAL_STRING("NodeClass", nodeInfoAttributesIn.Attribute[UAAI_NodeClass].sName);
	TEST_ASSERT_EQUAL_STRING("Variable", nodeInfoAttributesIn.Attribute[UAAI_NodeClass].sValue);
	TEST_ASSERT_EQUAL_STRING("NodeId", nodeInfoAttributesIn.Attribute[UAAI_NodeId].sName);
	TEST_ASSERT_EQUAL_STRING("ns=6;s=NodeId", nodeInfoAttributesIn.Attribute[UAAI_NodeId].sValue);
	TEST_ASSERT_EQUAL_STRING("Symmetric", nodeInfoAttributesIn.Attribute[UAAI_Symmetric].sName);
	TEST_ASSERT_EQUAL_STRING("True", nodeInfoAttributesIn.Attribute[UAAI_Symmetric].sValue);
	TEST_ASSERT_EQUAL_STRING("UserAccessLevel", nodeInfoAttributesIn.Attribute[UAAI_UserAccessLevel].sName);
	TEST_ASSERT_EQUAL_STRING("127= Read, Write, HistoryRead, HistoryWrite, SemanticChange, StatusWrite, TimestampWrite", nodeInfoAttributesIn.Attribute[UAAI_UserAccessLevel].sValue);
	TEST_ASSERT_EQUAL_STRING("UserExecutable", nodeInfoAttributesIn.Attribute[UAAI_UserExecutable].sName);
	TEST_ASSERT_EQUAL_STRING("True", nodeInfoAttributesIn.Attribute[UAAI_UserExecutable].sValue);
	TEST_ASSERT_EQUAL_STRING("UserWriteMask", nodeInfoAttributesIn.Attribute[UAAI_UserWriteMask].sName);
	TEST_ASSERT_EQUAL_STRING("131", nodeInfoAttributesIn.Attribute[UAAI_UserWriteMask].sValue);
	TEST_ASSERT_EQUAL_STRING("ValueRank", nodeInfoAttributesIn.Attribute[UAAI_ValueRank].sName);
	TEST_ASSERT_EQUAL_STRING("3", nodeInfoAttributesIn.Attribute[UAAI_ValueRank].sValue);
	TEST_ASSERT_EQUAL_STRING("UserWriteMask", nodeInfoAttributesIn.Attribute[UAAI_UserWriteMask].sName);
	TEST_ASSERT_EQUAL_STRING("131", nodeInfoAttributesIn.Attribute[UAAI_UserWriteMask].sValue);

	// Finished
	TEST_DONE;
}

_TEST BrbUaGetAttributeList2_NulPtr(void)
{
	dwordOut = BrbUaGetAttributeList2(0, &nodeInfoAttributesIn);
	BRB_ASSERT_EQUAL_UDINT(0x80460000, dwordOut); // = Bad_StructureMissing

	dwordOut = BrbUaGetAttributeList2(&nodeInformationIn, 0);
	BRB_ASSERT_EQUAL_UDINT(0x80460000, dwordOut); // = Bad_StructureMissing

	// Finished
	TEST_DONE;
}

_TEST BrbUaGetAttributeList2_Get(void)
{
	memset(&nodeInformationIn, 0, sizeof(nodeInformationIn));
	nodeInformationIn.AccessLevel = eBrbUaAccessLevel_CurrentRead + eBrbUaAccessLevel_CurrentWrite + eBrbUaAccessLevel_HistoryRead + eBrbUaAccessLevel_HistoryWrite + eBrbUaAccessLevel_SemanticChange + eBrbUaAccessLevel_StatusWrite + eBrbUaAccessLevel_TimestampWrite;
	nodeInformationIn.ArrayDimension[0] = 1;
	nodeInformationIn.ArrayDimension[1] = 2;
	nodeInformationIn.ArrayDimension[2] = 3;
	BrbUaSetQualifedName(&nodeInformationIn.BrowseName, 6, "BrowseName");
	nodeInformationIn.ContainsNoLoops = 1;
	BrbUaSetNodeId(&nodeInformationIn.DataType, "7", 0);
	BrbUaSetLocalizedTextString(&nodeInformationIn.Description, "en", "Description");
	BrbUaSetLocalizedTextString(&nodeInformationIn.DisplayName, "en", "DisplayName");
	nodeInformationIn.EventNotifier = eBrbUaEvtNotif_SubscribeToEvents + eBrbUaEvtNotif_HistoryRead + eBrbUaEvtNotif_HistoryWrite;
	nodeInformationIn.Executable = 1;
	nodeInformationIn.Historizing = 1;
	strcpy(nodeInformationIn.InverseName, "InverseName");
	nodeInformationIn.IsAbstract = 1;
	nodeInformationIn.MinimumSamplingInterval = 123;
	nodeInformationIn.NodeClass = UANodeClass_Variable;
	nodeInformationIn.Symmetric = 1;
	nodeInformationIn.UserAccessLevel = eBrbUaAccessLevel_CurrentRead + eBrbUaAccessLevel_CurrentWrite + eBrbUaAccessLevel_HistoryRead + eBrbUaAccessLevel_HistoryWrite + eBrbUaAccessLevel_SemanticChange + eBrbUaAccessLevel_StatusWrite + eBrbUaAccessLevel_TimestampWrite;
	nodeInformationIn.UserExecutable = 1;
	nodeInformationIn.UserWriteMask = eBrbUaWriteMask_AccessLevel + eBrbUaWriteMask_ArrayDimensions + eBrbUaWriteMask_EventNotifier;
	nodeInformationIn.ValueRank = 3;
	nodeInformationIn.WriteMask = eBrbUaWriteMask_BrowseName + eBrbUaWriteMask_DisplayName + eBrbUaWriteMask_Description;

	memset(&nodeInfoAttributesIn, 0, sizeof(nodeInfoAttributesIn));
	dwordOut = BrbUaGetAttributeList2(&nodeInformationIn, &nodeInfoAttributesIn);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("AccessLevel", nodeInfoAttributesIn.Attribute[UAAI_AccessLevel].sName);
	TEST_ASSERT_EQUAL_STRING("127= Read, Write, HistoryRead, HistoryWrite, SemanticChange, StatusWrite, TimestampWrite", nodeInfoAttributesIn.Attribute[UAAI_AccessLevel].sValue);
	TEST_ASSERT_EQUAL_STRING("ArrayDimensions", nodeInfoAttributesIn.Attribute[UAAI_ArrayDimensions].sName);
	TEST_ASSERT_EQUAL_STRING("1;2;3", nodeInfoAttributesIn.Attribute[UAAI_ArrayDimensions].sValue);
	TEST_ASSERT_EQUAL_STRING("BrowseName", nodeInfoAttributesIn.Attribute[UAAI_BrowseName].sName);
	TEST_ASSERT_EQUAL_STRING("6:BrowseName", nodeInfoAttributesIn.Attribute[UAAI_BrowseName].sValue);
	TEST_ASSERT_EQUAL_STRING("ContainsNoLoops", nodeInfoAttributesIn.Attribute[UAAI_ContainsNoLoops].sName);
	TEST_ASSERT_EQUAL_STRING("True", nodeInfoAttributesIn.Attribute[UAAI_ContainsNoLoops].sValue);
	TEST_ASSERT_EQUAL_STRING("DataType", nodeInfoAttributesIn.Attribute[UAAI_DataType].sName);
	TEST_ASSERT_EQUAL_STRING("7=UInt32", nodeInfoAttributesIn.Attribute[UAAI_DataType].sValue);
	TEST_ASSERT_EQUAL_STRING("Description", nodeInfoAttributesIn.Attribute[UAAI_Description].sName);
	TEST_ASSERT_EQUAL_STRING("en:Description", nodeInfoAttributesIn.Attribute[UAAI_Description].sValue);
	TEST_ASSERT_EQUAL_STRING("DisplayName", nodeInfoAttributesIn.Attribute[UAAI_DisplayName].sName);
	TEST_ASSERT_EQUAL_STRING("en:DisplayName", nodeInfoAttributesIn.Attribute[UAAI_DisplayName].sValue);
	TEST_ASSERT_EQUAL_STRING("EventNotifier", nodeInfoAttributesIn.Attribute[UAAI_EventNotifier].sName);
	TEST_ASSERT_EQUAL_STRING("13= Subscribe, HistoryRead, HistoryWrite", nodeInfoAttributesIn.Attribute[UAAI_EventNotifier].sValue);
	TEST_ASSERT_EQUAL_STRING("Executable", nodeInfoAttributesIn.Attribute[UAAI_Executable].sName);
	TEST_ASSERT_EQUAL_STRING("True", nodeInfoAttributesIn.Attribute[UAAI_Executable].sValue);
	TEST_ASSERT_EQUAL_STRING("Historizing", nodeInfoAttributesIn.Attribute[UAAI_Historizing].sName);
	TEST_ASSERT_EQUAL_STRING("True", nodeInfoAttributesIn.Attribute[UAAI_Historizing].sValue);
	TEST_ASSERT_EQUAL_STRING("InverseName", nodeInfoAttributesIn.Attribute[UAAI_InverseName].sName);
	TEST_ASSERT_EQUAL_STRING("InverseName", nodeInfoAttributesIn.Attribute[UAAI_InverseName].sValue);
	TEST_ASSERT_EQUAL_STRING("IsAbstract", nodeInfoAttributesIn.Attribute[UAAI_IsAbstract].sName);
	TEST_ASSERT_EQUAL_STRING("True", nodeInfoAttributesIn.Attribute[UAAI_IsAbstract].sValue);
	TEST_ASSERT_EQUAL_STRING("MinimumSamplingInterval", nodeInfoAttributesIn.Attribute[UAAI_MinimumSamplingInterval].sName);
	TEST_ASSERT_EQUAL_STRING("123", nodeInfoAttributesIn.Attribute[UAAI_MinimumSamplingInterval].sValue);
	TEST_ASSERT_EQUAL_STRING("NodeClass", nodeInfoAttributesIn.Attribute[UAAI_NodeClass].sName);
	TEST_ASSERT_EQUAL_STRING("Variable", nodeInfoAttributesIn.Attribute[UAAI_NodeClass].sValue);
	TEST_ASSERT_EQUAL_STRING("NodeId", nodeInfoAttributesIn.Attribute[UAAI_NodeId].sName);
	TEST_ASSERT_EQUAL_STRING("", nodeInfoAttributesIn.Attribute[UAAI_NodeId].sValue);
	TEST_ASSERT_EQUAL_STRING("Symmetric", nodeInfoAttributesIn.Attribute[UAAI_Symmetric].sName);
	TEST_ASSERT_EQUAL_STRING("True", nodeInfoAttributesIn.Attribute[UAAI_Symmetric].sValue);
	TEST_ASSERT_EQUAL_STRING("UserAccessLevel", nodeInfoAttributesIn.Attribute[UAAI_UserAccessLevel].sName);
	TEST_ASSERT_EQUAL_STRING("127= Read, Write, HistoryRead, HistoryWrite, SemanticChange, StatusWrite, TimestampWrite", nodeInfoAttributesIn.Attribute[UAAI_UserAccessLevel].sValue);
	TEST_ASSERT_EQUAL_STRING("UserExecutable", nodeInfoAttributesIn.Attribute[UAAI_UserExecutable].sName);
	TEST_ASSERT_EQUAL_STRING("True", nodeInfoAttributesIn.Attribute[UAAI_UserExecutable].sValue);
	TEST_ASSERT_EQUAL_STRING("UserWriteMask", nodeInfoAttributesIn.Attribute[UAAI_UserWriteMask].sName);
	TEST_ASSERT_EQUAL_STRING("131", nodeInfoAttributesIn.Attribute[UAAI_UserWriteMask].sValue);
	TEST_ASSERT_EQUAL_STRING("ValueRank", nodeInfoAttributesIn.Attribute[UAAI_ValueRank].sName);
	TEST_ASSERT_EQUAL_STRING("3", nodeInfoAttributesIn.Attribute[UAAI_ValueRank].sValue);
	TEST_ASSERT_EQUAL_STRING("UserWriteMask", nodeInfoAttributesIn.Attribute[UAAI_UserWriteMask].sName);
	TEST_ASSERT_EQUAL_STRING("131", nodeInfoAttributesIn.Attribute[UAAI_UserWriteMask].sValue);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-11-19 12:53:12Z
By B+R UnitTest Helper Version: 6.0.0.173
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaGetAttributeList_NulPtr", BrbUaGetAttributeList_NulPtr), 
	new_TestFixture("BrbUaGetAttributeList_Get", BrbUaGetAttributeList_Get), 
	new_TestFixture("BrbUaGetAttributeList2_NulPtr", BrbUaGetAttributeList2_NulPtr), 
	new_TestFixture("BrbUaGetAttributeList2_Get", BrbUaGetAttributeList2_Get), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaGetAttributeList, "Set_BrbUaGetAttributeList", 0, 0, fixtures, 0, 0, 0);

