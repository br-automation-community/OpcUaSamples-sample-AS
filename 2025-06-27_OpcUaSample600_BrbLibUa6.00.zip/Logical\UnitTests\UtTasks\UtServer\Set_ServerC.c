#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

UDINT ServerC_GetPointer(STRING* pPvName)
{
	UDINT nPvAdr = 0;
	UDINT nPvLen = 0;
	nPvXGetAdrStatus = PV_xgetadr(pPvName, &nPvAdr, &nPvLen);
	STRING sText[255];
	BrbStringCopy(sText, "Error on getting pointer of ", sizeof(sText));
	BrbStringCat(sText, pPvName, sizeof(sText));
	TEST_ABORT_CONDITION_MSG(nPvXGetAdrStatus != 0, sText)
	TEST_ABORT_CONDITION_MSG(nPvAdr == 0, sText)
	return nPvAdr;
}

_TEST ServerC_GetLocalPointer(void)
{
	BrbStringCopy(sCurrentUnitTest, "ServerC.ServerC_GetLocalPointer", sizeof(sCurrentUnitTest));

	pServerUint64									=	(BrbUint64_TYP*)					ServerC_GetPointer("SrvDt64C:nUint64");
	pServerInt64									=	(BrbInt64_TYP*)						ServerC_GetPointer("SrvDt64C:nInt64");
	pFbUaSrv_MethodOperateErrorId	=	(DWORD*)									ServerC_GetPointer("SrvMethC:fbUaSrv_MethodOperateCalculate.ErrorID");
	pServerMethCalculateCallCount	=	(UDINT*)									ServerC_GetPointer("SrvMethC:nMethCalculateCallCount");
	pFbfbUaSrv_FireEventErrorId		=	(DWORD*)									ServerC_GetPointer("SrvEvntC:fbUaSrv_FireEvent.ErrorID");
	pServerEvtFieldSeverity				=	(UINT*)										ServerC_GetPointer("SrvEvntC:Fields.nSeverity");

	// Finished
	TEST_DONE;
}

_TEST ServerC_Wait_Dt64(void)
{
	BrbStringCopy(sCurrentUnitTest, "ServerC.ServerC_Wait_Dt64", sizeof(sCurrentUnitTest));

	// Die Variablen z�hlen hoch und runter. Wird der Wert zu einem ung�nstigen Zeitpunkt gespeichert, ist er nach der abgelaufenen Zeit wieder genau derselbe Wert.
	// Dies w�rde ein Assert ausl�sen. Deshalb wird hier auf einen bestimmten Wert gewartet, bei dem das nicht passiert.
	TEST_BUSY_CONDITION(pServerUint64->nHigh != 0 && pServerUint64->nLow != 5)

	// Finished
	TEST_DONE;
}

_TEST ServerC_Change_Values_Store(void)
{
	BrbStringCopy(sCurrentUnitTest, "ServerC.ServerC_Change_Values_Store", sizeof(sCurrentUnitTest));

	memcpy(&ServerUint64Stored, pServerUint64, sizeof(ServerUint64Stored));
	memcpy(&ServerInt64Stored, pServerInt64, sizeof(ServerInt64Stored));
	ServerMethCalcCallCountStored = *pServerMethCalculateCallCount;
	ServerEvtFieldSeverityStored = *pServerEvtFieldSeverity;

	// Finished
	TEST_DONE;
}

_TEST ServerC_Change_Values_Wait(void)
{
	BrbStringCopy(sCurrentUnitTest, "ServerC.ServerC_Change_Values_Wait", sizeof(sCurrentUnitTest));

	// Zeit abwarten
	fbTonWait.IN = 1;
	fbTonWait.PT = 7000;
	TON(&fbTonWait);
	TEST_BUSY_CONDITION(fbTonWait.Q == 0)
	fbTonWait.IN = 0;
	TON(&fbTonWait);

	// Finished
	TEST_DONE;
}

_TEST ServerC_Change_Values_Check(void)
{
	BrbStringCopy(sCurrentUnitTest, "ServerC.ServerC_Change_Values_Check", sizeof(sCurrentUnitTest));

	// Werte testen. Achtung: Da der Update stark von Zeiten abh�ngt, die ArSim aber nicht deterministisch ist, kann hier manchmal ein Fehler registiert werden!
	
	// Dt64
	TEST_ASSERT_MESSAGE((memcmp(&ServerUint64Stored, pServerUint64, sizeof(ServerUint64Stored))) != 0, "Uint64 was not updated!");
	TEST_ASSERT_MESSAGE((memcmp(&ServerInt64Stored, pServerInt64, sizeof(ServerInt64Stored))) != 0, "Int64 was not updated!");

	// Method
	TEST_ASSERT_MESSAGE(0x00000000 != pFbUaSrv_MethodOperateErrorId, "Method: ErrorId was not Good!");
	TEST_ASSERT_MESSAGE(ServerMethCalcCallCountStored != *pServerMethCalculateCallCount, "Method: CallCount was not incremented!");

	// Event
	TEST_ASSERT_MESSAGE(0x00000000 != pFbfbUaSrv_FireEventErrorId, "FireEvent: ErrorId was not Good!");
	TEST_ASSERT_MESSAGE(ServerEvtFieldSeverityStored != *pServerEvtFieldSeverity, "Event: Severity was not updated!");
	
	// Finished
	TEST_DONE;
}


// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-03-21 14:55:55Z
By B+R UnitTest Helper Version: 2.0.1.59
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("ServerC_GetLocalPointer", ServerC_GetLocalPointer), 
	new_TestFixture("ServerC_Wait_Dt64", ServerC_Wait_Dt64), 
	new_TestFixture("ServerC_Change_Values_Store", ServerC_Change_Values_Store), 
	new_TestFixture("ServerC_Change_Values_Wait", ServerC_Change_Values_Wait), 
	new_TestFixture("ServerC_Change_Values_Check", ServerC_Change_Values_Check), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_ServerC, "Set_ServerC", 0, 0, fixtures, 0, 0, 0);

