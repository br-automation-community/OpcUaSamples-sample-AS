#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_SETUP_SET(void)
{
	// Finished
	TEST_DONE;
}

_TEARDOWN_SET(void)
{
	RcMonitor.bEnable = 0;
	bRunCyclic = 0;
	// Exit
	fbBrbUaRunClientExit.pRunClient = &RunClient;
	BrbUaRunClientExit(&fbBrbUaRunClientExit);
	TEST_BUSY_CONDITION(fbBrbUaRunClientExit.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRunClientExit.nStatus);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-11-25 07:46:00Z
By B+R UnitTest Helper Version: 6.0.0.173
*/
UNITTEST_FIXTURES(fixtures)
{
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaCltExit, "Set_BrbUaCltExit", 0, 0, fixtures, setupSet, teardownSet, 0);

