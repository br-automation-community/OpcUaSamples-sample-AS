
#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLib.h"

#ifdef __cplusplus
	};
#endif

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/* Gibt die Tageszeit zur�ck */
plctod BrbGetTimeOfDay(void)
{
	RTCtime_typ Time;
	RTC_gettime(&Time);
	UDINT nTime = Time.millisec + (Time.second * nBRB_MILLISECONDS_PER_SECOND) + (Time.minute * nBRB_MILLISECONDS_PER_MINUTE) + (Time.hour * nBRB_MILLISECONDS_PER_HOUR);
	return (TIME_OF_DAY)nTime;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)
