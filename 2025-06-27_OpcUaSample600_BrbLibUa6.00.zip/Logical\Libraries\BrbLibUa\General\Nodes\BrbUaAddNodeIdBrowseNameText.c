#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*, hicpp-function-size)

/* H�ngt den Text einer NodeId mit BrowseName an */
plcdword BrbUaAddNodeIdBrowseNameText(struct UANodeID* pNodeId, plcstring* pText, unsigned long nTextSize)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pNodeId != 0 && pText != 0)
	{
		nStatus = 0x00000000; // = Good
		// Text der NodeId anh�ngen
		BrbUaAddNodeIdText(pNodeId, pText, nTextSize);
		// BrowseName von allen bekannten NodeId's anh�ngen
		STRING sBrowseName[nBRBUA_VALUE_TEXT_CHAR_MAX];
		memset(sBrowseName, 0, sizeof(sBrowseName));
		if(pNodeId->NamespaceIndex == 0) // http://opcfoundation.org/UA/
		{
			if(pNodeId->IdentifierType == UAIT_Numeric)
			{
				if(brsstrlen((UDINT)&pNodeId->Identifier) > 0)
				{
					UINT nIdentifier = (UINT)brsatoi((UDINT)&pNodeId->Identifier);
					switch(nIdentifier) // NOLINT(hicpp-multiway-paths-covered)
					{
						case 1:
							BrbStringCopy(sBrowseName, "Boolean", sizeof(sBrowseName));
							break;
						case 2:
							BrbStringCopy(sBrowseName, "SByte", sizeof(sBrowseName));
							break;
						case 3:
							BrbStringCopy(sBrowseName, "Byte", sizeof(sBrowseName));
							break;
						case 4:
							BrbStringCopy(sBrowseName, "Int16", sizeof(sBrowseName));
							break;
						case 5:
							BrbStringCopy(sBrowseName, "UInt16", sizeof(sBrowseName));
							break;
						case 6:
							BrbStringCopy(sBrowseName, "Int32", sizeof(sBrowseName));
							break;
						case 7:
							BrbStringCopy(sBrowseName, "UInt32", sizeof(sBrowseName));
							break;
						case 8:
							BrbStringCopy(sBrowseName, "Int64", sizeof(sBrowseName));
							break;
						case 9:
							BrbStringCopy(sBrowseName, "UInt64", sizeof(sBrowseName));
							break;
						case 10:
							BrbStringCopy(sBrowseName, "Float", sizeof(sBrowseName));
							break;
						case 11:
							BrbStringCopy(sBrowseName, "Double", sizeof(sBrowseName));
							break;
						case 12:
							BrbStringCopy(sBrowseName, "String", sizeof(sBrowseName));
							break;
						case 13:
							BrbStringCopy(sBrowseName, "DateTime", sizeof(sBrowseName));
							break;
						case 14:
							BrbStringCopy(sBrowseName, "Guid", sizeof(sBrowseName));
							break;
						case 15:
							BrbStringCopy(sBrowseName, "ByteString", sizeof(sBrowseName));
							break;
						case 16:
							BrbStringCopy(sBrowseName, "XmlElement", sizeof(sBrowseName));
							break;
						case 17:
							BrbStringCopy(sBrowseName, "NodeId", sizeof(sBrowseName));
							break;
						case 18:
							BrbStringCopy(sBrowseName, "ExpandedNodeId", sizeof(sBrowseName));
							break;
						case 19:
							BrbStringCopy(sBrowseName, "StatusCode", sizeof(sBrowseName));
							break;
						case 20:
							BrbStringCopy(sBrowseName, "QualifiedName", sizeof(sBrowseName));
							break;
						case 21:
							BrbStringCopy(sBrowseName, "LocalizedText", sizeof(sBrowseName));
							break;
						case 22:
							BrbStringCopy(sBrowseName, "Structure", sizeof(sBrowseName));
							break;
						case 23:
							BrbStringCopy(sBrowseName, "DataValue", sizeof(sBrowseName));
							break;
						case 24:
							BrbStringCopy(sBrowseName, "BaseDataType", sizeof(sBrowseName));
							break;
						case 25:
							BrbStringCopy(sBrowseName, "DiagnosticInfo", sizeof(sBrowseName));
							break;
						case 26:
							BrbStringCopy(sBrowseName, "Number", sizeof(sBrowseName));
							break;
						case 27:
							BrbStringCopy(sBrowseName, "Integer", sizeof(sBrowseName));
							break;
						case 28:
							BrbStringCopy(sBrowseName, "UInteger", sizeof(sBrowseName));
							break;
						case 29:
							BrbStringCopy(sBrowseName, "Enumeration", sizeof(sBrowseName));
							break;
						case 30:
							BrbStringCopy(sBrowseName, "Image", sizeof(sBrowseName));
							break;
						case 31:
							BrbStringCopy(sBrowseName, "References", sizeof(sBrowseName));
							break;
						case 32:
							BrbStringCopy(sBrowseName, "NonHierarchicalReferences", sizeof(sBrowseName));
							break;
						case 33:
							BrbStringCopy(sBrowseName, "HierarchicalReferences", sizeof(sBrowseName));
							break;
						case 34:
							BrbStringCopy(sBrowseName, "HasChild", sizeof(sBrowseName));
							break;
						case 35:
							BrbStringCopy(sBrowseName, "Organizes", sizeof(sBrowseName));
							break;
						case 36:
							BrbStringCopy(sBrowseName, "HasEventSource", sizeof(sBrowseName));
							break;
						case 37:
							BrbStringCopy(sBrowseName, "HasModellingRule", sizeof(sBrowseName));
							break;
						case 38:
							BrbStringCopy(sBrowseName, "HasEncoding", sizeof(sBrowseName));
							break;
						case 39:
							BrbStringCopy(sBrowseName, "HasDescription", sizeof(sBrowseName));
							break;
						case 40:
							BrbStringCopy(sBrowseName, "HasTypeDefinition", sizeof(sBrowseName));
							break;
						case 41:
							BrbStringCopy(sBrowseName, "GeneratesEvent", sizeof(sBrowseName));
							break;
						case 44:
							BrbStringCopy(sBrowseName, "Aggregates", sizeof(sBrowseName));
							break;
						case 45:
							BrbStringCopy(sBrowseName, "HasSubtype", sizeof(sBrowseName));
							break;
						case 46:
							BrbStringCopy(sBrowseName, "HasProperty", sizeof(sBrowseName));
							break;
						case 47:
							BrbStringCopy(sBrowseName, "HasComponent", sizeof(sBrowseName));
							break;
						case 48:
							BrbStringCopy(sBrowseName, "HasNotifier", sizeof(sBrowseName));
							break;
						case 49:
							BrbStringCopy(sBrowseName, "HasOrderedComponent", sizeof(sBrowseName));
							break;
						case 50:
							BrbStringCopy(sBrowseName, "Decimal", sizeof(sBrowseName));
							break;
						case 51:
							BrbStringCopy(sBrowseName, "FromState", sizeof(sBrowseName));
							break;
						case 52:
							BrbStringCopy(sBrowseName, "ToState", sizeof(sBrowseName));
							break;
						case 53:
							BrbStringCopy(sBrowseName, "HasCause", sizeof(sBrowseName));
							break;
						case 54:
							BrbStringCopy(sBrowseName, "HasEffect", sizeof(sBrowseName));
							break;
						case 56:
							BrbStringCopy(sBrowseName, "HasHistoricalConfiguration", sizeof(sBrowseName));
							break;
						case 78:
							BrbStringCopy(sBrowseName, "Mandatory", sizeof(sBrowseName));
							break;
						case 80:
							BrbStringCopy(sBrowseName, "Optional", sizeof(sBrowseName));
							break;
						case 83:
							BrbStringCopy(sBrowseName, "ExposesItsArray", sizeof(sBrowseName));
							break;
						case 84:
							BrbStringCopy(sBrowseName, "Root", sizeof(sBrowseName));
							break;
						case 85:
							BrbStringCopy(sBrowseName, "Objects", sizeof(sBrowseName));
							break;
						case 86:
							BrbStringCopy(sBrowseName, "Types", sizeof(sBrowseName));
							break;
						case 87:
							BrbStringCopy(sBrowseName, "Views", sizeof(sBrowseName));
							break;
						case 90:
							BrbStringCopy(sBrowseName, "DataTypes", sizeof(sBrowseName));
							break;
						case 91:
							BrbStringCopy(sBrowseName, "ReferenceTypes", sizeof(sBrowseName));
							break;
						case 93:
							BrbStringCopy(sBrowseName, "OPC Binary", sizeof(sBrowseName));
							break;
						case 94:
							BrbStringCopy(sBrowseName, "PermissionType", sizeof(sBrowseName));
							break;
						case 95:
							BrbStringCopy(sBrowseName, "AccessRestrictionType", sizeof(sBrowseName));
							break;
						case 96:
							BrbStringCopy(sBrowseName, "RolePermissionType", sizeof(sBrowseName));
							break;
						case 97:
							BrbStringCopy(sBrowseName, "DataTypeDefinition", sizeof(sBrowseName));
							break;
						case 98:
							BrbStringCopy(sBrowseName, "StructureType", sizeof(sBrowseName));
							break;
						case 99:
							BrbStringCopy(sBrowseName, "StructureDefinition", sizeof(sBrowseName));
							break;
						case 100:
							BrbStringCopy(sBrowseName, "EnumDefinition", sizeof(sBrowseName));
							break;
						case 101:
							BrbStringCopy(sBrowseName, "StructureField", sizeof(sBrowseName));
							break;
						case 102:
							BrbStringCopy(sBrowseName, "EnumField", sizeof(sBrowseName));
							break;
						case 117:
							BrbStringCopy(sBrowseName, "HasSubStateMachine", sizeof(sBrowseName));
							break;
						case 120:
							BrbStringCopy(sBrowseName, "NamingRuleType", sizeof(sBrowseName));
							break;
						case 129:
							BrbStringCopy(sBrowseName, "HasArgumentDescription", sizeof(sBrowseName));
							break;
						case 131:
							BrbStringCopy(sBrowseName, "HasOptionalInputArgumentDescription", sizeof(sBrowseName));
							break;
						case 256:
							BrbStringCopy(sBrowseName, "IdType", sizeof(sBrowseName));
							break;
						case 257:
							BrbStringCopy(sBrowseName, "NodeClass", sizeof(sBrowseName));
							break;
						case 288:
							BrbStringCopy(sBrowseName, "IntegerId", sizeof(sBrowseName));
							break;
						case 289:
							BrbStringCopy(sBrowseName, "Counter", sizeof(sBrowseName));
							break;
						case 290:
							BrbStringCopy(sBrowseName, "Duration", sizeof(sBrowseName));
							break;
						case 291:
							BrbStringCopy(sBrowseName, "NumericRange", sizeof(sBrowseName));
							break;
						case 294:
							BrbStringCopy(sBrowseName, "UtcTime", sizeof(sBrowseName));
							break;
						case 295:
							BrbStringCopy(sBrowseName, "LocaleId", sizeof(sBrowseName));
							break;
						case 296:
							BrbStringCopy(sBrowseName, "Argument", sizeof(sBrowseName));
							break;
						case 299:
							BrbStringCopy(sBrowseName, "StatusResult", sizeof(sBrowseName));
							break;
						case 302:
							BrbStringCopy(sBrowseName, "MessageSecurityMode", sizeof(sBrowseName));
							break;
						case 303:
							BrbStringCopy(sBrowseName, "UserTokenType", sizeof(sBrowseName));
							break;
						case 304:
							BrbStringCopy(sBrowseName, "UserTokenPolicy", sizeof(sBrowseName));
							break;
						case 307:
							BrbStringCopy(sBrowseName, "ApplicationType", sizeof(sBrowseName));
							break;
						case 308:
							BrbStringCopy(sBrowseName, "ApplicationDescription", sizeof(sBrowseName));
							break;
						case 311:
							BrbStringCopy(sBrowseName, "ApplicationInstanceCertificate", sizeof(sBrowseName));
							break;
						case 312:
							BrbStringCopy(sBrowseName, "EndpointDescription", sizeof(sBrowseName));
							break;
						case 315:
							BrbStringCopy(sBrowseName, "SecurityTokenRequestType", sizeof(sBrowseName));
							break;
						case 316:
							BrbStringCopy(sBrowseName, "UserIdentityToken", sizeof(sBrowseName));
							break;
						case 319:
							BrbStringCopy(sBrowseName, "AnonymousIdentityToken", sizeof(sBrowseName));
							break;
						case 322:
							BrbStringCopy(sBrowseName, "UserNameIdentityToken", sizeof(sBrowseName));
							break;
						case 325:
							BrbStringCopy(sBrowseName, "X509IdentityToken", sizeof(sBrowseName));
							break;
						case 331:
							BrbStringCopy(sBrowseName, "EndpointConfiguration", sizeof(sBrowseName));
							break;
						case 338:
							BrbStringCopy(sBrowseName, "BuildInfo", sizeof(sBrowseName));
							break;
						case 344:
							BrbStringCopy(sBrowseName, "SignedSoftwareCertificate", sizeof(sBrowseName));
							break;
						case 347:
							BrbStringCopy(sBrowseName, "AttributeWriteMask", sizeof(sBrowseName));
							break;
						case 348:
							BrbStringCopy(sBrowseName, "NodeAttributesMask", sizeof(sBrowseName));
							break;
						case 376:
							BrbStringCopy(sBrowseName, "AddNodesItem", sizeof(sBrowseName));
							break;
						case 379:
							BrbStringCopy(sBrowseName, "AddReferencesItem", sizeof(sBrowseName));
							break;
						case 382:
							BrbStringCopy(sBrowseName, "DeleteNodesItem", sizeof(sBrowseName));
							break;
						case 385:
							BrbStringCopy(sBrowseName, "DeleteReferencesItem", sizeof(sBrowseName));
							break;
						case 388:
							BrbStringCopy(sBrowseName, "SessionAuthenticationToken", sizeof(sBrowseName));
							break;
						case 432:
							BrbStringCopy(sBrowseName, "RegisteredServer", sizeof(sBrowseName));
							break;
						case 521:
							BrbStringCopy(sBrowseName, "ContinuationPoint", sizeof(sBrowseName));
							break;
						case 537:
							BrbStringCopy(sBrowseName, "RelativePathElement", sizeof(sBrowseName));
							break;
						case 540:
							BrbStringCopy(sBrowseName, "RelativePath", sizeof(sBrowseName));
							break;
						case 576:
							BrbStringCopy(sBrowseName, "FilterOperator", sizeof(sBrowseName));
							break;
						case 583:
							BrbStringCopy(sBrowseName, "ContentFilterElement", sizeof(sBrowseName));
							break;
						case 586:
							BrbStringCopy(sBrowseName, "ContentFilter", sizeof(sBrowseName));
							break;
						case 589:
							BrbStringCopy(sBrowseName, "FilterOperand", sizeof(sBrowseName));
							break;
						case 592:
							BrbStringCopy(sBrowseName, "ElementOperand", sizeof(sBrowseName));
							break;
						case 595:
							BrbStringCopy(sBrowseName, "LiteralOperand", sizeof(sBrowseName));
							break;
						case 598:
							BrbStringCopy(sBrowseName, "AttributeOperand", sizeof(sBrowseName));
							break;
						case 719:
							BrbStringCopy(sBrowseName, "MonitoringFilter", sizeof(sBrowseName));
							break;
						case 725:
							BrbStringCopy(sBrowseName, "EventFilter", sizeof(sBrowseName));
							break;
						case 601:
							BrbStringCopy(sBrowseName, "SimpleAttributeOperand", sizeof(sBrowseName));
							break;
						case 659:
							BrbStringCopy(sBrowseName, "HistoryEvent", sizeof(sBrowseName));
							break;
						case 851:
							BrbStringCopy(sBrowseName, "RedundancySupport", sizeof(sBrowseName));
							break;
						case 852:
							BrbStringCopy(sBrowseName, "ServerState", sizeof(sBrowseName));
							break;
						case 853:
							BrbStringCopy(sBrowseName, "RedundantServerDataType", sizeof(sBrowseName));
							break;
						case 856:
							BrbStringCopy(sBrowseName, "SamplingIntervalDiagnosticsDataType", sizeof(sBrowseName));
							break;
						case 859:
							BrbStringCopy(sBrowseName, "ServerDiagnosticsSummaryDataType", sizeof(sBrowseName));
							break;
						case 862:
							BrbStringCopy(sBrowseName, "ServerStatusDataType", sizeof(sBrowseName));
							break;
						case 865:
							BrbStringCopy(sBrowseName, "SessionDiagnosticsDataType", sizeof(sBrowseName));
							break;
						case 868:
							BrbStringCopy(sBrowseName, "SessionSecurityDiagnosticsDataType", sizeof(sBrowseName));
							break;
						case 871:
							BrbStringCopy(sBrowseName, "ServiceCounterDataType", sizeof(sBrowseName));
							break;
						case 874:
							BrbStringCopy(sBrowseName, "SubscriptionDiagnosticsDataType", sizeof(sBrowseName));
							break;
						case 877:
							BrbStringCopy(sBrowseName, "ModelChangeStructureDataType", sizeof(sBrowseName));
							break;
						case 884:
							BrbStringCopy(sBrowseName, "Range", sizeof(sBrowseName));
							break;
						case 887:
							BrbStringCopy(sBrowseName, "EUInformation", sizeof(sBrowseName));
							break;
						case 890:
							BrbStringCopy(sBrowseName, "ExceptionDeviationFormat", sizeof(sBrowseName));
							break;
						case 891:
							BrbStringCopy(sBrowseName, "Annotation", sizeof(sBrowseName));
							break;
						case 894:
							BrbStringCopy(sBrowseName, "ProgramDiagnosticDataType", sizeof(sBrowseName));
							break;
						case 897:
							BrbStringCopy(sBrowseName, "SemanticChangeStructureDataType", sizeof(sBrowseName));
							break;
						case 920:
							BrbStringCopy(sBrowseName, "HistoryEventFieldList", sizeof(sBrowseName));
							break;
						case 938:
							BrbStringCopy(sBrowseName, "IssuedIdentityToken", sizeof(sBrowseName));
							break;
						case 948:
							BrbStringCopy(sBrowseName, "AggregateConfiguration", sizeof(sBrowseName));
							break;
						case 2000:
							BrbStringCopy(sBrowseName, "ImageBMP", sizeof(sBrowseName));
							break;
						case 2001:
							BrbStringCopy(sBrowseName, "ImageGIF", sizeof(sBrowseName));
							break;
						case 2002:
							BrbStringCopy(sBrowseName, "ImageJPG", sizeof(sBrowseName));
							break;
						case 2003:
							BrbStringCopy(sBrowseName, "ImagePNG", sizeof(sBrowseName));
							break;
						case 2041:
							BrbStringCopy(sBrowseName, "BaseEventType", sizeof(sBrowseName));
							break;
						case 2052:
							BrbStringCopy(sBrowseName, "AuditEventType", sizeof(sBrowseName));
							break;
						case 2058:
							BrbStringCopy(sBrowseName, "AuditSecurityEventType", sizeof(sBrowseName));
							break;
						case 2059:
							BrbStringCopy(sBrowseName, "AuditChannelEventType", sizeof(sBrowseName));
							break;
						case 2060:
							BrbStringCopy(sBrowseName, "AuditOpenSecureChannelEventType", sizeof(sBrowseName));
							break;
						case 2069:
							BrbStringCopy(sBrowseName, "AuditSessionEventType", sizeof(sBrowseName));
							break;
						case 2071:
							BrbStringCopy(sBrowseName, "AuditCreateSessionEventType", sizeof(sBrowseName));
							break;
						case 2075:
							BrbStringCopy(sBrowseName, "AuditActivateSessionEventType", sizeof(sBrowseName));
							break;
						case 2078:
							BrbStringCopy(sBrowseName, "AuditCancelEventType", sizeof(sBrowseName));
							break;
						case 2080:
							BrbStringCopy(sBrowseName, "AuditCertificateEventType", sizeof(sBrowseName));
							break;
						case 2082:
							BrbStringCopy(sBrowseName, "AuditCertificateDataMismatchEventType", sizeof(sBrowseName));
							break;
						case 2085:
							BrbStringCopy(sBrowseName, "AuditCertificateExpiredEventType", sizeof(sBrowseName));
							break;
						case 2086:
							BrbStringCopy(sBrowseName, "AuditCertificateInvalidEventType", sizeof(sBrowseName));
							break;
						case 2087:
							BrbStringCopy(sBrowseName, "AuditCertificateUntrustedEventType", sizeof(sBrowseName));
							break;
						case 2088:
							BrbStringCopy(sBrowseName, "AuditCertificateRevokedEventType", sizeof(sBrowseName));
							break;
						case 2089:
							BrbStringCopy(sBrowseName, "AuditCertificateMismatchEventType", sizeof(sBrowseName));
							break;
						case 2090:
							BrbStringCopy(sBrowseName, "AuditNodeManagementEventType", sizeof(sBrowseName));
							break;
						case 2091:
							BrbStringCopy(sBrowseName, "AuditAddNodesEventType", sizeof(sBrowseName));
							break;
						case 2093:
							BrbStringCopy(sBrowseName, "AuditDeleteNodesEventType", sizeof(sBrowseName));
							break;
						case 2095:
							BrbStringCopy(sBrowseName, "AuditAddReferencesEventType", sizeof(sBrowseName));
							break;
						case 2097:
							BrbStringCopy(sBrowseName, "AuditDeleteReferencesEventType", sizeof(sBrowseName));
							break;
						case 2099:
							BrbStringCopy(sBrowseName, "AuditUpdateEventType", sizeof(sBrowseName));
							break;
						case 2100:
							BrbStringCopy(sBrowseName, "AuditWriteUpdateEventType", sizeof(sBrowseName));
							break;
						case 2104:
							BrbStringCopy(sBrowseName, "AuditHistoryUpdateEventType", sizeof(sBrowseName));
							break;
						case 2127:
							BrbStringCopy(sBrowseName, "AuditUpdateMethodEventType", sizeof(sBrowseName));
							break;
						case 2130:
							BrbStringCopy(sBrowseName, "SystemEventType", sizeof(sBrowseName));
							break;
						case 2131:
							BrbStringCopy(sBrowseName, "DeviceFailureEventType", sizeof(sBrowseName));
							break;
						case 2132:
							BrbStringCopy(sBrowseName, "BaseModelChangeEventType", sizeof(sBrowseName));
							break;
						case 2133:
							BrbStringCopy(sBrowseName, "GeneralModelChangeEventType", sizeof(sBrowseName));
							break;
						case 2253:
							BrbStringCopy(sBrowseName, "Server", sizeof(sBrowseName));
							break;
						case 2254:
							BrbStringCopy(sBrowseName, "ServerArray", sizeof(sBrowseName));
							break;
						case 2255:
							BrbStringCopy(sBrowseName, "NamespaceArray", sizeof(sBrowseName));
							break;
						case 2256:
							BrbStringCopy(sBrowseName, "ServerStatus", sizeof(sBrowseName));
							break;
						case 2257:
							BrbStringCopy(sBrowseName, "StartTime", sizeof(sBrowseName));
							break;
						case 2258:
							BrbStringCopy(sBrowseName, "CurrentTime", sizeof(sBrowseName));
							break;
						case 2259:
							BrbStringCopy(sBrowseName, "State", sizeof(sBrowseName));
							break;
						case 2260:
							BrbStringCopy(sBrowseName, "BuildInfo", sizeof(sBrowseName));
							break;
						case 2261:
							BrbStringCopy(sBrowseName, "ProductName", sizeof(sBrowseName));
							break;
						case 2262:
							BrbStringCopy(sBrowseName, "ProductUri", sizeof(sBrowseName));
							break;
						case 2263:
							BrbStringCopy(sBrowseName, "ManufacturerName", sizeof(sBrowseName));
							break;
						case 2264:
							BrbStringCopy(sBrowseName, "SoftwareVersion", sizeof(sBrowseName));
							break;
						case 2265:
							BrbStringCopy(sBrowseName, "BuildNumber", sizeof(sBrowseName));
							break;
						case 2266:
							BrbStringCopy(sBrowseName, "BuildDate", sizeof(sBrowseName));
							break;
						case 2267:
							BrbStringCopy(sBrowseName, "ServiceLevel", sizeof(sBrowseName));
							break;
						case 2268:
							BrbStringCopy(sBrowseName, "ServerCapabilities", sizeof(sBrowseName));
							break;
						case 2274:
							BrbStringCopy(sBrowseName, "ServerDiagnostics", sizeof(sBrowseName));
							break;
						case 2275:
							BrbStringCopy(sBrowseName, "ServerDiagnosticsSummary", sizeof(sBrowseName));
							break;
						case 2290:
							BrbStringCopy(sBrowseName, "SubscriptionDiagnosticsArray", sizeof(sBrowseName));
							break;
						case 2294:
							BrbStringCopy(sBrowseName, "EnabledFlag", sizeof(sBrowseName));
							break;
						case 2295:
							BrbStringCopy(sBrowseName, "VendorServerInfo", sizeof(sBrowseName));
							break;
						case 2296:
							BrbStringCopy(sBrowseName, "ServerRedundancy", sizeof(sBrowseName));
							break;
						case 2311:
							BrbStringCopy(sBrowseName, "TransitionEventType", sizeof(sBrowseName));
							break;
						case 2315:
							BrbStringCopy(sBrowseName, "AuditUpdateStateEventType", sizeof(sBrowseName));
							break;
						case 2378:
							BrbStringCopy(sBrowseName, "ProgramTransitionEventType", sizeof(sBrowseName));
							break;
						case 2738:
							BrbStringCopy(sBrowseName, "SemanticChangeEventType", sizeof(sBrowseName));
							break;
						case 2748:
							BrbStringCopy(sBrowseName, "AuditUrlMismatchEventType", sizeof(sBrowseName));
							break;
						case 2782:
							BrbStringCopy(sBrowseName, "ConditionType", sizeof(sBrowseName));
							break;
						case 2787:
							BrbStringCopy(sBrowseName, "RefreshStartEventType", sizeof(sBrowseName));
							break;
						case 2788:
							BrbStringCopy(sBrowseName, "RefreshEndEventType", sizeof(sBrowseName));
							break;
						case 2789:
							BrbStringCopy(sBrowseName, "RefreshRequiredEventType", sizeof(sBrowseName));
							break;
						case 2790:
							BrbStringCopy(sBrowseName, "AuditConditionEventType", sizeof(sBrowseName));
							break;
						case 2803:
							BrbStringCopy(sBrowseName, "AuditConditionEnableEventType", sizeof(sBrowseName));
							break;
						case 2829:
							BrbStringCopy(sBrowseName, "AuditConditionCommentEventType", sizeof(sBrowseName));
							break;
						case 2830:
							BrbStringCopy(sBrowseName, "DialogConditionType", sizeof(sBrowseName));
							break;
						case 2881:
							BrbStringCopy(sBrowseName, "AcknowledgeableConditionType", sizeof(sBrowseName));
							break;
						case 2915:
							BrbStringCopy(sBrowseName, "AlarmConditionType", sizeof(sBrowseName));
							break;
						case 2955:
							BrbStringCopy(sBrowseName, "LimitAlarmType", sizeof(sBrowseName));
							break;
						case 2992:
							BrbStringCopy(sBrowseName, "SecondsTillShutdown", sizeof(sBrowseName));
							break;
						case 2993:
							BrbStringCopy(sBrowseName, "ShutdownReason", sizeof(sBrowseName));
							break;
						case 2994:
							BrbStringCopy(sBrowseName, "Auditing", sizeof(sBrowseName));
							break;
						case 2996:
							BrbStringCopy(sBrowseName, "ModellingRules", sizeof(sBrowseName));
							break;
						case 2999:
							BrbStringCopy(sBrowseName, "AuditHistoryEventUpdateEventType", sizeof(sBrowseName));
							break;
						case 3006:
							BrbStringCopy(sBrowseName, "AuditHistoryValueUpdateEventType", sizeof(sBrowseName));
							break;
						case 3012:
							BrbStringCopy(sBrowseName, "AuditHistoryDeleteEventType", sizeof(sBrowseName));
							break;
						case 3014:
							BrbStringCopy(sBrowseName, "AuditHistoryRawModifyDeleteEventType", sizeof(sBrowseName));
							break;
						case 3019:
							BrbStringCopy(sBrowseName, "AuditHistoryAtTimeDeleteEventType", sizeof(sBrowseName));
							break;
						case 3022:
							BrbStringCopy(sBrowseName, "AuditHistoryEventDeleteEventType", sizeof(sBrowseName));
							break;
						case 3035:
							BrbStringCopy(sBrowseName, "EventQueueOverflowEventType", sizeof(sBrowseName));
							break;
						case 3048:
							BrbStringCopy(sBrowseName, "EventTypes", sizeof(sBrowseName));
							break;
						case 3065:
							BrbStringCopy(sBrowseName, "AlwaysGeneratesEvent", sizeof(sBrowseName));
							break;
						case 3706:
							BrbStringCopy(sBrowseName, "SessionsDiagnosticsSummary", sizeof(sBrowseName));
							break;
						case 3709:
							BrbStringCopy(sBrowseName, "RedundancySupport", sizeof(sBrowseName));
							break;
						case 3806:
							BrbStringCopy(sBrowseName, "ProgramTransitionAuditEventType", sizeof(sBrowseName));
							break;
						case 7594:
							BrbStringCopy(sBrowseName, "EnumValueType", sizeof(sBrowseName));
							break;
						case 8912:
							BrbStringCopy(sBrowseName, "TimeZoneDataType", sizeof(sBrowseName));
							break;
						case 8927:
							BrbStringCopy(sBrowseName, "AuditConditionRespondEventType", sizeof(sBrowseName));
							break;
						case 8944:
							BrbStringCopy(sBrowseName, "AuditConditionAcknowledgeEventType", sizeof(sBrowseName));
							break;
						case 8961:
							BrbStringCopy(sBrowseName, "AuditConditionConfirmEventType", sizeof(sBrowseName));
							break;
						case 9004:
							BrbStringCopy(sBrowseName, "HasTrueSubState", sizeof(sBrowseName));
							break;
						case 9005:
							BrbStringCopy(sBrowseName, "HasFalseSubState", sizeof(sBrowseName));
							break;
						case 9006:
							BrbStringCopy(sBrowseName, "HasCondition", sizeof(sBrowseName));
							break;
						case 9341:
							BrbStringCopy(sBrowseName, "ExclusiveLimitAlarmType", sizeof(sBrowseName));
							break;
						case 9482:
							BrbStringCopy(sBrowseName, "ExclusiveLevelAlarmType", sizeof(sBrowseName));
							break;
						case 9623:
							BrbStringCopy(sBrowseName, "ExclusiveRateOfChangeAlarmType", sizeof(sBrowseName));
							break;
						case 9764:
							BrbStringCopy(sBrowseName, "ExclusiveDeviationAlarmType", sizeof(sBrowseName));
							break;
						case 9906:
							BrbStringCopy(sBrowseName, "NonExclusiveLimitAlarmType", sizeof(sBrowseName));
							break;
						case 10060:
							BrbStringCopy(sBrowseName, "NonExclusiveLevelAlarmType", sizeof(sBrowseName));
							break;
						case 10214:
							BrbStringCopy(sBrowseName, "NonExclusiveRateOfChangeAlarmType", sizeof(sBrowseName));
							break;
						case 10368:
							BrbStringCopy(sBrowseName, "NonExclusiveDeviationAlarmType", sizeof(sBrowseName));
							break;
						case 10523:
							BrbStringCopy(sBrowseName, "DiscreteAlarmType", sizeof(sBrowseName));
							break;
						case 10637:
							BrbStringCopy(sBrowseName, "OffNormalAlarmType", sizeof(sBrowseName));
							break;
						case 10751:
							BrbStringCopy(sBrowseName, "TripAlarmType", sizeof(sBrowseName));
							break;
						case 11093:
							BrbStringCopy(sBrowseName, "AuditConditionShelvingEventType", sizeof(sBrowseName));
							break;
						case 11216:
							BrbStringCopy(sBrowseName, "ModificationInfo", sizeof(sBrowseName));
							break;
						case 11234:
							BrbStringCopy(sBrowseName, "HistoryUpdateType", sizeof(sBrowseName));
							break;
						case 11293:
							BrbStringCopy(sBrowseName, "PerformUpdateType", sizeof(sBrowseName));
							break;
						case 11436:
							BrbStringCopy(sBrowseName, "ProgressEventType", sizeof(sBrowseName));
							break;
						case 11446:
							BrbStringCopy(sBrowseName, "SystemStatusChangeEventType", sizeof(sBrowseName));
							break;
						case 11508:
							BrbStringCopy(sBrowseName, "OptionalPlaceholder", sizeof(sBrowseName));
							break;
						case 11510:
							BrbStringCopy(sBrowseName, "MandatoryPlaceholder", sizeof(sBrowseName));
							break;
						case 11704:
							BrbStringCopy(sBrowseName, "OperationLimits", sizeof(sBrowseName));
							break;
						case 11717:
							BrbStringCopy(sBrowseName, "Namespaces", sizeof(sBrowseName));
							break;
						case 11737:
							BrbStringCopy(sBrowseName, "BitFieldMaskDataType", sizeof(sBrowseName));
							break;
						case 11753:
							BrbStringCopy(sBrowseName, "SystemOffNormalAlarmType", sizeof(sBrowseName));
							break;
						case 11856:
							BrbStringCopy(sBrowseName, "AuditProgramTransitionEventType", sizeof(sBrowseName));
							break;
						case 11939:
							BrbStringCopy(sBrowseName, "OpenFileMode", sizeof(sBrowseName));
							break;
						case 11943:
							BrbStringCopy(sBrowseName, "EndpointUrlListDataType", sizeof(sBrowseName));
							break;
						case 12077:
							BrbStringCopy(sBrowseName, "AxisScaleEnumeration", sizeof(sBrowseName));
							break;
						case 12079:
							BrbStringCopy(sBrowseName, "AxisInformation", sizeof(sBrowseName));
							break;
						case 12080:
							BrbStringCopy(sBrowseName, "XVType", sizeof(sBrowseName));
							break;
						case 12171:
							BrbStringCopy(sBrowseName, "ComplexNumberType", sizeof(sBrowseName));
							break;
						case 12172:
							BrbStringCopy(sBrowseName, "DoubleComplexNumberType", sizeof(sBrowseName));
							break;
						case 12189:
							BrbStringCopy(sBrowseName, "ServerOnNetwork", sizeof(sBrowseName));
							break;
						case 12552:
							BrbStringCopy(sBrowseName, "TrustListMasks", sizeof(sBrowseName));
							break;
						case 12554:
							BrbStringCopy(sBrowseName, "TrustListDataType", sizeof(sBrowseName));
							break;
						case 12561:
							BrbStringCopy(sBrowseName, "TrustListUpdatedAuditEventType", sizeof(sBrowseName));
							break;
						case 12620:
							BrbStringCopy(sBrowseName, "CertificateUpdatedAuditEventType", sizeof(sBrowseName));
							break;
						case 12755:
							BrbStringCopy(sBrowseName, "OptionSet", sizeof(sBrowseName));
							break;
						case 12756:
							BrbStringCopy(sBrowseName, "Union", sizeof(sBrowseName));
							break;
						case 12877:
							BrbStringCopy(sBrowseName, "NormalizedString", sizeof(sBrowseName));
							break;
						case 12878:
							BrbStringCopy(sBrowseName, "DecimalString", sizeof(sBrowseName));
							break;
						case 12879:
							BrbStringCopy(sBrowseName, "DurationString", sizeof(sBrowseName));
							break;
						case 12880:
							BrbStringCopy(sBrowseName, "TimeString", sizeof(sBrowseName));
							break;
						case 12881:
							BrbStringCopy(sBrowseName, "DateString", sizeof(sBrowseName));
							break;
						case 12890:
							BrbStringCopy(sBrowseName, "DiscoveryConfiguration", sizeof(sBrowseName));
							break;
						case 12891:
							BrbStringCopy(sBrowseName, "MdnsDiscoveryConfiguration", sizeof(sBrowseName));
							break;
						case 13225:
							BrbStringCopy(sBrowseName, "CertificateExpirationAlarmType", sizeof(sBrowseName));
							break;
						case 14476:
							BrbStringCopy(sBrowseName, "HasPubSubConnection", sizeof(sBrowseName));
							break;
						case 14524:
							BrbStringCopy(sBrowseName, "FieldMetaData", sizeof(sBrowseName));
							break;
						case 14525:
							BrbStringCopy(sBrowseName, "DataTypeDescription", sizeof(sBrowseName));
							break;
						case 14533:
							BrbStringCopy(sBrowseName, "KeyValuePair", sizeof(sBrowseName));
							break;
						case 14744:
							BrbStringCopy(sBrowseName, "FieldTargetDataType", sizeof(sBrowseName));
							break;
						case 14936:
							BrbStringCopy(sBrowseName, "DataSetToWriter", sizeof(sBrowseName));
							break;
						case 15005:
							BrbStringCopy(sBrowseName, "SimpleTypeDescription", sizeof(sBrowseName));
							break;
						case 15006:
							BrbStringCopy(sBrowseName, "UABinaryFileDataType", sizeof(sBrowseName));
							break;
						case 15013:
							BrbStringCopy(sBrowseName, "AuditConditionResetEventType", sizeof(sBrowseName));
							break;
						case 15031:
							BrbStringCopy(sBrowseName, "AccessLevelType", sizeof(sBrowseName));
							break;
						case 15033:
							BrbStringCopy(sBrowseName, "EventNotifierType", sizeof(sBrowseName));
							break;
						case 15112:
							BrbStringCopy(sBrowseName, "HasGuard", sizeof(sBrowseName));
							break;
						case 15296:
							BrbStringCopy(sBrowseName, "HasDataSetWriter", sizeof(sBrowseName));
							break;
						case 15297:
							BrbStringCopy(sBrowseName, "HasDataSetReader", sizeof(sBrowseName));
							break;
						case 15406:
							BrbStringCopy(sBrowseName, "AccessLevelExType", sizeof(sBrowseName));
							break;
						case 15487:
							BrbStringCopy(sBrowseName, "StructureDescription", sizeof(sBrowseName));
							break;
						case 15488:
							BrbStringCopy(sBrowseName, "EnumDescription", sizeof(sBrowseName));
							break;
						case 15528:
							BrbStringCopy(sBrowseName, "EndpointType", sizeof(sBrowseName));
							break;
						case 15534:
							BrbStringCopy(sBrowseName, "DataTypeSchemaHeader", sizeof(sBrowseName));
							break;
						case 15535:
							BrbStringCopy(sBrowseName, "PubSubStatusEventType", sizeof(sBrowseName));
							break;
						case 15548:
							BrbStringCopy(sBrowseName, "PubSubTransportLimitsExceedEventType", sizeof(sBrowseName));
							break;
						case 15563:
							BrbStringCopy(sBrowseName, "PubSubCommunicationFailureEventType", sizeof(sBrowseName));
							break;
						case 15606:
							BrbStringCopy(sBrowseName, "RoleSet", sizeof(sBrowseName));
							break;
						case 15632:
							BrbStringCopy(sBrowseName, "IdentityCriteriaType", sizeof(sBrowseName));
							break;
						case 15634:
							BrbStringCopy(sBrowseName, "IdentityMappingRuleType", sizeof(sBrowseName));
							break;
						case 15644:
							BrbStringCopy(sBrowseName, "Anonymous", sizeof(sBrowseName));
							break;
						case 15656:
							BrbStringCopy(sBrowseName, "AuthenticatedUser", sizeof(sBrowseName));
							break;
						case 15668:
							BrbStringCopy(sBrowseName, "Observer", sizeof(sBrowseName));
							break;
						case 15680:
							BrbStringCopy(sBrowseName, "Operator", sizeof(sBrowseName));
							break;
						case 15692:
							BrbStringCopy(sBrowseName, "Supervisor", sizeof(sBrowseName));
							break;
						case 15704:
							BrbStringCopy(sBrowseName, "SecurityAdmin", sizeof(sBrowseName));
							break;
						case 15716:
							BrbStringCopy(sBrowseName, "ConfigureAdmin", sizeof(sBrowseName));
							break;
						case 15874:
							BrbStringCopy(sBrowseName, "OverrideValueHandling", sizeof(sBrowseName));
							break;
						case 16036:
							BrbStringCopy(sBrowseName, "Engineer", sizeof(sBrowseName));
							break;
						case 16307:
							BrbStringCopy(sBrowseName, "AudioDataType", sizeof(sBrowseName));
							break;
						case 16313:
							BrbStringCopy(sBrowseName, "AdditionalParametersType", sizeof(sBrowseName));
							break;
						case 16361:
							BrbStringCopy(sBrowseName, "HasAlarmSuppressionGroup", sizeof(sBrowseName));
							break;
						case 16362:
							BrbStringCopy(sBrowseName, "AlarmGroupMember", sizeof(sBrowseName));
							break;
						case 17080:
							BrbStringCopy(sBrowseName, "DiscrepancyAlarmType", sizeof(sBrowseName));
							break;
						case 17225:
							BrbStringCopy(sBrowseName, "AuditConditionSuppressionEventType", sizeof(sBrowseName));
							break;
						case 17242:
							BrbStringCopy(sBrowseName, "AuditConditionSilenceEventType", sizeof(sBrowseName));
							break;
						case 17259:
							BrbStringCopy(sBrowseName, "AuditConditionOutOfServiceEventType", sizeof(sBrowseName));
							break;
						case 17276:
							BrbStringCopy(sBrowseName, "HasEffectDisable", sizeof(sBrowseName));
							break;
						case 17548:
							BrbStringCopy(sBrowseName, "EphemeralKeyType", sizeof(sBrowseName));
							break;
						case 17588:
							BrbStringCopy(sBrowseName, "Index", sizeof(sBrowseName));
							break;
						case 17594:
							BrbStringCopy(sBrowseName, "Dictionaries", sizeof(sBrowseName));
							break;
						case 17597:
							BrbStringCopy(sBrowseName, "HasDictionaryEntry", sizeof(sBrowseName));
							break;
						case 17603:
							BrbStringCopy(sBrowseName, "HasInterface", sizeof(sBrowseName));
							break;
						case 17604:
							BrbStringCopy(sBrowseName, "HasAddIn", sizeof(sBrowseName));
							break;
						case 17641:
							BrbStringCopy(sBrowseName, "RoleMappingRuleChangedAuditEventType", sizeof(sBrowseName));
							break;
						case 17983:
							BrbStringCopy(sBrowseName, "HasEffectEnable", sizeof(sBrowseName));
							break;
						case 17984:
							BrbStringCopy(sBrowseName, "HasEffectSuppressed", sizeof(sBrowseName));
							break;
						case 17985:
							BrbStringCopy(sBrowseName, "HasEffectUnsuppressed", sizeof(sBrowseName));
							break;
						case 18011:
							BrbStringCopy(sBrowseName, "KeyCredentialAuditEventType", sizeof(sBrowseName));
							break;
						case 18029:
							BrbStringCopy(sBrowseName, "KeyCredentialUpdatedAuditEventType", sizeof(sBrowseName));
							break;
						case 18047:
							BrbStringCopy(sBrowseName, "KeyCredentialDeletedAuditEventType", sizeof(sBrowseName));
							break;
						case 18347:
							BrbStringCopy(sBrowseName, "InstrumentDiagnosticAlarmType", sizeof(sBrowseName));
							break;
						case 18496:
							BrbStringCopy(sBrowseName, "SystemDiagnosticAlarmType", sizeof(sBrowseName));
							break;
						case 18804:
							BrbStringCopy(sBrowseName, "HasWriterGroup", sizeof(sBrowseName));
							break;
						case 18805:
							BrbStringCopy(sBrowseName, "HasReaderGroup", sizeof(sBrowseName));
							break;
						case 18806:
							BrbStringCopy(sBrowseName, "RationalNumber", sizeof(sBrowseName));
							break;
						case 18807:
							BrbStringCopy(sBrowseName, "Vector", sizeof(sBrowseName));
							break;
						case 18808:
							BrbStringCopy(sBrowseName, "3DVector", sizeof(sBrowseName));
							break;
						case 18809:
							BrbStringCopy(sBrowseName, "CartesianCoordinates", sizeof(sBrowseName));
							break;
						case 18810:
							BrbStringCopy(sBrowseName, "3DCartesianCoordinates", sizeof(sBrowseName));
							break;
						case 18811:
							BrbStringCopy(sBrowseName, "Orientation", sizeof(sBrowseName));
							break;
						case 18812:
							BrbStringCopy(sBrowseName, "3DOrientation", sizeof(sBrowseName));
							break;
						case 18813:
							BrbStringCopy(sBrowseName, "Frame", sizeof(sBrowseName));
							break;
						case 18814:
							BrbStringCopy(sBrowseName, "3DFrame", sizeof(sBrowseName));
							break;
						case 19095:
							BrbStringCopy(sBrowseName, "AuditHistoryAnnotationUpdateEventType", sizeof(sBrowseName));
							break;
						case 19297:
							BrbStringCopy(sBrowseName, "TrustListOutOfDateAlarmType", sizeof(sBrowseName));
							break;
						case 19723:
							BrbStringCopy(sBrowseName, "DiagnosticsLevel", sizeof(sBrowseName));
							break;
						case 20998:
							BrbStringCopy(sBrowseName, "VersionTime", sizeof(sBrowseName));
							break;
						case 23468:
							BrbStringCopy(sBrowseName, "AliasNameDataType", sizeof(sBrowseName));
							break;
						case 23469:
							BrbStringCopy(sBrowseName, "AliasFor", sizeof(sBrowseName));
							break;
						case 23498:
							BrbStringCopy(sBrowseName, "CurrencyUnitType", sizeof(sBrowseName));
							break;
						case 23564:
							BrbStringCopy(sBrowseName, "TrustListValidationOptions", sizeof(sBrowseName));
							break;
						case 23606:
							BrbStringCopy(sBrowseName, "AuditClientEventType", sizeof(sBrowseName));
							break;
						case 23751:
							BrbStringCopy(sBrowseName, "UriString", sizeof(sBrowseName));
							break;
						case 23562:
							BrbStringCopy(sBrowseName, "IsDeprecated", sizeof(sBrowseName));
							break;
						case 23926:
							BrbStringCopy(sBrowseName, "AuditClientUpdateMethodResultEventType", sizeof(sBrowseName));
							break;
						case 24033:
							BrbStringCopy(sBrowseName, "ProgramDiagnostic2DataType", sizeof(sBrowseName));
							break;
						case 24105:
							BrbStringCopy(sBrowseName, "PortableQualifiedName", sizeof(sBrowseName));
							break;
						case 24106:
							BrbStringCopy(sBrowseName, "PortableNodeId", sizeof(sBrowseName));
							break;
						case 24107:
							BrbStringCopy(sBrowseName, "UnsignedRationalNumber", sizeof(sBrowseName));
							break;
						case 24136:
							BrbStringCopy(sBrowseName, "HasStructuredComponent", sizeof(sBrowseName));
							break;
						case 24137:
							BrbStringCopy(sBrowseName, "AssociatedWith", sizeof(sBrowseName));
							break;
						case 24210:
							BrbStringCopy(sBrowseName, "Duplex", sizeof(sBrowseName));
							break;
						case 24212:
							BrbStringCopy(sBrowseName, "InterfaceAdminStatus", sizeof(sBrowseName));
							break;
						case 24214:
							BrbStringCopy(sBrowseName, "InterfaceOperStatus", sizeof(sBrowseName));
							break;
						case 24216:
							BrbStringCopy(sBrowseName, "NegotiationStatus", sizeof(sBrowseName));
							break;
						case 24263:
							BrbStringCopy(sBrowseName, "SemanticVersionString", sizeof(sBrowseName));
							break;
						case 24277:
							BrbStringCopy(sBrowseName, "PasswordOptionsMask", sizeof(sBrowseName));
							break;
						case 24279:
							BrbStringCopy(sBrowseName, "UserConfigurationMask", sizeof(sBrowseName));
							break;
						case 24281:
							BrbStringCopy(sBrowseName, "UserManagementDataType", sizeof(sBrowseName));
							break;
						case 25237:
							BrbStringCopy(sBrowseName, "UsesPriorityMappingTable", sizeof(sBrowseName));
							break;
						case 25238:
							BrbStringCopy(sBrowseName, "HasLowerLayerInterface", sizeof(sBrowseName));
							break;
						case 25253:
							BrbStringCopy(sBrowseName, "IsExecutableOn", sizeof(sBrowseName));
							break;
						case 25254:
							BrbStringCopy(sBrowseName, "Controls", sizeof(sBrowseName));
							break;
						case 25255:
							BrbStringCopy(sBrowseName, "Utilizes", sizeof(sBrowseName));
							break;
						case 25256:
							BrbStringCopy(sBrowseName, "Requires", sizeof(sBrowseName));
							break;
						case 25257:
							BrbStringCopy(sBrowseName, "IsPhysicallyConnectedTo", sizeof(sBrowseName));
							break;
						case 25258:
							BrbStringCopy(sBrowseName, "RepresentsSameEntityAs", sizeof(sBrowseName));
							break;
						case 25259:
							BrbStringCopy(sBrowseName, "RepresentsSameHardwareAs", sizeof(sBrowseName));
							break;
						case 25260:
							BrbStringCopy(sBrowseName, "RepresentsSameFunctionalityAs", sizeof(sBrowseName));
							break;
						case 25261:
							BrbStringCopy(sBrowseName, "IsHostedBy", sizeof(sBrowseName));
							break;
						case 25262:
							BrbStringCopy(sBrowseName, "HasPhysicalComponent", sizeof(sBrowseName));
							break;
						case 25263:
							BrbStringCopy(sBrowseName, "HasContainedComponent", sizeof(sBrowseName));
							break;
						case 25264:
							BrbStringCopy(sBrowseName, "HasAttachedComponent", sizeof(sBrowseName));
							break;
						case 25265:
							BrbStringCopy(sBrowseName, "IsExecutingOn", sizeof(sBrowseName));
							break;
						case 25345:
							BrbStringCopy(sBrowseName, "HasPushedSecurityGroup", sizeof(sBrowseName));
							break;
						case 25726:
							BrbStringCopy(sBrowseName, "EncodedTicket", sizeof(sBrowseName));
							break;
						case 31917:
							BrbStringCopy(sBrowseName, "Handle", sizeof(sBrowseName));
							break;
						case 31918:
							BrbStringCopy(sBrowseName, "TrimmedString", sizeof(sBrowseName));
							break;
						case 32059:
							BrbStringCopy(sBrowseName, "AlarmSuppressionGroupMember", sizeof(sBrowseName));
							break;
						case 32251:
							BrbStringCopy(sBrowseName, "AlarmMask", sizeof(sBrowseName));
							break;
						case 32260:
							BrbStringCopy(sBrowseName, "TrustListUpdateRequestedAuditEventType", sizeof(sBrowseName));
							break;
						case 32285:
							BrbStringCopy(sBrowseName, "TransactionErrorType", sizeof(sBrowseName));
							break;
						case 32306:
							BrbStringCopy(sBrowseName, "CertificateUpdateRequestedAuditEventType", sizeof(sBrowseName));
							break;
						case 32407:
							BrbStringCopy(sBrowseName, "HasKeyValueDescription", sizeof(sBrowseName));
							break;
						case 32417:
							BrbStringCopy(sBrowseName, "RedundantServerMode", sizeof(sBrowseName));
							break;
						case 32421:
							BrbStringCopy(sBrowseName, "BitFieldDefinition", sizeof(sBrowseName));
							break;
						case 32434:
							BrbStringCopy(sBrowseName, "AnnotationDataType", sizeof(sBrowseName));
							break;
						case 32435:
							BrbStringCopy(sBrowseName, "LinearConversionDataType", sizeof(sBrowseName));
							break;
						case 32436:
							BrbStringCopy(sBrowseName, "ConversionLimitEnum", sizeof(sBrowseName));
							break;
						case 32438:
							BrbStringCopy(sBrowseName, "QuantityDimension", sizeof(sBrowseName));
							break;
						case 32558:
							BrbStringCopy(sBrowseName, "HasEngineeringUnitDetails", sizeof(sBrowseName));
							break;
						case 32559:
							BrbStringCopy(sBrowseName, "HasQuantity", sizeof(sBrowseName));
							break;
						case 32633:
							BrbStringCopy(sBrowseName, "HasCurrentData", sizeof(sBrowseName));
							break;
						case 32634:
							BrbStringCopy(sBrowseName, "HasCurrentEvent", sizeof(sBrowseName));
							break;
						case 32659:
							BrbStringCopy(sBrowseName, "ReferenceDescriptionDataType", sizeof(sBrowseName));
							break;
						case 32660:
							BrbStringCopy(sBrowseName, "ReferenceListEntryDataType", sizeof(sBrowseName));
							break;
						case 32679:
							BrbStringCopy(sBrowseName, "HasReferenceDescription", sizeof(sBrowseName));
							break;
						case 32758:
							BrbStringCopy(sBrowseName, "AuditHistoryConfigurationChangeEventType", sizeof(sBrowseName));
							break;
						case 32803:
							BrbStringCopy(sBrowseName, "AuditHistoryBulkInsertEventType", sizeof(sBrowseName));
							break;
						case 32824:
							BrbStringCopy(sBrowseName, "HistoryModifiedEvent", sizeof(sBrowseName));
							break;
					}
				}
			}
		}
		if (brsstrlen((UDINT)&sBrowseName) != 0)
		{
			BrbStringCat(pText, " - ", nTextSize);
			BrbStringCat(pText, sBrowseName, nTextSize);
		}
	}
	return nStatus;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*, hicpp-function-size)
