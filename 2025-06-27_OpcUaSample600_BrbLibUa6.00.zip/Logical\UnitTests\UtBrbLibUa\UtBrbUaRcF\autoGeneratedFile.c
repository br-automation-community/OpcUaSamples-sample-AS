/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (List of TestSets).
LastUpdated: 2024-09-26 10:43:03Z
By B+R UnitTest Helper Version: 6.0.0.173
*/
#include "UnitTest.h"



UNITTEST_TESTSET_DECLARATION  Set_BrbUaRcFull;



UNITTEST_TESTSET_FIXTURES(utTestSets)
{
	new_TestSet(Set_BrbUaRcFull),
};
UNTITTEST_TESTSET_HANDLER();

