
Hier werden Variablen zur Verf�gung gestellt, die der eigene OpcUa-Server ver�ffentlicht.

Der Server ist in der ConfigurationView in den Dateien 'Connectivity/OpcUaCs/UaCsConfig.uacfg' und '.../UaDvConfig.uadcfg'
parametriert.
Hinweis: Ab AS6.0 ist das PV-Informationsmodell des Servers nicht mehr einzustellen. Es ist immer das
Informationsmodell V2.0 aus AS4.12 eingestellt.
F�r die Rechte-Vergabe an den einzelnen Datenpunkten (z.B. f�r die Variable 'nOperatorNonBrowsable') siehe
"ReadMePermissions.txt".

Daten sind als globale Variable 'gVarsGlobal' und als lokale Variable 'VarsLocal' angelegt.
Sie wurden in der Datei 'OpcUaCsMap.uad' (siehe ConfigurationView/Connectivity/OpcUa) f�r den Server konfiguriert.
Sie enthalten die Strukturen 'Read', 'Write' und 'ReadWrite', welche auch so parametriert sind.
Diese wiederum enthalten jeweils ein Unterelement jeden Standard-Datentyps.
Definition siehe LogicalView/Global.typ.
Die Elemente der Unter-Struktur 'Read' werden im Task-Takt (500ms) ge�ndert.
Achtung: W�rden z.B. bei dem Struktur-Knoten 'VarsLocal' die Zugriffsrechte auf Read+Write gesetzt, k�nnten �ber
einen Zugriff darauf die Unterelemente in 'WriteOnly' gelesen und in 'ReadOnly' geschrieben werden. Diese Art der
Parametrierung ist unbedingt zu vermeiden, da sie zu Fehlzugriffen f�hren kann, die man sehr schwer findet. Um
dies hier zu verhindern, ist dieser �bergeordnete Knoten weder les- noch schreibbar.
Dazu werden zwei Varianten gezeigt:
	Bei der lokalen Variable 'VarsLocal' wurde an der Einstellung AccessLevel weder Read noch Write angehakt. Deshalb
	bleibt der Knoten zwar eine Variable, diese ist aber weder les- noch schreibbar.
	Bei der globalen Variable 'gVarsGlobal' wurde die NodeClass von 'Variable' auf 'Object' ge�ndert. Dies erreicht man,
	in dem in 'UaCsConfig.uacfg' beim Knoten in der Spalte 'UA Type Definition' der Wert 'i=58' eingetragen wird. Dieser
	Wert zeigt auf den Datentyp 'Root/Types/ObjectTypes/BaseObjectType'. Das bewirkt, dass der Knoten nicht mehr als
	Variable, sondern als Object ver�ffentlicht wird, also keinen Wert besitzt, somit also auch weder les- noch schreibbar
	ist.

Eine �bersetzung des Attributes 'Description' ist beispielhaft bei den beiden Knoten 'gVarsGlobal' und 'VarsLocal'
implementiert. Dabei werden die Texte aus der Datei 'Texts/OpcUaServerTexts.tmx' verwendet.

Ausserdem gibt es die Strukturen 'WriteC' und 'WriteST', auf deren Elemente teilweise von den Clients geschrieben wird.

Einsatz von dynamischen Arrays:
	Auf einer SPS kann ein Array nie dynamisch sein, also keine variable L�nge haben. Die L�nge eines Arrays 
	muss zur Projektierungszeit im AS  festgelegt werden und kann zur Laufzeit nicht mehr ge�ndert werden.
	OpcUa unters�tzt jedoch dynamische Arrays.
	Der B&R-Server kann mit einem Trick ein in der SPS deklariertes Array OpcUa-seitig als dynamisch
	ausliefern. Auch ein empfangenes dynamisches Array kann so auf ein festes SPS-Array �bertragen werden.
	Als einfaches Beispiel dient hier die Variable 'DynamicUintArrayLength', welche durch einen selbstdefinierten
	Datentyp deklariert wird. Der Datentyp sieht so aus:
		DynamicUintArrayLength_TYP : 	STRUCT 
			nLength : BrUaArrayLength;
			anData : ARRAY[0..9]OF UINT;
		END_STRUCT;
	Das Element 'anData' enth�lt das Array mit fester maximaler L�nge, wie auf der SPS ben�tigt.
	Das Element 'nLength' enth�lt die Anzahl der g�ltigen Array-Elemente. Durch Setzen dieses Wertes wird	das am 
	OpcUa-Server bediente Array angepasst.
	Die Variable wird ganz normal am OpcUa-Server freigegeben (ohne Unter-Elemente). Das System erkennt aufgrund der
	Deklaration, dass diese	Variable ein dynamisches Array ist und behandelt es entsprechend.
	Bei einem DirectRead oder als MonitoredItem einer Subscription wird ein Array mit der aktuellen L�nge �bertragen.
	Bei einem DirectWrite werden die als Array �bertragene Werte in 'anData' geschrieben und 'nLength' entsprechend
	gesetzt.
	Die L�nge kann anstatt als 'BrUaArrayLength' auch als 'BrUaNoOfElements' deklariert werden. Der Unterschied ist das Format,
	in welchem das Array an den Client �bertragen bzw. vom Client erwartet wird:
		BrUaArrayLength:		Wird als Uint16[] �bertragen.
		BrUaNoOfElements:		Wird als ExtensionObject �bertragen. Es enth�lt das UINT-Array.
		
	Als Beispiel f�r die zweite Variante ist die Variable 'DynamicUintArrayElements' implementiert. �ber einen Test-Client
	wie UaExpert oder RnCommTest kann der Unterschied des Formats sehr leicht erkannt werden.
	Welche Variante verwendet werden sollte, h�ngt davon ab, mit welchem Format der Client umgehen kann. Sps-seitig ist
	Behandlung identisch.
	
	Dieses Konzept funktioniert nicht nur mit allen Standard-Datentypen, sondern auch mit Struktur-Arrays. Als Beispiele
	sind die beiden Variablen 'DynamicStructArrayLength' bzw. 'DynamicStructArrayElements' implementiert.
	Achtung: Mindestens eine skalare Instanz der verwendeten Struktur muss freigegeben sein, damit der Datentyp vom Server
	ver�ffentlicht wird und es dem Client so erm�glicht, die Struktur aufzul�sen. Wenn der Struktur-Datentyp nur im Array
	verwendet wird, ist dies nicht der Fall!
	
	Achtung: Bei einem Schreib-Zugriff auf ein dynamisches Array darf die Anzahl der geschriebenen Elemente NICHT die 
	L�nge des Array 'anData' �berschreiten, da der Server dann die empfangenen Daten nicht in das Array �bertragen kann.
	Wird dies	doch gemacht, f�hrt der Server den Schreibauftrag nicht aus und gibt den Status
	'0x8074000' = BadTypeMismatch	zur�ck!
	
	Hinweis: Bei dynamischen Arrays werden nur 1-dimensionale, aber keine mehrdimensionalen Arrays unterst�tzt.
	
	Implementierung im Beispiel-Task:
	Die Arrays werden im Init des Tasks vorbesetzt. Im zyklischen Teil (500ms) werden nur die L�ngen der einzelnen
	Instanzen zuf�llig ver�ndert.
	
Schreibbare Attribute:
	Die Variable 'nWritableAttributes' ist in der Datei 'OpcUaCsMap.uad' so parametriert, dass die Attribute
	'BrowseName', 'DisplayName' und 'Description' von einem Client beschrieben werden k�nnen.
	Achtung: Ge�nderte Werte sind nicht warmstartsicher!
	
Rechte-Vergabe:
	Die Variable 'nOperatorNonBrowsable' wurde zur Veranschaulichung der Rechte-Vergabe implementiert (siehe
	"ReadMePermissions.txt").

Ver�ffentlichung von Struktur-Typen
	Wird eine Struktur-Variable ver�ffentlicht, so wird der Wert als Byte-Array �bertragen. Der Server packt die
	einzelnen	Elemente der Struktur nach spezifizierten Regeln in dieses Byte-Array. Damit der Client dieses Array
	wieder in die urspr�ngliche Struktur-Form zur�ckwandeln kann, ben�tigt er die Definition dieser Struktur.
	Dieser 'Struktur-Bauplan' wird vom Kompiler automatisch erzeugt und alle ben�tigten Knoten aufgelegt.
	Ab der ersten Server-Spezifikation gab es daf�r ein Konzept namens 'ComplexType Server Facet', welches die Baupl�ne
	aller	ben�tigten Strukturen als sogenanntes 'Dictionary' ver�ffentlicht. Dies bedeutet, dass der Client durch
	Folgen von mehreren Referenzen ab dem Datentyp-Knoten schliesslich an einem Knoten landet, der die Baupl�ne als
	Xml-formatierten String	beinhaltet.
	Ab 2017 wurde ein zus�tzliches Konzept namens 'ComplexType 2017 Server Facet' spezifiziert, welches performanter
	ist. Dabei hat der Datentyp-Knoten ein neues Attribut 'DataTypeDefinition', welches die Elemente der Struktur als
	Array	enth�lt. Diese Form ist f�r den Client wesentlich einfacher und schneller aufzul�sen.
	Welches Format der Server zur Verf�gung stellen soll, h�ngt nat�rlich davon ab, was die verbundenen Clients
	unterst�tzen. Deshalb gibt es in der Datei 	'UaDvConfig.uadcfg' die Einstellung 'ComplexTypeFacet', welche auf
	einer dieser Werte gesetzt werden kann:
		-ComplexType Server Facet						Nur die Daten der urspr�nglichen Variante werden erzeugt.
		-ComplexType 2017 Server Facet			Nur die Daten der 2017-Variante werden erzeugt.
		-Both																Die Daten beider Varianten werden erzeugt.
	Bei jeder Variante m�ssen Knoten bzw. Attribute erzeugt werden. Jeder Knoten und jedes Attribut ben�tigen aber
	auch Arbeitsspeicher zur Laufzeit.
	Die urspr�ngliche Variante braucht zwar mehr Knoten, wird aber auch von �lteren Clients	unterst�tzt.
	Die neuere Variante braucht bedeutend weniger Knoten, wird aber u.U. nicht von jedem Client unterst�tzt.
	Werden beide Varianten eingestellt, so k�nnen �ltere Clients unterst�tzt und gleichzeitig die neueren Clients
	performanter bedient werden. Dies braucht aber auch am meisten Arbeitsspeicher.
	In diesem Beispiel wurde die Einstellung 'Both' gew�hlt. So kann mit einem Test-Client der Unterschied untersucht
	werden.
	