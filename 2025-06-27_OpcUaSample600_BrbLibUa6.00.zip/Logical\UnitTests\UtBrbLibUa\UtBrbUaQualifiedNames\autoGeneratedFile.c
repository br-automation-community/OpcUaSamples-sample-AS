/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (List of TestSets).
LastUpdated: 2024-12-04 10:42:58Z
By B+R UnitTest Helper Version: 6.0.0.173
*/
#include "UnitTest.h"



UNITTEST_TESTSET_DECLARATION  Set_BrbUaSetQualifiedName;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaGetRandomQualifiedName;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaAddQualifiedNameString;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaEncodeBrowseNameForPath;



UNITTEST_TESTSET_FIXTURES(utTestSets)
{
	new_TestSet(Set_BrbUaSetQualifiedName),
	new_TestSet(Set_BrbUaGetRandomQualifiedName),
	new_TestSet(Set_BrbUaAddQualifiedNameString),
	new_TestSet(Set_BrbUaEncodeBrowseNameForPath),
};
UNTITTEST_TESTSET_HANDLER();

