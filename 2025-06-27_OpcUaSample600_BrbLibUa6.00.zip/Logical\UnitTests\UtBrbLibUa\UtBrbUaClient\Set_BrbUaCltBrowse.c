#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

_CYCLIC_SET(void)
{
	if(RunClient.State.eState >= eBRB_RCSTATE_INIT_DONE && RunClient.State.eState < eBRB_RCSTATE_EXITING)
	{
		if(bRunCyclic == 1)
		{
			fbBrbUaRunClientCyclic.pRunClient = &RunClient;
			BrbUaRunClientCyclic(&fbBrbUaRunClientCyclic);
		}
	}
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	return;
}

_TEST BrbUaBrowse_Init0(void)
{
	// Init
	memset(&fbBrbUaBrowse, 0, sizeof(fbBrbUaBrowse));
	memset(&aBrowseResults, 0, sizeof(aBrowseResults));
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_BrowseResults_NulPtr(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	fbBrbUaBrowse.nBrowseResultsIndexMax = nBROWSE_RESULTS_INDEX_MAX;
	fbBrbUaBrowse.pBrowseResults = 0;
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, fbBrbUaBrowse.nStatus);
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_InvConnectionHandle0(void)
{
	fbBrbUaBrowse.nConnectionHandle = 0;
	fbBrbUaBrowse.nBrowseResultsIndexMax = nBROWSE_RESULTS_INDEX_MAX;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_INVALID_PARAMETER, fbBrbUaBrowse.nStatus);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_InvConnectionHandle1(void)
{
	fbBrbUaBrowse.nConnectionHandle = 1;
	fbBrbUaBrowse.nBrowseResultsIndexMax = nBROWSE_RESULTS_INDEX_MAX;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_ERROR, fbBrbUaBrowse.nStatus);
	TEST_ASSERT_EQUAL_INT(0xA0000105, fbBrbUaBrowse.nErrorId); // UA_Bad_ConnectionInvalidHdl

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array1_MaxIdx0(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray1", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 0;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(1, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array1_MaxIdx1(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray1", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 1;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array1_MaxIdx199(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray1", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = nBROWSE_RESULTS_INDEX_MAX;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array63_MaxIdx31(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray63", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 31;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(32, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(31, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array63_MaxIdx61(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray63", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 61;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(62, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(1, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array63_MaxIdx62(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray63", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 62;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(63, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array63_MaxIdx199(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray63", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = nBROWSE_RESULTS_INDEX_MAX;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(63, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array64_MaxIdx32(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray64", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 32;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(33, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(31, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array64_MaxIdx62(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray64", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 62;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(63, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(1, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array64_MaxIdx63(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray64", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 63;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(64, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array64_MaxIdx199(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray64", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = nBROWSE_RESULTS_INDEX_MAX;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(64, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array65_MaxIdx32(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray65", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 32;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(33, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(32, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array65_MaxIdx63(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray65", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 63;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(64, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(1, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array65_MaxIdx64(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray65", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 64;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(65, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array65_MaxIdx199(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray65", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = nBROWSE_RESULTS_INDEX_MAX;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(65, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array127_MaxIdx63(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray127", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 63;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(64, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(63, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array127_MaxIdx125(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray127", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 125;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(126, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(1, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array127_MaxIdx126(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray127", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 126;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(127, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array127_MaxIdx199(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray127", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = nBROWSE_RESULTS_INDEX_MAX;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(127, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array128_MaxIdx64(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray128", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 64;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(65, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(63, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array128_MaxIdx126(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray128", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 126;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(127, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(1, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array128_MaxIdx127(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray128", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 127;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(128, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array128_MaxIdx199(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray128", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = nBROWSE_RESULTS_INDEX_MAX;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(128, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array129_MaxIdx64(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray129", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 64;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(65, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(64, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array129_MaxIdx127(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray129", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 127;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(128, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(1, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array129_MaxIdx128(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray129", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 128;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(129, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array129_MaxIdx199(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray129", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = nBROWSE_RESULTS_INDEX_MAX;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(129, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array191_MaxIdx95(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray191", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 95;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(96, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(95, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array191_MaxIdx189(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray191", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 189;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(190, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(1, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array191_MaxIdx190(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray191", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 190;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(191, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array191_MaxIdx199(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray191", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = nBROWSE_RESULTS_INDEX_MAX;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(191, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array192_MaxIdx96(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray192", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 96;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(97, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(95, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array192_MaxIdx190(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray192", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 190;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(191, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(1, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array192_MaxIdx191(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray192", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 191;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(192, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array192_MaxIdx199(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray192", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = nBROWSE_RESULTS_INDEX_MAX;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(192, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array193_MaxIdx96(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray193", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 96;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(97, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(96, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array193_MaxIdx191(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray193", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 191;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(192, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(1, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array193_MaxIdx192(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray193", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 192;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(193, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array193_MaxIdx199(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray193", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = nBROWSE_RESULTS_INDEX_MAX;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(193, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(0, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array256_MaxIdx64(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray256", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 64;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(65, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(191, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array256_MaxIdx128(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray256", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = 128;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(129, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(127, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

_TEST BrbUaBrowse_Array256_MaxIdx199(void)
{
	fbBrbUaBrowse.nConnectionHandle = RunClient.Connection.nConnectionHandle;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.StartingNodeID, "::UtBrbUaRs:BrowseArrays.anArray256", nNamespaceBrPlcPv);
	fbBrbUaBrowse.BrowseDescription.Direction = UABD_Forward;
	BrbUaSetNodeId(&fbBrbUaBrowse.BrowseDescription.ReferenceTypeID, "47", 0); // HasComponent
	fbBrbUaBrowse.BrowseDescription.IncludeSubtypes = 1;
	fbBrbUaBrowse.BrowseDescription.NodeClass = UANCM_All;
	fbBrbUaBrowse.BrowseDescription.ResultMask = UABRM_All;
	fbBrbUaBrowse.nBrowseResultsIndexMax = nBROWSE_RESULTS_INDEX_MAX;
	fbBrbUaBrowse.pBrowseResults = &aBrowseResults[0];
	fbBrbUaBrowse.tTimeout = 3000;
	BrbUaBrowse(&fbBrbUaBrowse);
	TEST_BUSY_CONDITION(fbBrbUaBrowse.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaBrowse.nStatus);
	BRB_ASSERT_EQUAL_UDINT(200, fbBrbUaBrowse.nBrowseResultsCount);
	BRB_ASSERT_EQUAL_UDINT(56, fbBrbUaBrowse.nRemainingBrowseResults);

	// Finished
	TEST_DONE;
}

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-12-03 09:52:56Z
By B+R UnitTest Helper Version: 6.0.0.173
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaBrowse_Init0", BrbUaBrowse_Init0), 
	new_TestFixture("BrbUaBrowse_BrowseResults_NulPtr", BrbUaBrowse_BrowseResults_NulPtr), 
	new_TestFixture("BrbUaBrowse_InvConnectionHandle0", BrbUaBrowse_InvConnectionHandle0), 
	new_TestFixture("BrbUaBrowse_InvConnectionHandle1", BrbUaBrowse_InvConnectionHandle1), 
	new_TestFixture("BrbUaBrowse_Array1_MaxIdx0", BrbUaBrowse_Array1_MaxIdx0), 
	new_TestFixture("BrbUaBrowse_Array1_MaxIdx1", BrbUaBrowse_Array1_MaxIdx1), 
	new_TestFixture("BrbUaBrowse_Array1_MaxIdx199", BrbUaBrowse_Array1_MaxIdx199), 
	new_TestFixture("BrbUaBrowse_Array63_MaxIdx31", BrbUaBrowse_Array63_MaxIdx31), 
	new_TestFixture("BrbUaBrowse_Array63_MaxIdx61", BrbUaBrowse_Array63_MaxIdx61), 
	new_TestFixture("BrbUaBrowse_Array63_MaxIdx62", BrbUaBrowse_Array63_MaxIdx62), 
	new_TestFixture("BrbUaBrowse_Array63_MaxIdx199", BrbUaBrowse_Array63_MaxIdx199), 
	new_TestFixture("BrbUaBrowse_Array64_MaxIdx32", BrbUaBrowse_Array64_MaxIdx32), 
	new_TestFixture("BrbUaBrowse_Array64_MaxIdx62", BrbUaBrowse_Array64_MaxIdx62), 
	new_TestFixture("BrbUaBrowse_Array64_MaxIdx63", BrbUaBrowse_Array64_MaxIdx63), 
	new_TestFixture("BrbUaBrowse_Array64_MaxIdx199", BrbUaBrowse_Array64_MaxIdx199), 
	new_TestFixture("BrbUaBrowse_Array65_MaxIdx32", BrbUaBrowse_Array65_MaxIdx32), 
	new_TestFixture("BrbUaBrowse_Array65_MaxIdx63", BrbUaBrowse_Array65_MaxIdx63), 
	new_TestFixture("BrbUaBrowse_Array65_MaxIdx64", BrbUaBrowse_Array65_MaxIdx64), 
	new_TestFixture("BrbUaBrowse_Array65_MaxIdx199", BrbUaBrowse_Array65_MaxIdx199), 
	new_TestFixture("BrbUaBrowse_Array127_MaxIdx63", BrbUaBrowse_Array127_MaxIdx63), 
	new_TestFixture("BrbUaBrowse_Array127_MaxIdx125", BrbUaBrowse_Array127_MaxIdx125), 
	new_TestFixture("BrbUaBrowse_Array127_MaxIdx126", BrbUaBrowse_Array127_MaxIdx126), 
	new_TestFixture("BrbUaBrowse_Array127_MaxIdx199", BrbUaBrowse_Array127_MaxIdx199), 
	new_TestFixture("BrbUaBrowse_Array128_MaxIdx64", BrbUaBrowse_Array128_MaxIdx64), 
	new_TestFixture("BrbUaBrowse_Array128_MaxIdx126", BrbUaBrowse_Array128_MaxIdx126), 
	new_TestFixture("BrbUaBrowse_Array128_MaxIdx127", BrbUaBrowse_Array128_MaxIdx127), 
	new_TestFixture("BrbUaBrowse_Array128_MaxIdx199", BrbUaBrowse_Array128_MaxIdx199), 
	new_TestFixture("BrbUaBrowse_Array129_MaxIdx64", BrbUaBrowse_Array129_MaxIdx64), 
	new_TestFixture("BrbUaBrowse_Array129_MaxIdx127", BrbUaBrowse_Array129_MaxIdx127), 
	new_TestFixture("BrbUaBrowse_Array129_MaxIdx128", BrbUaBrowse_Array129_MaxIdx128), 
	new_TestFixture("BrbUaBrowse_Array129_MaxIdx199", BrbUaBrowse_Array129_MaxIdx199), 
	new_TestFixture("BrbUaBrowse_Array191_MaxIdx95", BrbUaBrowse_Array191_MaxIdx95), 
	new_TestFixture("BrbUaBrowse_Array191_MaxIdx189", BrbUaBrowse_Array191_MaxIdx189), 
	new_TestFixture("BrbUaBrowse_Array191_MaxIdx190", BrbUaBrowse_Array191_MaxIdx190), 
	new_TestFixture("BrbUaBrowse_Array191_MaxIdx199", BrbUaBrowse_Array191_MaxIdx199), 
	new_TestFixture("BrbUaBrowse_Array192_MaxIdx96", BrbUaBrowse_Array192_MaxIdx96), 
	new_TestFixture("BrbUaBrowse_Array192_MaxIdx190", BrbUaBrowse_Array192_MaxIdx190), 
	new_TestFixture("BrbUaBrowse_Array192_MaxIdx191", BrbUaBrowse_Array192_MaxIdx191), 
	new_TestFixture("BrbUaBrowse_Array192_MaxIdx199", BrbUaBrowse_Array192_MaxIdx199), 
	new_TestFixture("BrbUaBrowse_Array193_MaxIdx96", BrbUaBrowse_Array193_MaxIdx96), 
	new_TestFixture("BrbUaBrowse_Array193_MaxIdx191", BrbUaBrowse_Array193_MaxIdx191), 
	new_TestFixture("BrbUaBrowse_Array193_MaxIdx192", BrbUaBrowse_Array193_MaxIdx192), 
	new_TestFixture("BrbUaBrowse_Array193_MaxIdx199", BrbUaBrowse_Array193_MaxIdx199), 
	new_TestFixture("BrbUaBrowse_Array256_MaxIdx64", BrbUaBrowse_Array256_MaxIdx64), 
	new_TestFixture("BrbUaBrowse_Array256_MaxIdx128", BrbUaBrowse_Array256_MaxIdx128), 
	new_TestFixture("BrbUaBrowse_Array256_MaxIdx199", BrbUaBrowse_Array256_MaxIdx199), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaCltBrowse, "Set_BrbUaCltBrowse", 0, 0, fixtures, 0, 0, cyclicSetCaller);

