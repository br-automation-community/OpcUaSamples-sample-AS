#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_TEST BrbUaEncodeBrowseNameForPath_NulPtr(void)
{
	dwordOut = BrbUaEncodeBrowseNameForPath(0);
	BRB_ASSERT_EQUAL_UDINT(0x80460000, dwordOut); // = Bad_StructureMissing

	// Finished
	TEST_DONE;
}

_TEST BrbUaEncodeBrowseNameForPath_Encode(void)
{
	// Alle codierten Zeichen
	strcpy(stringIn, "1&2!3#4:5>6<7.8/");
	dwordOut = BrbUaEncodeBrowseNameForPath(stringIn);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("1&&2&!3&#4&:5&>6&<7&.8&/", stringIn);

	// B&R-PV-Namepace-Uri
	strcpy(stringIn, "http://br-automation.com/OpcUa/PLC/PV/");
	dwordOut = BrbUaEncodeBrowseNameForPath(stringIn);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("http&:&/&/br-automation&.com&/OpcUa&/PLC&/PV&/", stringIn);

	// Nicht codierte Sonderzeichen
	strcpy(stringIn, "Test�Test$Test%Test(Test)Test=Test?Test+Test*Test~Test'Test,Test;Test-Test_Test");
	dwordOut = BrbUaEncodeBrowseNameForPath(stringIn);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test�Test$Test%Test(Test)Test=Test?Test+Test*Test~Test'Test,Test;Test-Test_Test", stringIn);

	// Zahlen
	strcpy(stringIn, "Test0Test1Test2Test3Test4Test5Test6Test7Test8Test9Test");
	dwordOut = BrbUaEncodeBrowseNameForPath(stringIn);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test0Test1Test2Test3Test4Test5Test6Test7Test8Test9Test", stringIn);

	// Gro�buchstaben
	strcpy(stringIn, "ABCDEFGHIJKLMOPQRSTUVWXYZ");
	dwordOut = BrbUaEncodeBrowseNameForPath(stringIn);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("ABCDEFGHIJKLMOPQRSTUVWXYZ", stringIn);

	// Kleinbuchstaben
	strcpy(stringIn, "abcdefghijklmnopqrstuvwxyz");
	dwordOut = BrbUaEncodeBrowseNameForPath(stringIn);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("abcdefghijklmnopqrstuvwxyz", stringIn);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-12-04 10:49:05Z
By B+R UnitTest Helper Version: 6.0.0.173
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaEncodeBrowseNameForPath_NulPtr", BrbUaEncodeBrowseNameForPath_NulPtr), 
	new_TestFixture("BrbUaEncodeBrowseNameForPath_Encode", BrbUaEncodeBrowseNameForPath_Encode), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaEncodeBrowseNameForPath, "Set_BrbUaEncodeBrowseNameForPath", 0, 0, fixtures, 0, 0, 0);

