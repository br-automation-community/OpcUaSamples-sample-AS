#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"

#ifdef __cplusplus
	};
#endif

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/* Gibt den OpcUa-Datentyp f�r ein Attribut zur�ck */
enum BrUaVariantType BrbUaGetAttributeIdDatatype(enum UAAttributeID eAttributeId)
{
	BrUaVariantType eResult = BrUaVariantType_Null;
	// NOLINTBEGIN(bugprone-branch-clone)
	switch(eAttributeId) // NOLINT(hicpp-multiway-paths-covered)
	{
		case UAAI_Default:
			eResult = BrUaVariantType_Null;
			break;
		case UAAI_NodeId:
			eResult = BrUaVariantType_NodeId;
			break;
		case UAAI_NodeClass:
			eResult = BrUaVariantType_Int32;
			break;
		case UAAI_DisplayName:
			eResult = BrUaVariantType_LocalizedText;
			break;
		case UAAI_BrowseName:
			eResult = BrUaVariantType_QualifiedName;
			break;
		case UAAI_Description:
			eResult = BrUaVariantType_LocalizedText;
			break;
		case UAAI_WriteMask:
			eResult = BrUaVariantType_UInt32;
			break;
		case UAAI_UserWriteMask:
			eResult = BrUaVariantType_UInt32;
			break;
		case UAAI_IsAbstract:
			eResult = BrUaVariantType_Boolean;
			break;
		case UAAI_Symmetric:
			eResult = BrUaVariantType_Boolean;
			break;
		case UAAI_InverseName:
			eResult = BrUaVariantType_LocalizedText;
			break;
		case UAAI_ContainsNoLoops:
			eResult = BrUaVariantType_Boolean;
			break;
		case UAAI_EventNotifier:
			eResult = BrUaVariantType_Byte;
			break;
		case UAAI_Value:
			eResult = BrUaVariantType_Null;
			break;
		case UAAI_DataType:
			eResult = BrUaVariantType_NodeId;
			break;
		case UAAI_ValueRank:
			eResult = BrUaVariantType_Int32;
			break;
		case UAAI_ArrayDimensions:
			eResult = BrUaVariantType_Null;
			break;
		case UAAI_AccessLevel:
			eResult = BrUaVariantType_Byte;
			break;
		case UAAI_UserAccessLevel:
			eResult = BrUaVariantType_Byte;
			break;
		case UAAI_MinimumSamplingInterval:
			eResult = BrUaVariantType_Double;
			break;
		case UAAI_Historizing:
			eResult = BrUaVariantType_Boolean;
			break;
		case UAAI_Executable:
			eResult = BrUaVariantType_Boolean;
			break;
		case UAAI_UserExecutable:
			eResult = BrUaVariantType_Boolean;
			break;
		case UAAI_DataTypeDefinition:
			eResult = BrUaVariantType_Null;
			break;
		case UAAI_RolePermission:
			eResult = BrUaVariantType_Null;
			break;
		case UAAI_UserRolePermissions:
			eResult = BrUaVariantType_Null;
			break;
		case UAAI_AccessRestriction:
			eResult = BrUaVariantType_UInt16;
			break;
		case UAAI_AccessLevelEx:
			eResult = BrUaVariantType_UInt32;
			break;
	}
	// NOLINTEND(bugprone-branch-clone)
	return eResult;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)
