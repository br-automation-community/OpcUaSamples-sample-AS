
Ab AS6.00 wurde das Konzept der Rechte-Vergabe ge�ndert. Es wird jetzt die OpcUa-Spezifikation 'OPC 10000-18'
(Part 18: Role-Based Security) unterst�tzt. Dieses Konzept hat einige Vorteile, funkioniert aber ganz anders als die
bisherige Rechte-Vergabe im AS4.12. Somit ergeben sich wichtige �nderungen.

Genereller Hinweis: Werden versuchsweise �nderungen an den hier genannten Komponenten auf die SPS �bertragen, empfiehlt
sich ein Neustart der SPS, damit alles �bernommen wird. Manchmal ist auch ein Rebuild + Neustart n�tig.

Die Zugriffs-Berechtigung auf einen Knoten wird jetzt durch die Kombination mehreren Komponenten (z.B Zugriffs-
Beschr�nkungen, Knoten-Eigenschaften, Permissions (Berechtigungen) der dem eingeloggten Benutzer zugewiesenen Rollen
usw.) ermittelt.
Auf den ersten Blick mag dieses Konzept komplex erscheinen, aber es ist sehr m�chtig. Bei richtiger Handhabung kann
in manchen F�llen viel Konfigurations-Aufwand gespart werden.
Hinweis: Um alle in diesem Text beschriebenen Knoten und Attribute betrachten zu k�nnen, sollte man sich mit einem
Test-Client unter dem Benutzer 'Admin' (Passwort: 'admin') anmelden.
Folgende Komponenten haben Auswirkung auf die endg�ltigen Berechtigungen eines Benutzers:

AccessRestrictions
	Das Attribut 'AccessRestrictions' ('Zugriffsbeschr�nkungen') eines Knotens ist bitcodiert und gibt an, welche
	Bedingungen erf�llt sein m�ssen, damit ein Client (unabh�ngig des eingeloggten Benutzers und dessen Rollen) Zugriff
	darauf erh�lt:
		Beschr�nkung								Bit-Nummer					Bit-Wert			Beschreibung
		----------------------------------------------------------------------------------------
		SigningRequired							0										1							Verbindung muss signiert sein
		EncryptionRequired					1										2							Verbindung muss verschl�sselt sein
		SessionRequired							2										4							Verbindung darf nicht im Mode 'SessionlessInvoke'
																																	bestehen
		ApplyRestrictionsToBrowse		3										8							Bit#0 + #1 gelten auch f�r Browse-Operationen
	
		Dieses Attribut pro Knoten kann nicht parametriert werden, sondern ist statisch hinterlegt. Die Knoten des B&R-
		Modells haben nur die Beschr�nkung 'SessionRequired', w�hrend System-Knoten, welche die Sicherheit betreffen (z.B.
		Hinzuf�gen/L�schen von Rollen) die Beschr�nkungen 'SessionRequired' + 'SigningRequired' + 'EncryptionRequired'
		haben. Hat ein Knoten keine Beschr�nkung, ist das Attribut nicht vorhanden oder hat den Wert 0.
		Wird versucht, ohne Einhaltung der Beschr�nkungen auf einen Knoten zuzugreifen, wird ein entsprechender Status
		(z.B. '80E60000=BadSecurityModeInsufficient') zur�ckgegeben.

Eigenschaft AccessLevel
	Die beiden Eigenschaften 'CurrentRead' und 'CurrentWrite' k�nnen pro Knoten im *.uad-Editor eingestellt werden.
	Diese Einstellungen m�ssen f�r jeden Knoten separat gesetzt werden und sind nicht vererbbar.
	Sie legen den grunds�tzlichen Zugriff unabh�ngig von Rollen-Berechtigungen (RolePermissions) fest. Ist z.B. die
	Eigenschaft	'CurrentWrite' nicht aktiviert, so kann kein Benutzer darauf schreiben, auch wenn eine seiner Rollen die
	Permission 'Write' (siehe unten) hat. So kann also das Lesen/Schreiben auf einen Knoten grunds�tzlich verhindert
	werden.	Bei neu angelegten Variablen sind beide Eigenschaften aktiviert, bei der Projekt-Portierung aus AS4.12 werden
	sie lt. den Einstellungen korrekt besetzt.

WellKnown-Roles
	Die OpcUa-Spezifikation sieht sogenannte 'Well Known Roles' vor, spezifiziert also bekannte Rollen mit fixen Rechten.
	B&R setzt dabei nur einige der vorgeschlagenen als System-Rollen um:
	
	OpcUa-Rolle								B&R-System-Rolle				Berechtigungen
	----------------------------------------------------------------------------------------
	Anonymous									BR_Anonymous						Wird bei anonymer Anmeldung verwendet. Hat nur Browse- und
																										Lese-Rechte auf bestimmte Knoten des OpcUa-Basis-Modells, aber nicht
																										auf das B&R-Modell und nicht auf Fremd-Modelle.
	AuthenticatedUser					-
	Observer									BR_Observer							Hat nur Browse- und Lese-Rechte auf das Basis-, B&R- sowie
																										Fremd-Modell(e).
	Operator									-
	Engineer									BR_Engineer							Hat Browse-, Lese- und Schreib-Rechte auf das Basis-, B&R- sowie
																										Fremd-Modell(e).
	ConfigureAdmin						-
	SecurityAdmin							BR_SecurityAdmin				Hat Browse-, Lese- und Schreib-Rechte auf Sicherheits-Einstellungen
																										des gesamten Modells, z.B. auf RolePermisssions (siehe unten).
	SecurityKeyServerAccess		-
	
	Die System-Rollen sind automatisch vorhanden und k�nnen einem Benutzer im Editor der Datei
	ConfigurationView/AccessAndSecurity/UserRoleSystem/*.user	zugewiesen werden, ohne dass sie angelegt werden m�ssen.
	Die Berechtigungen von Well-Known-Roles sind fest hinterlegt und k�nnen nicht ver�ndert werden!
	Der Vorteil der Well-Known-Roles besteht darin, dass f�r einige Anwendungsf�lle keine eigene Rolle angelegt und mit
	Berechtigungen versehen werden m�ssen. Dies kann jetzt u.U. ganz einfach mit einer der Well-Known-Roles umgesetzt
	werden und vermeidet damit gr��eren Aufwand.
	Zur Veranschaulichung sind in diesem Beispiel folgende Benutzer mit folgenden System-Rollen angelegt:
		Benutzer					Passwort							Rollen
		-----------------------------------------------------------------
		Observer					observer							BR_Observer
		Engineer					engineer							BR_Engineer
		SecurityAdmin			securityadmin					BR_SecurityAdmin
	Um sich mit den Berechtigungen einer Well-Known-Role vertraut zu machen, muss man sich lediglich �ber einen Test-Client
	als jeweiliger Benutzer anmelden und den Adressraum browsen.
	
Benutzerdefinierte Rollen/Benutzer
	Es ist nach wie vor m�glich, eigene Rollen und Benutzer anzulegen. Dies geschieht wie bisher im Editor der Datei
	ConfigurationView/AccessAndSecurity/UserRoleSystem/*.roles
		bzw.
	ConfigurationView/AccessAndSecurity/UserRoleSystem/*.user.
	In diesem Beispiel wurden die zwei Rollen 'Operators' und 'Administrators' definiert (Berechtigungen siehe unten).

	Au�erdem wurden zwei Benutzer mit jeweils folgenden Rollen definiert:
		Benutzer					Passwort							Benutzerdefinierte Rollen			System-Rollen
		----------------------------------------------------------------------------------------------------------
		Operator					operator							Operators
		Admin							admin									Administrators								BR_SecurityAdmin, BR_Engineer

Rollen zur Laufzeit auslesen/�ndern
	Welche Rollen am Laufzeit-System angelegt sind, kann �ber folgenden Datenpunkt ausgelesen/ge�ndert werden:
	/0:Root/0:Objects/0:Server/0:ServerCapabilities/0:RoleSet
	Er enth�lt Methoden zum Hinzuf�gen/L�schen von Rollen sowie einen Unterknoten f�r jede angelegte Rolle.
	Hinweis: Auch die von B&R nicht unterst�tzten Well-Known-Roles sind hier zu sehen, haben aber keine Rechte.
	Ist man als Benutzer mit der Rolle 'BR_SecurityAdmin' angemeldet, kann man zus�tzlich �ber die Unterknoten einer Rolle
	verschiedene Infos auslesen (z.B. welche Benutzer diese Rolle besitzen) bzw. zur Laufzeit auch einem Benutzer
	diese Rolle zuweisen/entfernen.
	Die Knoten der System-Rollen haben eine von der Foundation vorgebene Adresse (NodeId), selbst angelegte Rollen bekommen
	eine durch den Compiler:
		B&R-System-Rolle					NodeId
		----------------------------------------------------------------------------------------
		BR_Anonymous							i=15644
		BR_Observer								i=15668
		BR_Engineer								i=16036
		BR_SecurityAdmin					i=15704
		Operators									ns=1;s=UserRoles.Roles.Operators
		Administrators						ns=1;s=UserRoles.Roles.Administrators
	Diese NodeId's werden bei den RolePermissions als Referenz auf eine Rolle verwendet (siehe unten).
		
RolePermissions
	Jeder Knoten besitzt das Attribut 'RolePermissions', welches allerdings nicht von jedem Benutzer gelesen/geschrieben
	werden darf (siehe unten).
	Der Wert dieses Attributes ist ein Array, wobei jeder Eintrag eine Rolle und die dazugeh�rigen Berechtigungen als
	Bitcodierung enth�lt. Die Rolle wird dabei als NodeId angegeben (siehe oben). Die Berechtigungen sind lt. Spezifikation
	wie folgt codiert:
		Berechtigungen					Bit-Nummer					Bit-Wert
		----------------------------------------------------------------------------------------
		Browse									0										1
		ReadRolePermissions			1										2
		WriteAttribute					2										4
		WriteRolePermissions		3										8
		WriteHistorizing*				4										16
		Read										5										32
		Write										6										64
		ReadHistory							7										128
		InsertHistory*					8										256
		ModifyHistory*					9										512
		DeleteHistory*					10									1024
		ReceiveEvents						11									2048
		Call										12									4096
		AddReference*						13									8192
		RemoveReference*				14									16384
		DeleteNode*							15									32768
		AddNode*								16									65536
		
		*=Die Berechtigung ist zwar spezifiziert, wird aber bei B&R nicht unterst�tzt.
	
	Durch die Bitcodierung k�nnen die Berechtigungen frei kombiniert werden. 
	Dieses Attribut gibt also an, welche Rolle welche Berechtigungen an dem Knoten hat.
	Achtung:
		Gelesen werden kann dieses Attribut nur von einem Benutzer, dessen Rolle die Berechtigung 'ReadRolePermissions'
		an diesem Knoten hat.
		Geschrieben werden kann dieses Attribut nur von einem Benutzer, dessen Rolle die Berechtigung 'WriteRolePermissions'
		an diesem Knoten hat.
		Die System-Rolle 'BR_SecurityAdmin' hat immer beide Berechtigungen.
	Zur Veranschaulichung kann man sich am Server dieses Beispiels als Benutzer 'SecurityAdmin' oder 'Admin' anmelden,
	welche beide die Rolle 'SecurityAdmin' haben.
	
UserRolePermissions
	Im Gegensatz zu 'RolePermissions', welche die Berechtigungen f�r alle Rollen enth�lt, aber nicht von jedem Benutzer
	gelesen werden darf, kann das Attribut 'UserRolePermissions' eines Knotens von jedem Benutzer gelesen werden, dem
	der Knoten angezeigt wird. Es gibt ebenfalls durch ein Array von Rollen und Berechtigungen an, welche
	Berechtigungen die Rollen haben, die dem aktuellen eingeloggten Benutzer zugewiesen sind. So kann jeder Benutzer
	seine aktuellen	Berechtigungen an jedem sichtbaren Knoten auslesen.
	Hinweis: Die Berechtigungen der einzelnen Rollen werden f�r einen Benutzer mit mehreren Rollen verodert.

Vererbung der RolePermissions
	Theoretisch kann jeder Knoten andere RolePermissions pro Rolle haben. Um den Konfigurations-Aufwand �berschaubar zu
	halten, werden die Berechtigungen pro Rolle veerbt.
	Folgende Ebenen der Vererbung gibt es:
	
	1. DefaultRolePermissions im Namespace
		Jeder Namespace kann Default-Berechtigungen pro Rolle definieren, welche unter  
		/Root/Objects/Server/Namespaces/XXX/DefaultRolePermissions
		ausgelesen werden k�nnen, wobei XXX der Namespace ist. Ist dieser Knoten nicht vorhanden, hat dieser Namespace keine
		vorbesetzten Berechtigungen. F�r die Knoten des SPS-Programms ist es der Namespace
		'http://br-automation.com/OpcUa/PLC/PV/'.
		
		F�r WellKnownRoles sind die Berechtigungen fest hinterlegt:
			WellKnownRole							Berechtigung
			----------------------------------------------------------------------------------------
			BR_Anonymous							Browse
			BR_Observer								Browse, Read, ReadHistory, ReceiveEvents
			BR_Engineer								Browse, WriteAttribute, Read, Write, ReadHistory, ReceiveEvents, Call
			BR_SecurityAdmin					Browse, ReadRolePermissions, WriteRolePermissions
			
		F�r selbst angelegte Rollen k�nnen die Default-Berechtigungen im Editor der Datei
		ConfigurationView/Connectivity/OpcUaCs/*.uadcfg
		einzeln kombiniert werden.
		Jeder Knoten des SPS-Programms unter '/Root/Objects/PLC/Modules/::/' hat also von Haus aus die hier als
		DefaultRolePermissions angegebenen Berechtigungen.
		
	2. Abweichende RolePermissions pro Knoten
		Ein Knoten kann aber auch von den Default-Permissions abweichende, selbst definierte Berechtigungen haben. Dazu kann
		im Editor der *.uad-Datei die Einstellung 'Authorization/Inherit From Parent' auf 'Inherit None' gestellt und dann
		die Berechtigungen jeder benutzerdefinierten Rolle entsprechend ver�ndert werden.
		Zur Veranschaulichung wurde in diesem Beispiel der Rolle 'Operators' am Knoten
		/Root/Objects/PLC/Modules/::/ServerData/VarsLocal/ReadWrite/nSint die 'Write'-Berechtigung entzogen.
		Am Knoten /Root/Objects/PLC/Modules/::/ServerData/nOperatorNonBrowsable wurden dieser Rolle alle Berechtigungen
		(einschliesslich der 'Browse'-Berechtigung) entzogen.
		Ausserdem wurden dieser Rolle auch die 'Call'-Berechtigung f�r alle Methoden der Tasks 'UaCertsC' und 'UaCertsST'
		genommen, da diese sicherheitsrelevant sind und daher nur von der Rolle 'Administrators' aufgerufen k�nnen werden
		sollen.

Zugriffs-Attribute
	Die Attribute 'AccessLevel' und 'UserAccessLevel' bzw. 'Executable' und 'UserExecutable' eines Variablen- bzw.
	Methoden-Knotens werden zur Laufzeit aus den vorhergehenden Komponenten ermittelt. So kann der aktuelle Benutzer sehr
	einfach	seine momentan geltenden Zugriffs-Rechte auslesen.
		
Fremdmodelle
	Die Eigenschaften 'AccessRestrictions', 'CurrentRead' und 'CurrentWrite' werden am Fremdmodell-Knoten vom gemappten
	B&R-Knoten �bernommen.
	Leider gibt es noch ein Problem in Bezug auf Fremdmodelle: Die Default-Berechtigungen von selbstdefinierten Rollen
	werden nicht in die Namespaces der Fremdmodell(e) �bernommen (die Default-Berechtigungen von System-Rollen sind fest
	hinterlegt und gelten deshalb auch f�r Fremdmodelle). Daraus ergibt sich, dass ein Benutzer, welcher nur selbstdefinierte
	Rollen besitzt, keine Berechtigungen an einem Fremdmodell hat (er kann sie also nicht mal sehen).
	
	Als Workaround kann folgendes unternommen werden:
	Um einem Benutzer Browse- und Lese-Rechte einzur�umen, kann ihm die System-Rolle 'Observer' zugewiesen werden.
	Um einem Benutzer Browse-, Lese- und Schreib-Rechte einzur�umen, kann ihm die System-Rolle 'Engineer' zugewiesen werden.
	Das bedeutet aber, dass dieser Benutzer auch am Basis- und B&R-Modell dieses Berechtigungen hat.
	Dieses Problem wird in einer der n�chsten Versionen behoben werden.

	In diesem Beispiel hat der Benutzer 'Admin' deshalb die Rolle 'BR_Engineer', um das Fremdmodell 'AirConditions' browsen,
	lesen und schreiben zu k�nnen.
	Der Benutzer 'Operator' hat keine System-Rolle, weshalb er das Fremdmodell nicht sieht.
		
	
	
	
	
	