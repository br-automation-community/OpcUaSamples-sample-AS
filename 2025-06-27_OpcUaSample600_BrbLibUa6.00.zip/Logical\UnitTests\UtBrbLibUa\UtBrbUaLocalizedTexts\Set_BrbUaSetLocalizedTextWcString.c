#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_TEST BrbUaSetLocalizedTextWcString_NulPtr(void)
{
	dwordOut = BrbUaSetLocalizedTextWcString(0, "de", u"Hello");
	TEST_ASSERT_EQUAL_INT(0x80460000, dwordOut); // = Bad_StructureMissing

	dwordOut = BrbUaSetLocalizedTextWcString(&localizedTextIn, 0, u"Hello");
	TEST_ASSERT_EQUAL_INT(0x80460000, dwordOut); // = Bad_StructureMissing

	dwordOut = BrbUaSetLocalizedTextWcString(&localizedTextIn, "de", 0);
	TEST_ASSERT_EQUAL_INT(0x80460000, dwordOut); // = Bad_StructureMissing

	// Finished
	TEST_DONE;
}

_TEST BrbUaSetLocalizedTextWcString_SetMax(void)
{
	// Locale: 5 Zeichen
	memset((USINT*)&localizedTextIn, 0, sizeof(localizedTextIn));
	dwordOut = BrbUaSetLocalizedTextWcString(&localizedTextIn, "12345", u"Hello");
	TEST_ASSERT_EQUAL_INT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("12345", localizedTextIn.Locale);
	TEST_ASSERT_EQUAL_WSTRING(u"Hello", localizedTextIn.Text);

	// Locale: 6 Zeichen
	memset((USINT*)&localizedTextIn, 0, sizeof(localizedTextIn));
	dwordOut = BrbUaSetLocalizedTextWcString(&localizedTextIn, "123456", u"Hello");
	TEST_ASSERT_EQUAL_INT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("123456", localizedTextIn.Locale);
	TEST_ASSERT_EQUAL_WSTRING(u"Hello", localizedTextIn.Text);

	// Locale: 7 Zeichen
	memset((USINT*)&localizedTextIn, 0, sizeof(localizedTextIn));
	dwordOut = BrbUaSetLocalizedTextWcString(&localizedTextIn, "1234567", u"Hello");
	TEST_ASSERT_EQUAL_INT(0x803C0000, dwordOut); // = Bad_OutOfRange
	TEST_ASSERT_EQUAL_STRING("", localizedTextIn.Locale);
	TEST_ASSERT_EQUAL_WSTRING(u"", localizedTextIn.Text);

		// Text: 254 Zeichen
	memset((USINT*)&localizedTextIn, 0, sizeof(localizedTextIn));
	dwordOut = BrbUaSetLocalizedTextWcString(&localizedTextIn, "de", u"12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234");
	TEST_ASSERT_EQUAL_INT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("de", localizedTextIn.Locale);
	TEST_ASSERT_EQUAL_WSTRING(u"12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234", localizedTextIn.Text);

		// Text: 255 Zeichen
	memset((USINT*)&localizedTextIn, 0, sizeof(localizedTextIn));
	dwordOut = BrbUaSetLocalizedTextWcString(&localizedTextIn, "de", u"123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345");
	TEST_ASSERT_EQUAL_INT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("de", localizedTextIn.Locale);
	TEST_ASSERT_EQUAL_WSTRING(u"123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345", localizedTextIn.Text);

		// Text: 256 Zeichen
	memset((USINT*)&localizedTextIn, 0, sizeof(localizedTextIn));
	dwordOut = BrbUaSetLocalizedTextWcString(&localizedTextIn, "de", u"1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456");
	TEST_ASSERT_EQUAL_INT(0x803C0000, dwordOut); // = Bad_OutOfRange
	TEST_ASSERT_EQUAL_STRING("", localizedTextIn.Locale);
	TEST_ASSERT_EQUAL_WSTRING(u"", localizedTextIn.Text);

		// Finished
		TEST_DONE;
}

_TEST BrbUaSetLocalizedTextWcString_Set(void)
{
	dwordOut = BrbUaSetLocalizedTextWcString(&localizedTextIn, "de", u"Hello");
	TEST_ASSERT_EQUAL_INT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("de", localizedTextIn.Locale);
	TEST_ASSERT_EQUAL_WSTRING(u"Hello", localizedTextIn.Text);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-03-25 10:24:59Z
By B+R UnitTest Helper Version: 6.0.0.146
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaSetLocalizedTextWcString_NulPtr", BrbUaSetLocalizedTextWcString_NulPtr), 
	new_TestFixture("BrbUaSetLocalizedTextWcString_SetMax", BrbUaSetLocalizedTextWcString_SetMax), 
	new_TestFixture("BrbUaSetLocalizedTextWcString_Set", BrbUaSetLocalizedTextWcString_Set), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaSetLocalizedTextWcString, "Set_BrbUaSetLocalizedTextWcString", 0, 0, fixtures, 0, 0, 0);

