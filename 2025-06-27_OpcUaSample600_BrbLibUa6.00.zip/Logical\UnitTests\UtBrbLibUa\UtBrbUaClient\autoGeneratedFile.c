/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (List of TestSets).
LastUpdated: 2024-11-25 07:46:00Z
By B+R UnitTest Helper Version: 6.0.0.173
*/
#include "UnitTest.h"



UNITTEST_TESTSET_DECLARATION  Set_BrbUaGetConnectionStatusText;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaCltInit;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaCltBrowse;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaCltExit;



UNITTEST_TESTSET_FIXTURES(utTestSets)
{
	new_TestSet(Set_BrbUaGetConnectionStatusText),
	new_TestSet(Set_BrbUaCltInit),
	new_TestSet(Set_BrbUaCltBrowse),
	new_TestSet(Set_BrbUaCltExit),
};
UNTITTEST_TESTSET_HANDLER();

