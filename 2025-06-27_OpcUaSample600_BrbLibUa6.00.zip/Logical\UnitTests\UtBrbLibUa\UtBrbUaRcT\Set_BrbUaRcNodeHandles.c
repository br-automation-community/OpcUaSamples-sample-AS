#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_CYCLIC_SET(void)
{
	if(RunClient.State.eState >= eBRB_RCSTATE_INIT_DONE && RunClient.State.eState < eBRB_RCSTATE_EXITING)
	{
		if(bRunCyclic == 1)
		{
			fbBrbUaRunClientCyclic.pRunClient = &RunClient;
			BrbUaRunClientCyclic(&fbBrbUaRunClientCyclic);
		}
	}
	BrbUaRcMonitor(&RunClient, &CyclicMonitor);
	return;
}

_TEST BrbUaRcNodeHandles_GetNodeHandle_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcNamespacesInit.BrbUaRcNodeHandles_GetNodeHandle_NulPtr", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRcGetNodeHandle(0, 0, &NodeHandle);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_NULL_POINTER, uintOut);
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcNodeHandles_GetNodeHandle_InvalidNodeHandleIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcNamespacesInit.BrbUaRcNodeHandles_GetNodeHandle_InvalidNodeHandleIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&NodeHandle, 0, sizeof(NodeHandle));
	uintOut = BrbUaRcGetNodeHandle(&RunClient, 99, &NodeHandle);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, uintOut);
	TEST_ASSERT_EQUAL_INT(0, NodeHandle.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, NodeHandle.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("", NodeHandle.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, NodeHandle.nNodeHandle);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, NodeHandle.nErrorId); // Good

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.NodeHandle.nNodeHandleIndex = 99;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_UA_INVALID_INDEX, RcMonitor.NodeHandle.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.NodeHandle.NodeHandle.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.NodeHandle.NodeHandle.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("", RcMonitor.NodeHandle.NodeHandle.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.NodeHandle.NodeHandle.nNodeHandle);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.NodeHandle.NodeHandle.nErrorId); // Good

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcNodeHandles_GetNodeHandle_InvalidNamespaceIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcNamespacesInit.BrbUaRcNodeHandles_GetNodeHandle_InvalidNamespaceIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&NodeHandle, 0, sizeof(NodeHandle));
	uintOut = BrbUaRcGetNodeHandle(&RunClient, 4, &NodeHandle);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, NodeHandle.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, NodeHandle.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Read.anUint[4]", NodeHandle.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, NodeHandle.nNodeHandle);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, NodeHandle.nErrorId); // Bad_NodeIdUnknown

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.NodeHandle.nNodeHandleIndex = 4;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.NodeHandle.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.NodeHandle.NodeHandle.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, RcMonitor.NodeHandle.NodeHandle.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Read.anUint[4]", RcMonitor.NodeHandle.NodeHandle.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.NodeHandle.NodeHandle.nNodeHandle);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, RcMonitor.NodeHandle.NodeHandle.nErrorId); // Bad_NodeIdUnknown

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcNodeHandles_GetNodeHandle_InvalidVarName(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcNamespacesInit.BrbUaRcNodeHandles_GetNodeHandle_InvalidVarName", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&NodeHandle, 0, sizeof(NodeHandle));
	uintOut = BrbUaRcGetNodeHandle(&RunClient, 5, &NodeHandle);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(6, NodeHandle.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, NodeHandle.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Read.UnknownNode", NodeHandle.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, NodeHandle.nNodeHandle);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, NodeHandle.nErrorId); // Bad_NodeIdUnknown

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.NodeHandle.nNodeHandleIndex = 5;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.NodeHandle.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(6, RcMonitor.NodeHandle.NodeHandle.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, RcMonitor.NodeHandle.NodeHandle.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Read.UnknownNode", RcMonitor.NodeHandle.NodeHandle.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.NodeHandle.NodeHandle.nNodeHandle);
	BRB_ASSERT_EQUAL_UDINT(0x80340000, RcMonitor.NodeHandle.NodeHandle.nErrorId); // Bad_NodeIdUnknown

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcNodeHandles_GetNodeHandle_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcNamespacesInit.BrbUaRcNodeHandles_GetNodeHandle_Ok", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&NodeHandle, 0, sizeof(NodeHandle));
	uintOut = BrbUaRcGetNodeHandle(&RunClient, 1, &NodeHandle);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(6, NodeHandle.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, NodeHandle.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Read.anUint[1]", NodeHandle.NodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x0000000, NodeHandle.nErrorId); // Good

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.NodeHandle.nNodeHandleIndex = 1;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.NodeHandle.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(6, RcMonitor.NodeHandle.NodeHandle.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, RcMonitor.NodeHandle.NodeHandle.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Read.anUint[1]", RcMonitor.NodeHandle.NodeHandle.NodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x0000000, RcMonitor.NodeHandle.NodeHandle.nErrorId); // Good
	
	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-04-04 12:14:02Z
By B+R UnitTest Helper Version: 6.0.0.146
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaRcNodeHandles_GetNodeHandle_NulPtr", BrbUaRcNodeHandles_GetNodeHandle_NulPtr), 
	new_TestFixture("BrbUaRcNodeHandles_GetNodeHandle_InvalidNodeHandleIndex", BrbUaRcNodeHandles_GetNodeHandle_InvalidNodeHandleIndex), 
	new_TestFixture("BrbUaRcNodeHandles_GetNodeHandle_InvalidNamespaceIndex", BrbUaRcNodeHandles_GetNodeHandle_InvalidNamespaceIndex), 
	new_TestFixture("BrbUaRcNodeHandles_GetNodeHandle_InvalidVarName", BrbUaRcNodeHandles_GetNodeHandle_InvalidVarName), 
	new_TestFixture("BrbUaRcNodeHandles_GetNodeHandle_Ok", BrbUaRcNodeHandles_GetNodeHandle_Ok), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaRcNodeHandles, "Set_BrbUaRcNodeHandles", 0, 0, fixtures, 0, 0, cyclicSetCaller);

