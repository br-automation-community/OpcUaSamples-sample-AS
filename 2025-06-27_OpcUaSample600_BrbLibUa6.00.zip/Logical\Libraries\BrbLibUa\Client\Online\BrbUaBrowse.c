
#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>
#include <stdlib.h>

#ifdef __cplusplus
	};
#endif

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

// Eigene Enums und Typen
enum Steps_ENUM
{
	eSTEP_INIT,
	eSTEP_BROWSE
};

/* Durchsucht die Referenzen eines Knotens */
void BrbUaBrowse(struct BrbUaBrowse* inst)
{
	inst->nStatus = eBRB_ERR_NULL_POINTER;
	if(inst->pBrowseResults != 0)
	{
		inst->nStatus = eBRB_ERR_INVALID_PARAMETER;
		if(inst->nConnectionHandle != 0)
		{
			switch(inst->eStep)
			{
				case eSTEP_INIT:
					// Fub initialisieren
					inst->nStatus = eBRB_ERR_BUSY;
					inst->nErrorId = 0x00000000; // = Good
					if(inst->tTimeout == 0)
					{
						inst->tTimeout = 3000;
					}
					inst->nBrowseResultsCount = 0;
					inst->nRemainingBrowseResults = 0;
					memset(&inst->fbUA_Browse, 0, sizeof(inst->fbUA_Browse));
					inst->fbUA_Browse.ConnectionHdl = inst->nConnectionHandle;
					memcpy(&inst->fbUA_Browse.ViewDescription, &inst->ViewDescription, sizeof(inst->fbUA_Browse.ViewDescription));
					memcpy(&inst->fbUA_Browse.BrowseDescription, &inst->BrowseDescription, sizeof(inst->fbUA_Browse.BrowseDescription));
					inst->nContinuationPoint = 0;
					inst->fbUA_Browse.Timeout = inst->tTimeout;
					// Ergebnisliste l�schen
					memset(inst->pBrowseResults, 0, (inst->nBrowseResultsIndexMax+1) * sizeof(UAReferenceDescription));
					inst->eStep = eSTEP_BROWSE;
					break;

				case eSTEP_BROWSE:
					// Aufruf
					inst->nStatus = eBRB_ERR_BUSY;
					inst->fbUA_Browse.Execute = 1;
					inst->fbUA_Browse.ContinuationPointIn = inst->nContinuationPoint;
					UA_Browse(&inst->fbUA_Browse);
					if(inst->fbUA_Browse.Done == 1)
					{
						// Ziel-Array-Gr��e pr�fen
						UDINT nCopyCount = inst->fbUA_Browse.BrowseResultCount;
						if(inst->nBrowseResultsCount + nCopyCount > inst->nBrowseResultsIndexMax+1)
						{
							// Es passen nicht mehr alle Ergebnisse ins Ziel-Array
							nCopyCount = inst->nBrowseResultsIndexMax+1 - inst->nBrowseResultsCount;
							inst->nRemainingBrowseResults += inst->fbUA_Browse.BrowseResultCount - nCopyCount;
						}
						// Ergebnisse kopieren
						if(nCopyCount > 0)
						{
							UAReferenceDescription* pDestination = inst->pBrowseResults + inst->nBrowseResultsCount;
							memcpy(pDestination, &inst->fbUA_Browse.BrowseResult[0], nCopyCount * sizeof(UAReferenceDescription));
							inst->nBrowseResultsCount += nCopyCount;
						}
						// Pr�fen, ob weitere Ergebnisse zur Verf�gung stehen 
						if(inst->fbUA_Browse.ContinuationPointOut == 0)
						{
							// Fertig
							inst->nStatus = eBRB_ERR_OK;
							inst->nErrorId = 0x00000000; // = Good
							inst->fbUA_Browse.Execute = 0;
							inst->fbUA_Browse.ContinuationPointIn = 0;
							UA_Browse(&inst->fbUA_Browse);
							inst->eStep = eSTEP_INIT;
						}
						else
						{
							// Weitere Ergebnisse stehen zur Verf�gung
							inst->fbUA_Browse.Execute = 0;
							UA_Browse(&inst->fbUA_Browse);
							inst->nContinuationPoint = inst->fbUA_Browse.ContinuationPointOut;
						}
					}
					else if(inst->fbUA_Browse.Error == 1)
					{
						inst->nStatus = eBRB_ERR_UA_ERROR;
						inst->nErrorId = inst->fbUA_Browse.ErrorID;
						inst->eStep = eSTEP_INIT;
					}
					break;

			}
		}
	}
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

