/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (List of TestSets).
LastUpdated: 2024-03-25 14:29:38Z
By B+R UnitTest Helper Version: 6.0.0.146
*/
#include "UnitTest.h"



UNITTEST_TESTSET_DECLARATION  Set_BrbUaSrvGetMethodOperateText;



UNITTEST_TESTSET_FIXTURES(utTestSets)
{
	new_TestSet(Set_BrbUaSrvGetMethodOperateText),
};
UNTITTEST_TESTSET_HANDLER();

