#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_SETUP_SET(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsNamespaces._SETUP_SET", sizeof(sCurrentUnitTest));

	bRunCyclic = 0;
	memset(&RunServer, 0, sizeof(RunServer));
	memset(&fbBrbUaRunServerInit, 0, sizeof(fbBrbUaRunServerInit));
	memset(&fbBrbUaRunServerCyclic, 0, sizeof(fbBrbUaRunServerCyclic));
	memset(&fbBrbUaRunServerExit, 0, sizeof(fbBrbUaRunServerExit));

	// Finished
	TEST_DONE;
}

_TEST BrbUaRsNamespaces_Init(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsNamespaces.BrbUaRsNamespaces_Init", sizeof(sCurrentUnitTest));

	brsstrcpy((UDINT)&RunServer.Cfg.sCfgDataObjName, (UDINT)&"UtRs");
	fbBrbUaRunServerInit.pRunServer = &RunServer;
	BrbUaRunServerInit(&fbBrbUaRunServerInit);
	TEST_BUSY_CONDITION(fbBrbUaRunServerInit.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRunServerInit.nStatus);

	// Finished
	TEST_DONE;
}


_CYCLIC_SET(void)
{
	if(RunServer.State.eState >= eBRB_RSSTATE_INIT_DONE && RunServer.State.eState < eBRB_RSSTATE_EXITING)
	{
		if(bRunCyclic == 1)
		{
			fbBrbUaRunServerCyclic.pRunServer = &RunServer;
			BrbUaRunServerCyclic(&fbBrbUaRunServerCyclic);
		}
	}
	BrbUaRsMonitor(&RunServer, &CyclicMonitor);
	return;
}

_TEST BrbUaRsNamespaces_GetNamespace_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsNamespaces.BrbUaRsNamespaces_GetNamespace_NulPtr", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRsGetNamespace(0, 0, &Namespace);
	TEST_ASSERT_EQUAL_INT(0, uintOut);
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRsNamespaces_GetNamespace_InvalidNamespaceIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsNamespaces.BrbUaRsNamespaces_GetNamespace_InvalidNamespaceIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Namespace, 0, sizeof(Namespace));
	uintOut = BrbUaRsGetNamespace(&RunServer, 99, &Namespace);
	TEST_ASSERT_EQUAL_INT(0, uintOut);
	TEST_ASSERT_EQUAL_STRING("", Namespace.sNamespaceUri);
	TEST_ASSERT_EQUAL_INT(0, Namespace.nNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Namespace.nErrorId); // Good

	// Monitor
	memset(&RsMonitor, 0, sizeof(RsMonitor));
	RsMonitor.bEnable = 1;
	RsMonitor.Namespace.nDatObjNamespaceIndex = 99;
	BrbUaRsMonitor(&RunServer, &RsMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RsMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_STRING("", RsMonitor.Namespace.Namespace.sNamespaceUri);
	TEST_ASSERT_EQUAL_INT(0, RsMonitor.Namespace.Namespace.nNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RsMonitor.Namespace.Namespace.nErrorId); // Good

	// Finished
	TEST_DONE;
}

_TEST BrbUaRsNamespaces_GetNamespace_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsNamespaces.BrbUaRsNamespaces_GetNamespace_Ok", sizeof(sCurrentUnitTest));

	// Cyclic
	bRunCyclic = 1;
	TEST_ABORT_CONDITION_MSG(fbBrbUaRunServerCyclic.nStatus != eBRB_ERR_OK, "RunServer not running!")
	TEST_BUSY_CONDITION(RunServer.State.eState != eBRB_RSSTATE_RUNNING)
	
	// Direkt
	uintOut = BrbUaRsGetNamespace(&RunServer, 3, &Namespace);
	TEST_ASSERT_EQUAL_INT(6, uintOut);
	TEST_ASSERT_EQUAL_STRING("http://br-automation.com/OpcUa/PLC/PV/", Namespace.sNamespaceUri);
	TEST_ASSERT_EQUAL_INT(6, Namespace.nNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Namespace.nErrorId); // Good

	// Monitor
	memset(&RsMonitor, 0, sizeof(RsMonitor));
	RsMonitor.bEnable = 1;
	RsMonitor.Namespace.nDatObjNamespaceIndex = 3;
	BrbUaRsMonitor(&RunServer, &RsMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RsMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_STRING("http://br-automation.com/OpcUa/PLC/PV/", RsMonitor.Namespace.Namespace.sNamespaceUri);
	TEST_ASSERT_EQUAL_INT(6, RsMonitor.Namespace.Namespace.nNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RsMonitor.Namespace.Namespace.nErrorId); // Good

	// Finished
	bRunCyclic = 0;
	TEST_DONE;
}

_TEST BrbUaRsNamespaces_InvalidNamespace(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsNamespaces.BrbUaRsNamespaces_InvalidNamespace", sizeof(sCurrentUnitTest));

	// Cyclic
	bRunCyclic = 1;
	TEST_ABORT_CONDITION_MSG(fbBrbUaRunServerCyclic.nStatus != eBRB_ERR_OK, "RunServer not running!")
	TEST_BUSY_CONDITION(RunServer.State.eState != eBRB_RSSTATE_RUNNING)
	
	// Direkt
	uintOut = BrbUaRsGetNamespace(&RunServer, 4, &Namespace);
	TEST_ASSERT_EQUAL_INT(0, uintOut);
	BRB_ASSERT_EQUAL_UDINT(0xA0000200, Namespace.nErrorId); // PlcOpen_BadNsNotFound

	// Monitor
	memset(&RsMonitor, 0, sizeof(RsMonitor));
	RsMonitor.bEnable = 1;
	RsMonitor.Namespace.nDatObjNamespaceIndex = 4;
	BrbUaRsMonitor(&RunServer, &RsMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RsMonitor.nMonitorStatus);
	BRB_ASSERT_EQUAL_UDINT(0xA0000200, RsMonitor.Namespace.Namespace.nErrorId); // PlcOpen_BadNsNotFound

	// Finished
	TEST_DONE;
}

_TEARDOWN_SET(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRsNamespaces._TEARDOWN_SET", sizeof(sCurrentUnitTest));

	bRunCyclic = 0;
	// Exit
	fbBrbUaRunServerExit.pRunServer = &RunServer;
	BrbUaRunServerExit(&fbBrbUaRunServerExit);
	TEST_BUSY_CONDITION(fbBrbUaRunServerExit.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRunServerExit.nStatus);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-03-25 14:47:18Z
By B+R UnitTest Helper Version: 6.0.0.146
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaRsNamespaces_Init", BrbUaRsNamespaces_Init), 
	new_TestFixture("BrbUaRsNamespaces_GetNamespace_NulPtr", BrbUaRsNamespaces_GetNamespace_NulPtr), 
	new_TestFixture("BrbUaRsNamespaces_GetNamespace_InvalidNamespaceIndex", BrbUaRsNamespaces_GetNamespace_InvalidNamespaceIndex), 
	new_TestFixture("BrbUaRsNamespaces_GetNamespace_Ok", BrbUaRsNamespaces_GetNamespace_Ok), 
	new_TestFixture("BrbUaRsNamespaces_InvalidNamespace", BrbUaRsNamespaces_InvalidNamespace), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaRsNamespaces, "Set_BrbUaRsNamespaces", 0, 0, fixtures, setupSet, teardownSet, cyclicSetCaller);

