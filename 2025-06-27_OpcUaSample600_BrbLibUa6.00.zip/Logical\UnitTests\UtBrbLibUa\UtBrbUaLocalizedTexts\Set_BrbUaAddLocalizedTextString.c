#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_TEST BrbUaAddLocalizedTextString_NulPtr(void)
{
	dwordOut = BrbUaAddLocalizedTextString(0, stringIn, sizeof(stringIn));
	BRB_ASSERT_EQUAL_UDINT(0x80460000, dwordOut); // = Bad_StructureMissing

	dwordOut = BrbUaAddLocalizedTextString(&localizedTextIn, 0, sizeof(stringIn));
	BRB_ASSERT_EQUAL_UDINT(0x80460000, dwordOut); // = Bad_StructureMissing

	// Finished
	TEST_DONE;
}

_TEST BrbUaAddLocalizedTextString_Add(void)
{
	strcpy(stringIn, "Test ");
	BrbUaSetLocalizedTextString(&localizedTextIn, "de", "Hello");
	dwordOut = BrbUaAddLocalizedTextString(&localizedTextIn, stringIn, sizeof(stringIn));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test de:Hello", stringIn);

	strcpy(stringIn, "Test ");
	BrbUaSetLocalizedTextString(&localizedTextIn, "", "Hello");
	dwordOut = BrbUaAddLocalizedTextString(&localizedTextIn, stringIn, sizeof(stringIn));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test Hello", stringIn);

	strcpy(stringIn, "Test ");
	BrbUaSetLocalizedTextString(&localizedTextIn, "en", "");
	dwordOut = BrbUaAddLocalizedTextString(&localizedTextIn, stringIn, sizeof(stringIn));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test en:", stringIn);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-03-25 11:33:57Z
By B+R UnitTest Helper Version: 6.0.0.146
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaAddLocalizedTextString_NulPtr", BrbUaAddLocalizedTextString_NulPtr), 
	new_TestFixture("BrbUaAddLocalizedTextString_Add", BrbUaAddLocalizedTextString_Add), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaAddLocalizedTextString, "Set_BrbUaAddLocalizedTextString", 0, 0, fixtures, 0, 0, 0);

