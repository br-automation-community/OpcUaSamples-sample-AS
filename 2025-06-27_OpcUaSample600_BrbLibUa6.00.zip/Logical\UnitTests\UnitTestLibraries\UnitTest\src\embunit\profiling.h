

#define LOG_DATA(ident, event, addData)  /*	prLog.enable = 1; prLog.objIdent = (unsigned long)ident; prLog.userEvent = event; prLog.pAddData = addData; prLog.addDataLen = stdimpl_strlen(addData); LogEvent(&prLog);*/





