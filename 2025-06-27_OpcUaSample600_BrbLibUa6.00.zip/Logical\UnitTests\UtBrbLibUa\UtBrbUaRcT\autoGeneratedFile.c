/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (List of TestSets).
LastUpdated: 2024-09-26 10:43:03Z
By B+R UnitTest Helper Version: 6.0.0.173
*/
#include "UnitTest.h"



UNITTEST_TESTSET_DECLARATION  Set_BrbUaRcGeneral;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaRcConnection;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaRcInit;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaRcNamespaces;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaRcNodeHandles;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaRcReadBlocks;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaRcWriteBlocks;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaRcMethods;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaRcSubscriptionVar;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaRcSubscriptionQueue;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaRcSubscriptionEvent;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaRcExit;



UNITTEST_TESTSET_FIXTURES(utTestSets)
{
	new_TestSet(Set_BrbUaRcGeneral),
	new_TestSet(Set_BrbUaRcConnection),
	new_TestSet(Set_BrbUaRcInit),
	new_TestSet(Set_BrbUaRcNamespaces),
	new_TestSet(Set_BrbUaRcNodeHandles),
	new_TestSet(Set_BrbUaRcReadBlocks),
	new_TestSet(Set_BrbUaRcWriteBlocks),
	new_TestSet(Set_BrbUaRcMethods),
	new_TestSet(Set_BrbUaRcSubscriptionVar),
	new_TestSet(Set_BrbUaRcSubscriptionQueue),
	new_TestSet(Set_BrbUaRcSubscriptionEvent),
	new_TestSet(Set_BrbUaRcExit),
};
UNTITTEST_TESTSET_HANDLER();

