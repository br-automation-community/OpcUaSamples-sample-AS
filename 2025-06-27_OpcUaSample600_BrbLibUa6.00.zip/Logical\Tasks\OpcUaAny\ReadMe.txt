
Der OpcUaAny-Client ist als HW-Modul an der Ethernet-Schnittstelle eingef�gt.
Er repr�sentiert einen Server als IO-Modul und wird auch als 'normales' IO-Modul parametriert. Bedient
wird er automatisch durch einen im Betriebssystem integrierten Client.

Allgemeine Konfiguration:
	Die Einstellung 'Module supervised' sollte auf 'off' stehen. Sie verh�lt sie genauso wie bei jedem anderen
	IO-Modul. Das bedeutet, wenn sie auf 'on' steht und das Modul (also der Server) nicht erreicht wird, geht
	die SPS in den ServiceMode!
	Durch die Einstellung 'Server Diagnostics' werden Diagnose-Werte zur Verf�gung gestellt, welche auf
	Variablen gemappt werden k�nnen (siehe IO-Mapping).
	Bei den Security-Einstellungen ist die SSL-Config angegeben, welche auch schon f�r den Lib-Client verwendet 
	wird (Zertifikat mit 50 Jahren Laufzeit). Auch hier gilt: Wenn kein Zertifikat angegeben wird, wird 
	automatisch eines mit einer Laufzeit von 10 Jahren angelegt.
	Ausserdem ist hier der Benutzer eingestellt, mit dem sich der Client am Server anmeldet.
	
Namespace-Konfiguration:
	In der folgenden Kanal-Konfiguration ist es notwendig, Namespace-Indizes anzugeben. Bis AS4.12 mussten
	hier die Namespace-Indizes des Servers angegeben werden. Diese k�nnen sich jedoch theoretisch bei jedem
	Hochlauf des Servers ver�ndern.
	Deshalb wird dies ab AS6.0 anders gehandelt: Es kann eine lokale Namespace-Tabelle angegeben werden, dessen
	Indizes dann in der Konfiguration zu verwenden sind. Dazu wird in die Tabelle jeder Namespace-Uri eingetragen,
	welcher zur Adressierung der zu kommunizierenden Datenpunkte ben�tigt wird. Der Einfachkeit halber sind in
	diesem Beispiel nicht nur die ben�tigten, sondern alle am Server vorhandenen Namespace-Uris eingetragen:
		0		http://opcfoundation.org/UA/
		1		urn:br-automation/BR/UA/EmbeddedServer
		2		http://opcfoundation.org/UA/DI/
		3		http://PLCopen.org/OpcUa/IEC61131-3/
		4		http://br-automation.com/OpcUa/PLC/
		5		http://br-automation.com/AirCondModel/
		6		http://br-automation.com/OpcUa/PLC/PV/
	
	Der Client setzt diese Namespaces dann zur Laufzeit in die korreken, am Server geltenden Indizes um.
	Hinweis: Zur Kanal-Adressierung werden nur die Indizes 0, 4 und 6 ben�tigt.
	
Kanal-Konfiguration:
	Es wurden f�r dieses Beispiel je 3 Eingangs- und 3 Ausgangs-Kan�le angelegt. Eing�nge dienen dem Lesen vom
	Server, Ausg�nge dienen dem Schreiben auf den Server.
	
	Eing�nge (Direction=Input) werden als MonitoredItems �ber Subscriptions am Server abonniert. Dazu kann jeweils
	das	Sampling- und das Publishing-Intervall angegeben werden. Dabei wird f�r jedes unterschiedliche Publishing-
	Intervall je nur eine Subscription angelegt.
	
	Ein Ausgang (Direction=Output) wird nur geschrieben, wenn sich der Wert ge�ndert hat. Dazu �berwacht der
	Client die �nderung des Werts in dem angegebenen Sampling-Intervall.
	
	Zur Angabe des Server-Knotens kann zwischen 3 Adressierungs-Arten gew�hlt werden:
	1. Absoluter Browse-Pfad (wie im AS4.12)
		Er besteht aus einzelnen Elementen, welche durch '/' getrennt sind und jeweils einen Knoten der Hierarchie
		darstellen. Ein Element enth�lt den Wert des Attributs 'BrowseName' des Knotens. Dieser wiederum besteht aus dem
		Namespace-Index und dann durch Doppelpunkt getrennt dem Knotennamen. Um Sonderzeichen trotzdem auch im
		eigentlichen Namen verwenden zu k�nnen, werden diese innerhalb des Pfades mit einem '&' als Prefix gekennzeichnet.
		Folgende Sonderzeichen werden gekennzeichnet:
			Zeichen			Ersetzung
			&						&&
			!						&!
			#						&#
			:						&:
			>						&>
			<						&<
			.						&.
			/						&/
		
		Ein absoluter Browse-Pfad zeichnet sich dadurch aus, dass er stets beim 'Root'-Knoten beginnt.	
		Somit ergibt bei diesem Beispiel folgender absoluter Browse-Pfad:
		/0:Root/0:Objects/4:PLC/4:Modules/6:&:&:/6:OpcUaAny/6:Data/6:Read/6:Server/6:nUsint
		|																	|				|						|
		|																	|				|						+---	Ab hier beginnt der Variablenname
		|																	|				+---------------	Hier steht der Taskname
		|																	+-----------------------	Die : des Namens werden mit Pr�fix '&' gekennzeichnet
		+---------------------------------------------------------	Dies ist der Beginn des hierarchischen Address-Baums

		
	2. Relativer Browse-Pfad
		Der relative unterscheidet sich vom absoluten dadurch, dass nicht beim Knoten 'Root' begonnen wird.
		Stattdessen wird die NodeId des Start-Knotens angegeben, von dem aus der relative Pfad weitergef�hrt wird.
		Beim Browse-Pfad selbst gelten dieselben Regeln wie oben beim absoluten Browse-Pfad.
		In diesem Beispiel wird der Start-Knoten mit 'ns=6;s=::OpcUaAny:Data' angegeben. Somit lautet der weiterf�hrende
		relative Browse-Pfad '/6:Read/6:Server/6:nUint'.
		
	3. NodeId
		Es kann eine direkte NodeId angegeben werden, z.B. 'ns=6;s=::OpcUaAny:Data.Read.Server.nUdint'.

IO-Mapping:
	Standard-Kan�le
		ModuleOk
			Verh�lt sich wie bei einem normalen IO-Modul: Wenn der Server nicht erreichbar ist oder die Verbindung
			abbricht, geht dieser Kanal auf 'False'. Sobald die Verbindung besteht, ist er 'True'.
		ConnectionLostCount, ClientErrorCount und LastClientError
			Immer vorhandene Diagnose-Datenpunkte. Wenn ein Parametrier-Fehler vorliegt (z.B. falscher Browse-Pfad), kann
			dies an 'LastClientError' gesehen werden.
		ServerViewCount, CurrentSessionCount usw.
			Nur dann vorhandene Diagnose-Datenpunkte, wenn die Einstellung 'Server Diagnostics' auf 'on' steht.
		
	Benutzerdefinierte Kan�le
		Hier k�nnen die Kan�le gemappt werden, welche in der Konfiguration parametriert wurden.
	
	Wichtig: Eine zu mappende Variable muss den zum Datenpunkt passenden Datentyp haben!
	
Variablen in diesem Beispiel
	Der Task 'OpcUaAny' ist in diesem Beispiel nur vorhanden, um Variablen bereit zu stellen, welche an die
	Datenpunkte gemappt werden k�nnen.
	
	Eing�nge:
		Die Elemente der Struktur 'Data.Read.Server' werden im Task inkrementiert und vom Client abonniert. Die
		empfangenen Werte werden auf die Struktur 'Data.Read.Client' geschrieben.

	Ausg�nge:
		Die Elemente der Struktur 'Data.Write.Client' werden im Task inkrementiert und vom Client geschrieben.
		Serverseitig addressiert sind dabei die Elemente der Struktur 'Data.Write.Server'.
	
Verbindungsabbruch
	Wie schon beim Lib-Client wird auch hier nach einem Verbindungsabbruch die gesamte Kommunikation wieder
	automatisch restauriert. Ob eine Verbindung besteht, kann �ber den Eingangs-Kanal 'ModuleOk' abgefragt werden.
