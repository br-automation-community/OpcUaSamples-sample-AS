#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

void GetItemIndicesText(STRING* pText0, UINT nItemIdx0, STRING* pText1, UINT nItemIdx1, STRING* pText2, UINT nItemIdx2, STRING* pTextTotal, UDINT nTotalTextSize)
{
	BrbStringCopy(pTextTotal, "", nTotalTextSize);
	if(pText0 != 0)
	{
		BrbStringCat(pTextTotal, pText0, nTotalTextSize);
		STRING sHelp[32];
		BrbUdintToAscii(nItemIdx0, sHelp);
		BrbStringCat(pTextTotal, sHelp, nTotalTextSize);
	}
	if(pText1 != 0)
	{
		BrbStringCat(pTextTotal, pText1, nTotalTextSize);
		STRING sHelp[32];
		BrbUdintToAscii(nItemIdx1, sHelp);
		BrbStringCat(pTextTotal, sHelp, nTotalTextSize);
	}
	if(pText2 != 0)
	{
		BrbStringCat(pTextTotal, pText2, nTotalTextSize);
		STRING sHelp[32];
		BrbUdintToAscii(nItemIdx2, sHelp);
		BrbStringCat(pTextTotal, sHelp, nTotalTextSize);
	}
}

void AssertErrorId(DWORD nErrorIdExpected, DWORD nErrorIdActual, STRING* pText0, UINT nItemIdx0, STRING* pText1, UINT nItemIdx1, STRING* pText2, UINT nItemIdx2)
{
	STRING sTextTotal[255];
	BrbStringCopy(sTextTotal, " expected ErroId ", sizeof(sTextTotal));
	STRING sStatusText[255];
	BrbUaGetStatusCodeText(nErrorIdExpected, sStatusText, sizeof(sStatusText));
	BrbStringCat(sTextTotal, sStatusText, sizeof(sTextTotal));
	BrbStringCat(sTextTotal, " was ", sizeof(sTextTotal));
	BrbUaGetStatusCodeText(nErrorIdActual, sStatusText, sizeof(sStatusText));
	BrbStringCat(sTextTotal, sStatusText, sizeof(sTextTotal));
	if(pText0 != 0)
	{
		BrbStringCat(sTextTotal, ", ", sizeof(sTextTotal));
		STRING sTextIndices[255];
		GetItemIndicesText(pText0, nItemIdx0, pText1, nItemIdx1, pText2, nItemIdx2, sTextIndices, sizeof(sTextIndices));
		BrbStringCat(sTextTotal, sTextIndices, sizeof(sTextTotal));
	}
	TEST_ASSERT_MESSAGE(nErrorIdExpected == nErrorIdActual, sTextTotal);
}

_SETUP_SET(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull._SETUP_SET", sizeof(sCurrentUnitTest));

	bRunCyclic = 0;
	memset(&RunClient, 0, sizeof(RunClient));
	memset(&fbBrbUaRunClientInit, 0, sizeof(fbBrbUaRunClientInit));
	memset(&fbBrbUaRunClientCyclic, 0, sizeof(fbBrbUaRunClientCyclic));
	memset(&fbBrbUaRunClientExit, 0, sizeof(fbBrbUaRunClientExit));
	memset(&Data, 0, sizeof(Data));
	CyclicMonitor.bEnable =  1;

	memset(&Data.Read, 0, sizeof(Data.Read));

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_Init(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Init", sizeof(sCurrentUnitTest));

	brsstrcpy((UDINT)&RunClient.Cfg.sCfgDataObjName, (UDINT)&"UtRcFull");
	fbBrbUaRunClientInit.pRunClient = &RunClient;
	BrbUaRunClientInit(&fbBrbUaRunClientInit);
	TEST_BUSY_CONDITION(fbBrbUaRunClientInit.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRunClientInit.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RunClient.State.nErrorId); // Good
	TEST_ASSERT_EQUAL_STRING("", RunClient.State.sErrorText);
	
	// Finished
	TEST_DONE;
}

_CYCLIC_SET(void)
{
	if(RunClient.State.eState >= eBRB_RCSTATE_INIT_DONE && RunClient.State.eState < eBRB_RCSTATE_EXITING)
	{
		if(bRunCyclic == 1)
		{
			fbBrbUaRunClientCyclic.pRunClient = &RunClient;
			BrbUaRunClientCyclic(&fbBrbUaRunClientCyclic);
		}
		// Operate Queue
		fbUA_MonItemOperateList_Ok.Execute = bOperateSubscriptionQueue;
		if(fbUA_MonItemOperateList_Ok.Busy)
		{
			fbUA_MonItemOperateList_Ok.Execute = 1;
		}
		else if(fbUA_MonItemOperateList_Ok.Done || fbUA_MonItemOperateList_Ok.Error)
		{
			fbUA_MonItemOperateList_Ok.Execute = 0;
		}
		UA_MonitoredItemOperateList(&fbUA_MonItemOperateList_Ok);
	}
	BrbUaRcMonitor(&RunClient, &CyclicMonitor);
	return;
}

_TEST BrbUaRcFull_Connect(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Connect", sizeof(sCurrentUnitTest));

	bRunCyclic = 1;
	BrbStringCopy(RunClient.Cfg.sServerEndpointUrl, "opc.tcp://127.0.0.1:4840", sizeof(RunClient.Cfg.sServerEndpointUrl));
	RunClient.eCmd = eBRB_RCCLTCMD_CONNECT;
	TEST_ABORT_CONDITION_MSG(fbBrbUaRunClientCyclic.nStatus != eBRB_ERR_OK, "RunClient not connecting!")
	TEST_BUSY_CONDITION(RunClient.State.eState != eBRB_RCSTATE_CONNECTED)
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RunClient.State.nErrorId); // Good
	TEST_ASSERT_EQUAL_STRING("", RunClient.State.sErrorText);

	// Operate Queue besetzen
	memset(&Subscription, 0, sizeof(Subscription));
	BrbUaRcGetSubscription(&RunClient, 1, &Subscription, 0);
	fbUA_MonItemOperateList_Ok.SubscriptionHdl = Subscription.nSubscriptionHandle;
	fbUA_MonItemOperateList_Ok.MonitoredItemHdlCount = 2;
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	BrbUaRcGetMonitoredItem(&RunClient, 1, 0, &MonitoredItem);
	fbUA_MonItemOperateList_Ok.MonitoredItemHdls[0] = MonitoredItem.nMonitoredItemHandle;
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	BrbUaRcGetMonitoredItem(&RunClient, 1, 1, &MonitoredItem);
	fbUA_MonItemOperateList_Ok.MonitoredItemHdls[1] = MonitoredItem.nMonitoredItemHandle;

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_CheckAfterConnect_Namespaces(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_CheckAfterConnect_Namespaces", sizeof(sCurrentUnitTest));

	BRB_ASSERT_EQUAL_UDINT(70, RunClient.Namespaces.nNamespaceCount);
	for(nItemIndex0=0; nItemIndex0 < RunClient.Namespaces.nNamespaceCount; nItemIndex0++)
	{
		memset(&Namespace, 0, sizeof(Namespace));
		uintOut = BrbUaRcGetSrvNamespace(&RunClient, nItemIndex0, &Namespace);
		AssertErrorId(0x00000000, Namespace.nErrorId, "Namespace=", nItemIndex0, 0, 0, 0, 0);
	}
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_CheckAfterConnect_NodeHandles(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_CheckAfterConnect_NodeHandles", sizeof(sCurrentUnitTest));

	BRB_ASSERT_EQUAL_UDINT(70, RunClient.NodeHandles.nNodeHandleCount);
	for(nItemIndex0=0; nItemIndex0 < RunClient.NodeHandles.nNodeHandleCount; nItemIndex0++)
	{
		memset(&NodeHandle, 0, sizeof(NodeHandle));
		uintOut = BrbUaRcGetNodeHandle(&RunClient, nItemIndex0, &NodeHandle);
		TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
		AssertErrorId(0x00000000, NodeHandle.nErrorId, "NodeHandle=", nItemIndex0, 0, 0, 0, 0);
	}
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_CheckAfterConnect_ReadBlocks(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_CheckAfterConnect_ReadBlocks", sizeof(sCurrentUnitTest));

	BRB_ASSERT_EQUAL_UDINT(70, RunClient.ReadBlocks.nBlockCount);
	for(nItemIndex0=0; nItemIndex0 < RunClient.ReadBlocks.nBlockCount; nItemIndex0++)
	{
		memset(&ReadBlock, 0, sizeof(ReadBlock));
		uintOut = BrbUaRcGetReadBlock(&RunClient, nItemIndex0, &ReadBlock, 0);
		TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
		for(nItemIndex1=0; nItemIndex1 < ReadBlock.nReadItemCount; nItemIndex1++)
		{
			memset(&ReadItem, 0, sizeof(ReadItem));
			uintOut = BrbUaRcGetReadItem(&RunClient, nItemIndex0, nItemIndex1, &ReadItem);
			TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
			AssertErrorId(0x00000000, ReadItem.nErrorId, "ReadBlock=", nItemIndex0, "ReadItem=", nItemIndex1, 0, 0);
		}
	}
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_CheckAfterConnect_WriteBlocks(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_CheckAfterConnect_WriteBlocks", sizeof(sCurrentUnitTest));

	BRB_ASSERT_EQUAL_UDINT(70, RunClient.WriteBlocks.nBlockCount);
	for(nItemIndex0=0; nItemIndex0 < RunClient.WriteBlocks.nBlockCount; nItemIndex0++)
	{
		memset(&WriteBlock, 0, sizeof(WriteBlock));
		uintOut = BrbUaRcGetWriteBlock(&RunClient, nItemIndex0, &WriteBlock, 0);
		TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
		for(nItemIndex1=0; nItemIndex1 < WriteBlock.nWriteItemCount; nItemIndex1++)
		{
			memset(&WriteItem, 0, sizeof(WriteItem));
			uintOut = BrbUaRcGetWriteItem(&RunClient, nItemIndex0, nItemIndex1, &WriteItem);
			TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
			AssertErrorId(0x00000000, WriteItem.nErrorId, "WriteBlock=", nItemIndex0, "WriteItem=", nItemIndex1, 0, 0);
		}
	}
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_CheckAfterConnect_Methods(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_CheckAfterConnect_Methods", sizeof(sCurrentUnitTest));

	BRB_ASSERT_EQUAL_UDINT(70, RunClient.Methods.nMethodCount);
	for(nItemIndex0=0; nItemIndex0 < RunClient.Methods.nMethodCount; nItemIndex0++)
	{
		memset(&Method, 0, sizeof(Method));
		uintOut = BrbUaRcGetMethod(&RunClient, nItemIndex0, &Method, 0);
		TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
		AssertErrorId(0x00000000, Method.nErrorId, "Method=", nItemIndex0, 0, 0, 0, 0);
	}
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_CheckAfterConnect_Subscriptions(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_CheckAfterConnect_Subscriptions", sizeof(sCurrentUnitTest));

	BRB_ASSERT_EQUAL_UDINT(70, RunClient.Subscriptions.nSubscriptionCount);
	for(nItemIndex0=0; nItemIndex0 < RunClient.Subscriptions.nSubscriptionCount; nItemIndex0++)
	{
		memset(&Subscription, 0, sizeof(Subscription));
		uintOut = BrbUaRcGetSubscription(&RunClient, nItemIndex0, &Subscription, 0);
		TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
		BRB_ASSERT_EQUAL_UDINT(0x00000000, Subscription.nErrorId); // Good
		for(nItemIndex1=0; nItemIndex1 < Subscription.nMonitoredItemCount; nItemIndex1++)
		{
			memset(&MonitoredItem, 0, sizeof(MonitoredItem));
			uintOut = BrbUaRcGetMonitoredItem(&RunClient, nItemIndex0, nItemIndex1, &MonitoredItem);
			TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
			AssertErrorId(0x00000000, MonitoredItem.nNodeHandleErrorId, "at nNodeHandleErrorId, Sub=", nItemIndex0, ", MonItem=", nItemIndex1, 0, 0);
			AssertErrorId(0x00000000, MonitoredItem.nMonitoredItemErrorId, "at nMonitoredItemErrorId, Sub=", nItemIndex0, ", MonItem=", nItemIndex1, 0, 0);
		}
		for(nItemIndex1=0; nItemIndex1 < Subscription.nEventItemCount; nItemIndex1++)
		{
			memset(&EventItem, 0, sizeof(EventItem));
			uintOut = BrbUaRcGetEventItem(&RunClient, nItemIndex0, nItemIndex1, &EventItem, 0);
			TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
			AssertErrorId(0x00000000, EventItem.nEventNodeHandleErrorId, "Sub=", nItemIndex0, ", EvtItem=", nItemIndex1, 0, 0);
			AssertErrorId(0x00000000, EventItem.nEventItemErrorId, "Sub=", nItemIndex0, ", EvtItem=", nItemIndex1, 0, 0);
		}
	}
	
	// Finished
	TEST_DONE;
}

// Test des ReadBlock 0 -------------------------------------------------------------------------------------------------------------------

_TEST BrbUaRcFull_GetReadBlock_0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_GetReadBlock_0", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&ReadBlock, 0, sizeof(ReadBlock));
	memset(&ReadBlockIntern, 0, sizeof(ReadBlockIntern));
	uintOut = BrbUaRcGetReadBlock(&RunClient, 0, &ReadBlock, &ReadBlockIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(70, ReadBlock.nReadItemCount);
	TEST_ASSERT_EQUAL_INT(70, ReadBlockIntern.nReadItemCount);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.ReadBlock.nReadBlockIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.ReadBlock.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(70, RcMonitor.ReadBlock.ReadBlock.nReadItemCount);
	TEST_ASSERT_EQUAL_INT(70, RcMonitor.ReadBlock.ReadBlockIntern.nReadItemCount);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_GetReadItem_0_69(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_GetReadItem_0_69", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&ReadItem, 0, sizeof(ReadItem));
	uintOut = BrbUaRcGetReadItem(&RunClient, 0, 69, &ReadItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, ReadItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(6, ReadItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, ReadItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Read.anUint[69]", ReadItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, ReadItem.AddInfo.AttributeID);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.Read.anUint[69]", ReadItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, ReadItem.nErrorId); // Good

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.ReadItem.nReadBlockIndex = 0;
	RcMonitor.ReadItem.nReadItemIndex = 69;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.ReadItem.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(3, RcMonitor.ReadItem.ReadItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(6, RcMonitor.ReadItem.ReadItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, RcMonitor.ReadItem.ReadItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Read.anUint[69]", RcMonitor.ReadItem.ReadItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, RcMonitor.ReadItem.ReadItem.AddInfo.AttributeID);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.Read.anUint[69]", RcMonitor.ReadItem.ReadItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.ReadItem.ReadItem.nErrorId); // Good
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_ReadBlock_0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_ReadBlock_0", sizeof(sCurrentUnitTest));

	fbBrbUaRcReadBlock.pRunClient = &RunClient;
	fbBrbUaRcReadBlock.nReadBlockIndex = 0;
	BrbUaRcReadBlock(&fbBrbUaRcReadBlock);
	TEST_BUSY_CONDITION(fbBrbUaRcReadBlock.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRcReadBlock.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, fbBrbUaRcReadBlock.nErrorId); // Good
	TEST_ASSERT_EQUAL_STRING("0x00000000 = Good", fbBrbUaRcReadBlock.sErrorId);
	for(nIndex=0; nIndex<nDATA_INDEX_MAX; nIndex++)
	{
		TEST_ASSERT_EQUAL_INT(nIndex, Data.Read.anUint[nIndex]);
	}
	
	// Finished
	TEST_DONE;
}

// Test des WriteBlock 0 -------------------------------------------------------------------------------------------------------------------

_TEST BrbUaRcFull_GetWriteBlock_O(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_GetWriteBlock_O", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&WriteBlock, 0, sizeof(WriteBlock));
	memset(&WriteBlockIntern, 0, sizeof(WriteBlockIntern));
	uintOut = BrbUaRcGetWriteBlock(&RunClient, 0, &WriteBlock, &WriteBlockIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(70, WriteBlock.nWriteItemCount);
	TEST_ASSERT_EQUAL_INT(70, WriteBlockIntern.nWriteItemCount);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.WriteBlock.nWriteBlockIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.WriteBlock.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(70, RcMonitor.WriteBlock.WriteBlock.nWriteItemCount);
	TEST_ASSERT_EQUAL_INT(70, RcMonitor.WriteBlock.WriteBlockIntern.nWriteItemCount);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_GetWriteItem_0_69(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_GetWriteItem_0_69", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&WriteItem, 0, sizeof(WriteItem));
	uintOut = BrbUaRcGetWriteItem(&RunClient, 0, 69, &WriteItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, WriteItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(6, WriteItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, WriteItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Write.anUint[69]", WriteItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, WriteItem.AddInfo.AttributeID);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.Write.anUint[69]", WriteItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, WriteItem.nErrorId); // Good

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.WriteItem.nWriteBlockIndex = 0;
	RcMonitor.WriteItem.nWriteItemIndex = 69;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.WriteItem.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(3, RcMonitor.WriteItem.WriteItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(6, RcMonitor.WriteItem.WriteItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, RcMonitor.WriteItem.WriteItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.Write.anUint[69]", RcMonitor.WriteItem.WriteItem.NodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(UAAI_Value, RcMonitor.WriteItem.WriteItem.AddInfo.AttributeID);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.Write.anUint[69]", RcMonitor.WriteItem.WriteItem.sVar);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.WriteItem.WriteItem.nErrorId); // Good
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_WriteBlock_0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_WriteBlock_0", sizeof(sCurrentUnitTest));

	Data.Read.anUint[9] = 0;
	fbBrbUaRcWriteBlock.pRunClient = &RunClient;
	fbBrbUaRcWriteBlock.nWriteBlockIndex = 0;
	BrbUaRcWriteBlock(&fbBrbUaRcWriteBlock);
	TEST_BUSY_CONDITION(fbBrbUaRcWriteBlock.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRcWriteBlock.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, fbBrbUaRcWriteBlock.nErrorId); // Good
	TEST_ASSERT_EQUAL_STRING("0x00000000 = Good", fbBrbUaRcWriteBlock.sErrorId);

	// Finished
	TEST_DONE;
}

// Test der Method 0 -------------------------------------------------------------------------------------------------------------------

_TEST BrbUaRcFull_GetMethod_0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_GetMethod_0", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Method, 0, sizeof(Method));
	memset(&MethodIntern, 0, sizeof(MethodIntern));
	uintOut = BrbUaRcGetMethod(&RunClient, 0, &Method, &MethodIntern);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, Method.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(6, Method.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, Method.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs", Method.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(6, Method.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, Method.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Args10", Method.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, Method.tTimeout);
	TEST_ASSERT_EQUAL_INT(10, Method.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(10, Method.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Method.nErrorId); // Good
	TEST_ASSERT_EQUAL_INT(3, MethodIntern.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(6, MethodIntern.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, MethodIntern.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs", MethodIntern.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(6, MethodIntern.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, MethodIntern.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Args10", MethodIntern.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, MethodIntern.tTimeout);
	TEST_ASSERT_EQUAL_INT(10, MethodIntern.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(10, MethodIntern.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MethodIntern.nErrorId); // Good

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Method.nMethodIndex = 0;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.Method.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(3, RcMonitor.Method.Method.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(6, RcMonitor.Method.Method.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, RcMonitor.Method.Method.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs", RcMonitor.Method.Method.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(6, RcMonitor.Method.Method.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, RcMonitor.Method.Method.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Args10", RcMonitor.Method.Method.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, RcMonitor.Method.Method.tTimeout);
	TEST_ASSERT_EQUAL_INT(10, RcMonitor.Method.Method.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(10, RcMonitor.Method.Method.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Method.nErrorId);  // Good
	TEST_ASSERT_EQUAL_INT(3, RcMonitor.Method.MethodIntern.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(6, RcMonitor.Method.MethodIntern.ObjectNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, RcMonitor.Method.MethodIntern.ObjectNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs", RcMonitor.Method.MethodIntern.ObjectNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(6, RcMonitor.Method.MethodIntern.MethodNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, RcMonitor.Method.MethodIntern.MethodNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Args10", RcMonitor.Method.MethodIntern.MethodNodeId.Identifier);
	TEST_ASSERT_EQUAL_INT(500, RcMonitor.Method.MethodIntern.tTimeout);
	TEST_ASSERT_EQUAL_INT(10, RcMonitor.Method.MethodIntern.nInputArgsCount);
	TEST_ASSERT_EQUAL_INT(10, RcMonitor.Method.MethodIntern.nOutputArgsCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.Method.Method.nErrorId);  // Good

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_GetArgumentIn_0_9(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_GetArgumentIn_0_9", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Argument, 0, sizeof(Argument));
	uintOut = BrbUaRcGetArgument(&RunClient, 0, 0, 9, &Argument);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_STRING("nIn9", Argument.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.Methods.Args10.nIn9", Argument.Value);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Argument.nMethodIndex = 0;
	RcMonitor.Argument.bOutput = 0;
	RcMonitor.Argument.nArgumentIndex = 9;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.Argument.nMonitorStatus);
	TEST_ASSERT_EQUAL_STRING("nIn9", RcMonitor.Argument.Argument.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.Methods.Args10.nIn9", RcMonitor.Argument.Argument.Value);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_GetArgumentOut_0_9(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_GetArgumentOut_0_9", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Argument, 0, sizeof(Argument));
	uintOut = BrbUaRcGetArgument(&RunClient, 0, 1, 9, &Argument);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_STRING("nOut9", Argument.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.Methods.Args10.nOut9", Argument.Value);

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Argument.nMethodIndex = 0;
	RcMonitor.Argument.bOutput = 1;
	RcMonitor.Argument.nArgumentIndex = 9;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.Argument.nMonitorStatus);
	TEST_ASSERT_EQUAL_STRING("nOut9", RcMonitor.Argument.Argument.Name);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.Methods.Args10.nOut9", RcMonitor.Argument.Argument.Value);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_CallMethod_Args10_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_CallMethod_Args10_Ok", sizeof(sCurrentUnitTest));

	fbBrbUaRcCallMethod.pRunClient = &RunClient;
	fbBrbUaRcCallMethod.nMethodIndex = 0;
	BrbUaRcCallMethod(&fbBrbUaRcCallMethod);
	if(fbBrbUaRcCallMethod.bInit == 1)
	{
		// Eing�nge besetzen
		memset(&Data.Methods.Args10, 0, sizeof(Data.Methods.Args10));
		Data.Methods.Args10.nIn0 = (UINT)BrbGetRandomUdint(0,65535);
		Data.Methods.Args10.nIn1 = (UINT)BrbGetRandomUdint(0,65535);
		Data.Methods.Args10.nIn2 = (UINT)BrbGetRandomUdint(0,65535);
		Data.Methods.Args10.nIn3 = (UINT)BrbGetRandomUdint(0,65535);
		Data.Methods.Args10.nIn4 = (UINT)BrbGetRandomUdint(0,65535);
		Data.Methods.Args10.nIn5 = (UINT)BrbGetRandomUdint(0,65535);
		Data.Methods.Args10.nIn6 = (UINT)BrbGetRandomUdint(0,65535);
		Data.Methods.Args10.nIn7 = (UINT)BrbGetRandomUdint(0,65535);
		Data.Methods.Args10.nIn8 = (UINT)BrbGetRandomUdint(0,65535);
		Data.Methods.Args10.nIn9 = (UINT)BrbGetRandomUdint(0,65535);
	}
	TEST_BUSY_CONDITION(fbBrbUaRcCallMethod.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRcCallMethod.nStatus);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, fbBrbUaRcCallMethod.nErrorId);
	TEST_ASSERT_EQUAL_STRING("0x00000000 = Good", fbBrbUaRcCallMethod.sErrorId);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, fbBrbUaRcCallMethod.nMethodResult);
	TEST_ASSERT_EQUAL_STRING("0x00000000 = Good", fbBrbUaRcCallMethod.sMethodResult);
	nCallCount++;
	TEST_ASSERT_EQUAL_INT(nCallCount, fbBrbUaRcCallMethod.nCallCount);
	TEST_ASSERT_EQUAL_INT(Data.Methods.Args10.nIn0, Data.Methods.Args10.nOut0);
	TEST_ASSERT_EQUAL_INT(Data.Methods.Args10.nIn1, Data.Methods.Args10.nOut1);
	TEST_ASSERT_EQUAL_INT(Data.Methods.Args10.nIn2, Data.Methods.Args10.nOut2);
	TEST_ASSERT_EQUAL_INT(Data.Methods.Args10.nIn3, Data.Methods.Args10.nOut3);
	TEST_ASSERT_EQUAL_INT(Data.Methods.Args10.nIn4, Data.Methods.Args10.nOut4);
	TEST_ASSERT_EQUAL_INT(Data.Methods.Args10.nIn5, Data.Methods.Args10.nOut5);
	TEST_ASSERT_EQUAL_INT(Data.Methods.Args10.nIn6, Data.Methods.Args10.nOut6);
	TEST_ASSERT_EQUAL_INT(Data.Methods.Args10.nIn7, Data.Methods.Args10.nOut7);
	TEST_ASSERT_EQUAL_INT(Data.Methods.Args10.nIn8, Data.Methods.Args10.nOut8);
	TEST_ASSERT_EQUAL_INT(Data.Methods.Args10.nIn9, Data.Methods.Args10.nOut9);

	// Finished
	TEST_DONE;
}

// Test der Subscripton-Parameter -------------------------------------------------------------------------------------------------------------------

_TEST BrbUaRcFull_Check_Subscriptions_General(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Check_Subscriptions_General", sizeof(sCurrentUnitTest));

	BRB_ASSERT_EQUAL_UDINT(70, RunClient.Subscriptions.nSubscriptionCount);
	BRB_ASSERT_EQUAL_UDINT(140, RunClient.Subscriptions.nMonitoredItemsCountTotal);
	BRB_ASSERT_EQUAL_UDINT(139, RunClient.Subscriptions.nEventItemsCountTotal);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_Check_Subscription_0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Check_Subscription_0", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Subscription, 0, sizeof(Subscription));
	uintOut = BrbUaRcGetSubscription(&RunClient, 0, &Subscription, 0);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	BRB_ASSERT_EQUAL_BOOL(1, Subscription.bPublishingEnable);
	TEST_ASSERT_EQUAL_INT(100, Subscription.nPriority);
	BRB_ASSERT_EQUAL_DINT(500, Subscription.tPublishingInterval);
	TEST_ASSERT_EQUAL_INT(70, Subscription.nMonitoredItemCount);
	TEST_ASSERT_EQUAL_INT(70, Subscription.nEventItemCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Subscription.nErrorId); // Good

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_Check_MonitoredItem_0_0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Check_MonitoredItem_0_0", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, 0, 0, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, MonitoredItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(6, MonitoredItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, MonitoredItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.SubscriptionVar.anUint[0]", MonitoredItem.NodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(UAAI_Value, MonitoredItem.AddInfo.AttributeID); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.SubscriptionVar.anUint[0]", MonitoredItem.sVarValue);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.SubscriptionVar.anNodeQualityId[0]",  MonitoredItem.sVarNodeQualityId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.SubscriptionVar.adtTimeStamp[0]", MonitoredItem.sVarTimeStamp);
	BRB_ASSERT_EQUAL_UDINT(0, MonitoredItem.nQueueSizeOri);
	BRB_ASSERT_EQUAL_DINT(500, MonitoredItem.MonitoringParameter.SamplingInterval);
	BRB_ASSERT_EQUAL_UDINT(1, MonitoredItem.MonitoringParameter.QueueSize);
	BRB_ASSERT_EQUAL_BOOL(1, MonitoredItem.MonitoringParameter.DiscardOldest);
	BRB_ASSERT_EQUAL_DINT(UADT_None, MonitoredItem.MonitoringParameter.DeadbandType); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_REAL(0.0, MonitoredItem.MonitoringParameter.Deadband);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionVar.anNodeQualityId[0]); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nMonitoredItemErrorId); // Good
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_Check_MonitoredItem_0_69(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Check_MonitoredItem_0_69", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, 0, 69, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, MonitoredItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(6, MonitoredItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, MonitoredItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.SubscriptionVar.anUint[69]", MonitoredItem.NodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(UAAI_Value, MonitoredItem.AddInfo.AttributeID); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.SubscriptionVar.anUint[69]", MonitoredItem.sVarValue);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.SubscriptionVar.anNodeQualityId[69]",  MonitoredItem.sVarNodeQualityId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.SubscriptionVar.adtTimeStamp[69]", MonitoredItem.sVarTimeStamp);
	BRB_ASSERT_EQUAL_UDINT(0, MonitoredItem.nQueueSizeOri);
	BRB_ASSERT_EQUAL_DINT(500, MonitoredItem.MonitoringParameter.SamplingInterval);
	BRB_ASSERT_EQUAL_UDINT(1, MonitoredItem.MonitoringParameter.QueueSize);
	BRB_ASSERT_EQUAL_BOOL(1, MonitoredItem.MonitoringParameter.DiscardOldest);
	BRB_ASSERT_EQUAL_DINT(UADT_None, MonitoredItem.MonitoringParameter.DeadbandType); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_REAL(0.0, MonitoredItem.MonitoringParameter.Deadband);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionVar.anNodeQualityId[69]); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nMonitoredItemErrorId); // Good
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_Check_EventItem_0_0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Check_EventItem_0_0", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventItem, 0, sizeof(EventItem));
	uintOut = BrbUaRcGetEventItem(&RunClient, 0, 0, &EventItem, 0);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventItem.nEventDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.EventNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.EventNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("2253", EventItem.EventNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	TEST_ASSERT_EQUAL_INT(0, EventItem.nTypeDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("11446", EventItem.TypeNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventItemErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(1000, EventItem.tTimeout);
	BRB_ASSERT_EQUAL_BOOL(0, EventItem.bCallOperate);
	BRB_ASSERT_EQUAL_UDINT(1, EventItem.nEventFieldCount);
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_Check_Subscription_1(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Check_Subscription_1", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Subscription, 0, sizeof(Subscription));
	uintOut = BrbUaRcGetSubscription(&RunClient, 1, &Subscription, 0);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	BRB_ASSERT_EQUAL_BOOL(1, Subscription.bPublishingEnable);
	TEST_ASSERT_EQUAL_INT(100, Subscription.nPriority);
	BRB_ASSERT_EQUAL_DINT(500, Subscription.tPublishingInterval);
	TEST_ASSERT_EQUAL_INT(2, Subscription.nMonitoredItemCount);
	TEST_ASSERT_EQUAL_INT(1, Subscription.nEventItemCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Subscription.nErrorId); // Good

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_Check_MonitoredItem_1_0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Check_MonitoredItem_0_68", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, 1, 0, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, MonitoredItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(6, MonitoredItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, MonitoredItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.SubscriptionQueue.nUintSrv", MonitoredItem.NodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(UAAI_Value, MonitoredItem.AddInfo.AttributeID); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.SubscriptionQueue.nUintCltQueue002", MonitoredItem.sVarValue);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.SubscriptionQueue.nUintCltQueueNodeQuality002",  MonitoredItem.sVarNodeQualityId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.SubscriptionQueue.dtUintCltQueueTimeStamp002", MonitoredItem.sVarTimeStamp);
	BRB_ASSERT_EQUAL_UDINT(2, MonitoredItem.nQueueSizeOri);
	BRB_ASSERT_EQUAL_DINT(100, MonitoredItem.MonitoringParameter.SamplingInterval);
	BRB_ASSERT_EQUAL_UDINT(2, MonitoredItem.MonitoringParameter.QueueSize);
	BRB_ASSERT_EQUAL_BOOL(1, MonitoredItem.MonitoringParameter.DiscardOldest);
	BRB_ASSERT_EQUAL_DINT(UADT_None, MonitoredItem.MonitoringParameter.DeadbandType); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_REAL(0.0, MonitoredItem.MonitoringParameter.Deadband);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality002[0]); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality002[1]); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nMonitoredItemErrorId); // Good
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_Check_MonitoredItem_1_1(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Check_MonitoredItem_0_69", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, 1, 1, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(3, MonitoredItem.nDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(6, MonitoredItem.NodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_String, MonitoredItem.NodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRs:Data.SubscriptionQueue.nUintSrv", MonitoredItem.NodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(UAAI_Value, MonitoredItem.AddInfo.AttributeID); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.SubscriptionQueue.nUintCltQueue010", MonitoredItem.sVarValue);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.SubscriptionQueue.nUintCltQueueNodeQuality010",  MonitoredItem.sVarNodeQualityId);
	TEST_ASSERT_EQUAL_STRING("::UtBrbUaRcF:Data.SubscriptionQueue.dtUintCltQueueTimeStamp010", MonitoredItem.sVarTimeStamp);
	BRB_ASSERT_EQUAL_UDINT(10, MonitoredItem.nQueueSizeOri);
	BRB_ASSERT_EQUAL_DINT(100, MonitoredItem.MonitoringParameter.SamplingInterval);
	BRB_ASSERT_EQUAL_UDINT(10, MonitoredItem.MonitoringParameter.QueueSize);
	BRB_ASSERT_EQUAL_BOOL(1, MonitoredItem.MonitoringParameter.DiscardOldest);
	BRB_ASSERT_EQUAL_DINT(UADT_None, MonitoredItem.MonitoringParameter.DeadbandType); // NOLINT(clang-diagnostic-sign-conversion)
	TEST_ASSERT_EQUAL_REAL(0.0, MonitoredItem.MonitoringParameter.Deadband);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[0]); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[1]); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[2]); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[3]); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[4]); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[5]); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[6]); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[7]); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[8]); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[9]); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nMonitoredItemErrorId); // Good
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_Check_EventItem_1_0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Check_EventItem_1_0", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventItem, 0, sizeof(EventItem));
	uintOut = BrbUaRcGetEventItem(&RunClient, 1, 0, &EventItem, 0);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventItem.nEventDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.EventNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.EventNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("2253", EventItem.EventNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	TEST_ASSERT_EQUAL_INT(0, EventItem.nTypeDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("11446", EventItem.TypeNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventItemErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(1000, EventItem.tTimeout);
	BRB_ASSERT_EQUAL_BOOL(1, EventItem.bCallOperate);
	BRB_ASSERT_EQUAL_UDINT(1, EventItem.nEventFieldCount);
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_Check_Subscription_2(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Check_Subscription_2", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Subscription, 0, sizeof(Subscription));
	uintOut = BrbUaRcGetSubscription(&RunClient, 2, &Subscription, 0);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	BRB_ASSERT_EQUAL_BOOL(1, Subscription.bPublishingEnable);
	TEST_ASSERT_EQUAL_INT(100, Subscription.nPriority);
	BRB_ASSERT_EQUAL_DINT(500, Subscription.tPublishingInterval);
	TEST_ASSERT_EQUAL_INT(1, Subscription.nMonitoredItemCount);
	TEST_ASSERT_EQUAL_INT(1, Subscription.nEventItemCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Subscription.nErrorId); // Good

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_Check_EventItem_2_0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Check_EventItem_2_0", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventItem, 0, sizeof(EventItem));
	uintOut = BrbUaRcGetEventItem(&RunClient, 2, 0, &EventItem, 0);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventItem.nEventDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.EventNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.EventNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("2253", EventItem.EventNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	TEST_ASSERT_EQUAL_INT(0, EventItem.nTypeDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("11446", EventItem.TypeNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventItemErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(1000, EventItem.tTimeout);
	BRB_ASSERT_EQUAL_BOOL(1, EventItem.bCallOperate);
	BRB_ASSERT_EQUAL_UDINT(1, EventItem.nEventFieldCount);
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_Check_Subscription_3(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Check_Subscription_3", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Subscription, 0, sizeof(Subscription));
	uintOut = BrbUaRcGetSubscription(&RunClient, 3, &Subscription, 0);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	BRB_ASSERT_EQUAL_BOOL(1, Subscription.bPublishingEnable);
	TEST_ASSERT_EQUAL_INT(100, Subscription.nPriority);
	BRB_ASSERT_EQUAL_DINT(500, Subscription.tPublishingInterval);
	TEST_ASSERT_EQUAL_INT(1, Subscription.nMonitoredItemCount);
	TEST_ASSERT_EQUAL_INT(1, Subscription.nEventItemCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Subscription.nErrorId); // Good

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_Check_EventItem_3_0(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Check_EventItem_3_0", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&EventItem, 0, sizeof(EventItem));
	uintOut = BrbUaRcGetEventItem(&RunClient, 3, 0, &EventItem, 0);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	TEST_ASSERT_EQUAL_INT(0, EventItem.nEventDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.EventNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.EventNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("2253", EventItem.EventNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	TEST_ASSERT_EQUAL_INT(0, EventItem.nTypeDatObjNamespaceIndex);
	TEST_ASSERT_EQUAL_INT(0, EventItem.TypeNodeId.NamespaceIndex);
	TEST_ASSERT_EQUAL_INT(UAIT_Numeric, EventItem.TypeNodeId.IdentifierType);
	TEST_ASSERT_EQUAL_STRING("11446", EventItem.TypeNodeId.Identifier);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, EventItem.nEventItemErrorId); // Good
	BRB_ASSERT_EQUAL_DINT(1000, EventItem.tTimeout);
	BRB_ASSERT_EQUAL_BOOL(1, EventItem.bCallOperate);
	BRB_ASSERT_EQUAL_UDINT(1, EventItem.nEventFieldCount);
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_Check_Subscription_69(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Check_Subscription_69", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Subscription, 0, sizeof(Subscription));
	uintOut = BrbUaRcGetSubscription(&RunClient, 69, &Subscription, 0);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	BRB_ASSERT_EQUAL_BOOL(0, Subscription.bPublishingEnable);
	TEST_ASSERT_EQUAL_INT(90, Subscription.nPriority);
	BRB_ASSERT_EQUAL_DINT(500, Subscription.tPublishingInterval);
	TEST_ASSERT_EQUAL_INT(1, Subscription.nMonitoredItemCount);
	TEST_ASSERT_EQUAL_INT(1, Subscription.nEventItemCount);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Subscription.nErrorId); // Good

	// Finished
	TEST_DONE;
}

// Test des Subscripton-Empfangs -------------------------------------------------------------------------------------------------------------------

_TEST BrbUaRcFull_SubscriptionQueue_Receive_StartOperate(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_SubscriptionQueue_Receive_StartOperate", sizeof(sCurrentUnitTest));

	// Operate-Aufruf starten
	bOperateSubscriptionQueue = 1;

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_Subscriptions_Receive_Store(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Subscriptions_Receive_Store", sizeof(sCurrentUnitTest));

	// Werte speichern
	memcpy(&SubscriptionVarDataStored, &Data.SubscriptionVar, sizeof(SubscriptionVarDataStored));
	memcpy(&SubscriptionQueueDataStored, &Data.SubscriptionQueue, sizeof(SubscriptionQueueDataStored));
	memcpy(&SubscriptionEventDataStored, &Data.SubscriptionEvent, sizeof(SubscriptionEventDataStored));
	memset(&nSubEventReceiveCountStored, 0, sizeof(nSubEventReceiveCountStored));
	nSubEventReceiveCountStored[0] = BrbUaRcGetEventItemReceiveCount(&RunClient, 0, 0);
	nSubEventReceiveCountStored[1] = BrbUaRcGetEventItemReceiveCount(&RunClient, 1, 0);
	nSubEventReceiveCountStored[2] = BrbUaRcGetEventItemReceiveCount(&RunClient, 2, 0);
	nSubEventReceiveCountStored[3] = BrbUaRcGetEventItemReceiveCount(&RunClient, 3, 0);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_Subscriptions_Receive_Wait(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Subscriptions_Receive_Wait", sizeof(sCurrentUnitTest));

	// Zeit abwarten
	fbTonWait.IN = 1;
	fbTonWait.PT = 2000;
	TON(&fbTonWait);
	TEST_BUSY_CONDITION(fbTonWait.Q == 0)
	fbTonWait.IN = 0;
	TON(&fbTonWait);

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_Subscriptions_Receive_Check(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_Subscriptions_Receive_Check", sizeof(sCurrentUnitTest));

	// Werte testen. Achtung: Da der Update stark von Zeiten abh�ngt, die ArSim aber nicht deterministisch ist, kann hier manchmal ein Fehler registiert werden!
	
	// SubscriptionVar
	TEST_ASSERT_MESSAGE(SubscriptionVarDataStored.anUint[10] != Data.SubscriptionVar.anUint[10], "SubscriptionVar [10] was not updated!");

	// SubscriptionQueue
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUintCltQueue002[0] != Data.SubscriptionQueue.nUintCltQueue002[0], "SubscriptionQueue002[0] operated was not updated!");
	// Bei QueueSize=2: NodeQuality=1152
	// Siehe Ticketnr 400426494: Ist so korrekt
	BRB_ASSERT_EQUAL_UDINT(1152, Data.SubscriptionQueue.nUintCltQueueNodeQuality002[0]);
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUintCltQueue002[1] != Data.SubscriptionQueue.nUintCltQueue002[1], "SubscriptionQueue002[1] operated was not updated!");
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality002[1]); // Good
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUintCltQueue010[0] != Data.SubscriptionQueue.nUintCltQueue010[0], "SubscriptionQueue010[0] operated was not updated!");
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[0]); // Good
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUintCltQueue010[1] != Data.SubscriptionQueue.nUintCltQueue010[1], "SubscriptionQueue010[1] operated was not updated!");
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[1]); // Good
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUintCltQueue010[2] != Data.SubscriptionQueue.nUintCltQueue010[2], "SubscriptionQueue010[2] operated was not updated!");
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[2]); // Good
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUintCltQueue010[3] != Data.SubscriptionQueue.nUintCltQueue010[3], "SubscriptionQueue010[3] operated was not updated!");
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[3]); // Good
	/* Es werden nur 4 �nderungen erkannt:
		ChangeRate = 10ms
		SamplingRate = 100ms
		PublishingIntervall = 500ms
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUintCltQueue010[4] != Data.SubscriptionQueue.nUintCltQueue010[4], "SubscriptionQueue010[4] operated was not updated!");
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[4]); // Good
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUintCltQueue010[5] != Data.SubscriptionQueue.nUintCltQueue010[5], "SubscriptionQueue010[5] operated was not updated!");
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[5]); // Good
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUintCltQueue010[6] != Data.SubscriptionQueue.nUintCltQueue010[6], "SubscriptionQueue010[6] operated was not updated!");
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[6]); // Good
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUintCltQueue010[7] != Data.SubscriptionQueue.nUintCltQueue010[7], "SubscriptionQueue010[7] operated was not updated!");
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[7]); // Good
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUintCltQueue010[8] != Data.SubscriptionQueue.nUintCltQueue010[8], "SubscriptionQueue010[8] operated was not updated!");
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[8]); // Good
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUintCltQueue010[9] != Data.SubscriptionQueue.nUintCltQueue010[9], "SubscriptionQueue010[9] operated was not updated!");
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Data.SubscriptionQueue.nUintCltQueueNodeQuality010[9]); // Good
	*/
	
	// SubscriptionEvent Sub 1 Evt0
	udintOut = BrbUaRcGetEventItemReceiveCount(&RunClient, 1, 0);
	TEST_ASSERT_MESSAGE(nSubEventReceiveCountStored[0] != udintOut, "SubscriptionEvent Sub1, Evt0: ReceiveCount was not updated!");
	
	// SubscriptionEvent Sub 2 Evt0
	udintOut = BrbUaRcGetEventItemReceiveCount(&RunClient, 2, 0);
	TEST_ASSERT_MESSAGE(nSubEventReceiveCountStored[1] != udintOut, "SubscriptionEvent Sub2, Evt0: ReceiveCount was not updated!");
	
	// SubscriptionEvent Sub 3 Evt0
	udintOut = BrbUaRcGetEventItemReceiveCount(&RunClient, 3, 0);
	TEST_ASSERT_MESSAGE(nSubEventReceiveCountStored[2] != udintOut, "SubscriptionEvent Sub3, Evt0: ReceiveCount was not updated!");
	
	// SubscriptionEvent Sub 4 Evt0
	udintOut = BrbUaRcGetEventItemReceiveCount(&RunClient, 4, 0);
	TEST_ASSERT_MESSAGE(nSubEventReceiveCountStored[3] != udintOut, "SubscriptionEvent Sub4, Evt0: ReceiveCount was not updated!");
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcFull_SubscriptionQueue_Receive_EndOperate(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull.BrbUaRcFull_SubscriptionQueue_Receive_EndOperate", sizeof(sCurrentUnitTest));

	// Operate-Aufruf beenden
	bOperateSubscriptionQueue = 0;

	// Zeit abwarten
	fbTonWait.IN = 1;
	fbTonWait.PT = 1000;
	TON(&fbTonWait);
	TEST_BUSY_CONDITION(fbTonWait.Q == 0)
	fbTonWait.IN = 0;
	TON(&fbTonWait);

	// Finished
	TEST_DONE;
}

_TEARDOWN_SET(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcFull._TEARDOWN_SET", sizeof(sCurrentUnitTest));

	CyclicMonitor.bEnable =  0;
	bOperateSubscriptionQueue = 0;
	bRunCyclic = 0;
	// Exit
	fbBrbUaRunClientExit.pRunClient = &RunClient;
	BrbUaRunClientExit(&fbBrbUaRunClientExit);
	TEST_BUSY_CONDITION(fbBrbUaRunClientExit.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRunClientExit.nStatus);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-09-26 13:05:38Z
By B+R UnitTest Helper Version: 6.0.0.173
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaRcFull_Init", BrbUaRcFull_Init), 
	new_TestFixture("BrbUaRcFull_Connect", BrbUaRcFull_Connect), 
	new_TestFixture("BrbUaRcFull_CheckAfterConnect_Namespaces", BrbUaRcFull_CheckAfterConnect_Namespaces), 
	new_TestFixture("BrbUaRcFull_CheckAfterConnect_NodeHandles", BrbUaRcFull_CheckAfterConnect_NodeHandles), 
	new_TestFixture("BrbUaRcFull_CheckAfterConnect_ReadBlocks", BrbUaRcFull_CheckAfterConnect_ReadBlocks), 
	new_TestFixture("BrbUaRcFull_CheckAfterConnect_WriteBlocks", BrbUaRcFull_CheckAfterConnect_WriteBlocks), 
	new_TestFixture("BrbUaRcFull_CheckAfterConnect_Methods", BrbUaRcFull_CheckAfterConnect_Methods), 
	new_TestFixture("BrbUaRcFull_CheckAfterConnect_Subscriptions", BrbUaRcFull_CheckAfterConnect_Subscriptions), 
	new_TestFixture("BrbUaRcFull_GetReadBlock_0", BrbUaRcFull_GetReadBlock_0), 
	new_TestFixture("BrbUaRcFull_GetReadItem_0_69", BrbUaRcFull_GetReadItem_0_69), 
	new_TestFixture("BrbUaRcFull_ReadBlock_0", BrbUaRcFull_ReadBlock_0), 
	new_TestFixture("BrbUaRcFull_GetWriteBlock_O", BrbUaRcFull_GetWriteBlock_O), 
	new_TestFixture("BrbUaRcFull_GetWriteItem_0_69", BrbUaRcFull_GetWriteItem_0_69), 
	new_TestFixture("BrbUaRcFull_WriteBlock_0", BrbUaRcFull_WriteBlock_0), 
	new_TestFixture("BrbUaRcFull_GetMethod_0", BrbUaRcFull_GetMethod_0), 
	new_TestFixture("BrbUaRcFull_GetArgumentIn_0_9", BrbUaRcFull_GetArgumentIn_0_9), 
	new_TestFixture("BrbUaRcFull_GetArgumentOut_0_9", BrbUaRcFull_GetArgumentOut_0_9), 
	new_TestFixture("BrbUaRcFull_CallMethod_Args10_Ok", BrbUaRcFull_CallMethod_Args10_Ok), 
	new_TestFixture("BrbUaRcFull_Check_Subscriptions_General", BrbUaRcFull_Check_Subscriptions_General), 
	new_TestFixture("BrbUaRcFull_Check_Subscription_0", BrbUaRcFull_Check_Subscription_0), 
	new_TestFixture("BrbUaRcFull_Check_MonitoredItem_0_0", BrbUaRcFull_Check_MonitoredItem_0_0), 
	new_TestFixture("BrbUaRcFull_Check_MonitoredItem_0_69", BrbUaRcFull_Check_MonitoredItem_0_69), 
	new_TestFixture("BrbUaRcFull_Check_EventItem_0_0", BrbUaRcFull_Check_EventItem_0_0), 
	new_TestFixture("BrbUaRcFull_Check_Subscription_1", BrbUaRcFull_Check_Subscription_1), 
	new_TestFixture("BrbUaRcFull_Check_MonitoredItem_1_0", BrbUaRcFull_Check_MonitoredItem_1_0), 
	new_TestFixture("BrbUaRcFull_Check_MonitoredItem_1_1", BrbUaRcFull_Check_MonitoredItem_1_1), 
	new_TestFixture("BrbUaRcFull_Check_EventItem_1_0", BrbUaRcFull_Check_EventItem_1_0), 
	new_TestFixture("BrbUaRcFull_Check_Subscription_2", BrbUaRcFull_Check_Subscription_2), 
	new_TestFixture("BrbUaRcFull_Check_EventItem_2_0", BrbUaRcFull_Check_EventItem_2_0), 
	new_TestFixture("BrbUaRcFull_Check_Subscription_3", BrbUaRcFull_Check_Subscription_3), 
	new_TestFixture("BrbUaRcFull_Check_EventItem_3_0", BrbUaRcFull_Check_EventItem_3_0), 
	new_TestFixture("BrbUaRcFull_Check_Subscription_69", BrbUaRcFull_Check_Subscription_69), 
	new_TestFixture("BrbUaRcFull_SubscriptionQueue_Receive_StartOperate", BrbUaRcFull_SubscriptionQueue_Receive_StartOperate), 
	new_TestFixture("BrbUaRcFull_Subscriptions_Receive_Store", BrbUaRcFull_Subscriptions_Receive_Store), 
	new_TestFixture("BrbUaRcFull_Subscriptions_Receive_Wait", BrbUaRcFull_Subscriptions_Receive_Wait), 
	new_TestFixture("BrbUaRcFull_Subscriptions_Receive_Check", BrbUaRcFull_Subscriptions_Receive_Check), 
	new_TestFixture("BrbUaRcFull_SubscriptionQueue_Receive_EndOperate", BrbUaRcFull_SubscriptionQueue_Receive_EndOperate), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaRcFull, "Set_BrbUaRcFull", 0, 0, fixtures, setupSet, teardownSet, cyclicSetCaller);

