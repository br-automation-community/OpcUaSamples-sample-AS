#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_TEST BrbUaAddNodeIdBrowseNameText_NulPtr(void)
{
	dwordOut = BrbUaAddNodeIdBrowseNameText(0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x80460000, dwordOut); // = Bad_StructureMissing

	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, 0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x80460000, dwordOut); // = Bad_StructureMissing

	// Finished
	TEST_DONE;
}

_TEST BrbUaAddNodeIdBrowseNameText_AddEmpty(void)
{
	strcpy(stringIn0, "Test ");
	memset(&nodeIdIn0, 0, sizeof(nodeIdIn0));
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=", stringIn0);

	// Finished
	TEST_DONE;
}

_TEST BrbUaAddNodeIdBrowseNameText_AddKnown(void)
{
	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "84", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=84 - Root", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "85", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=85 - Objects", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "2253", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=2253 - Server", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "86", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=86 - Types", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "24", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=24 - BaseDataType", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "1", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=1 - Boolean", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "5", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=5 - UInt16", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "2041", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=2041 - BaseEventType", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "11436", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=11436 - ProgressEventType", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "91", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=91 - ReferenceTypes", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "33", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=33 - HierarchicalReferences", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "35", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=35 - Organizes", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "46", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=46 - HasProperty", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "32", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=32 - NonHierarchicalReferences", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "40", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=40 - HasTypeDefinition", stringIn0);

	// Finished
	TEST_DONE;
}

_TEST BrbUaAddNodeIdBrowseNameText_AddUnknown(void)
{
	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "0", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=0", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "42", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=42", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "10000", 0);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=0;i=10000", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "3002", 1);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=1;i=3002", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "5001", 2);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=2;i=5001", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "3007", 3);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=3;i=3007", stringIn0);

	strcpy(stringIn0, "Test ");
	BrbUaSetNodeId(&nodeIdIn0, "20000", 4);
	dwordOut = BrbUaAddNodeIdBrowseNameText(&nodeIdIn0, stringIn0, sizeof(stringIn0));
	BRB_ASSERT_EQUAL_UDINT(0x00000000, dwordOut); // = Good
	TEST_ASSERT_EQUAL_STRING("Test ns=4;i=20000", stringIn0);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-11-21 14:41:06Z
By B+R UnitTest Helper Version: 6.0.0.173
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaAddNodeIdBrowseNameText_NulPtr", BrbUaAddNodeIdBrowseNameText_NulPtr), 
	new_TestFixture("BrbUaAddNodeIdBrowseNameText_AddEmpty", BrbUaAddNodeIdBrowseNameText_AddEmpty), 
	new_TestFixture("BrbUaAddNodeIdBrowseNameText_AddKnown", BrbUaAddNodeIdBrowseNameText_AddKnown), 
	new_TestFixture("BrbUaAddNodeIdBrowseNameText_AddUnknown", BrbUaAddNodeIdBrowseNameText_AddUnknown), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaAddNodeIdBrowseNameText, "Set_BrbUaAddNodeIdBrowseNameText", 0, 0, fixtures, 0, 0, 0);

