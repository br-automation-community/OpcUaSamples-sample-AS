#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_SETUP_SET(void)
{
	bRunCyclic = 0;
	memset(&RunClient, 0, sizeof(RunClient));
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	memset(&fbBrbUaRunClientInit, 0, sizeof(fbBrbUaRunClientInit));
	memset(&fbBrbUaRunClientCyclic, 0, sizeof(fbBrbUaRunClientCyclic));
	memset(&fbBrbUaRunClientExit, 0, sizeof(fbBrbUaRunClientExit));

	// Finished
	TEST_DONE;
}

_TEST Init(void)
{
	brsstrcpy((UDINT)&RunClient.Cfg.sCfgDataObjName, (UDINT)&"UtClt");
	fbBrbUaRunClientInit.pRunClient = &RunClient;
	BrbUaRunClientInit(&fbBrbUaRunClientInit);
	TEST_BUSY_CONDITION(fbBrbUaRunClientInit.nStatus == eBRB_ERR_BUSY)
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, fbBrbUaRunClientInit.nStatus);
	
	// Finished
	TEST_DONE;
}

_CYCLIC_SET(void)
{
	if(RunClient.State.eState >= eBRB_RCSTATE_INIT_DONE && RunClient.State.eState < eBRB_RCSTATE_EXITING)
	{
		if(bRunCyclic == 1)
		{
			fbBrbUaRunClientCyclic.pRunClient = &RunClient;
			BrbUaRunClientCyclic(&fbBrbUaRunClientCyclic);
		}
	}
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	return;
}

_TEST Connect(void)
{
	bRunCyclic = 1;
	BrbStringCopy(RunClient.Cfg.sServerEndpointUrl, "opc.tcp://127.0.0.1:4840", sizeof(RunClient.Cfg.sServerEndpointUrl));
	RunClient.eCmd = eBRB_RCCLTCMD_CONNECT;
	TEST_ABORT_CONDITION_MSG(fbBrbUaRunClientCyclic.nStatus != eBRB_ERR_OK, "RunClient not connecting!")
	TEST_BUSY_CONDITION(RunClient.State.eState != eBRB_RCSTATE_CONNECTED)

	nNamespaceBrPlcPv = BrbUaRcGetSrvNamespace(&RunClient, 1, 0);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-11-25 07:46:00Z
By B+R UnitTest Helper Version: 6.0.0.173
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("Init", Init), 
	new_TestFixture("Connect", Connect), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaCltInit, "Set_BrbUaCltInit", 0, 0, fixtures, setupSet, 0, cyclicSetCaller);

