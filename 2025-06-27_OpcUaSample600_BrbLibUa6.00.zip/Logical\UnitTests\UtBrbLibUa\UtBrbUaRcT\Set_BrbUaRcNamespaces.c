#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_CYCLIC_SET(void)
{
	if(RunClient.State.eState >= eBRB_RCSTATE_INIT_DONE && RunClient.State.eState < eBRB_RCSTATE_EXITING)
	{
		if(bRunCyclic == 1)
		{
			fbBrbUaRunClientCyclic.pRunClient = &RunClient;
			BrbUaRunClientCyclic(&fbBrbUaRunClientCyclic);
		}
	}
	BrbUaRcMonitor(&RunClient, &CyclicMonitor);
	return;
}

_TEST BrbUaRcNamespaces_GetNamespace_NulPtr(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcNamespacesInit.BrbUaRcNamespaces_GetNamespace_NulPtr", sizeof(sCurrentUnitTest));

	uintOut = BrbUaRcGetSrvNamespace(0, 0, &Namespace);
	TEST_ASSERT_EQUAL_INT(0, uintOut);
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcNamespaces_GetNamespace_InvalidNamespaceIndex(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcNamespacesInit.BrbUaRcNamespaces_GetNamespace_InvalidNamespaceIndex", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Namespace, 0, sizeof(Namespace));
	uintOut = BrbUaRcGetSrvNamespace(&RunClient, 99, &Namespace);
	TEST_ASSERT_EQUAL_INT(0, uintOut);
	TEST_ASSERT_EQUAL_STRING("", Namespace.sNamespaceUri);
	TEST_ASSERT_EQUAL_INT(0, Namespace.nNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Namespace.nErrorId); // Good

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Namespace.nDatObjNamespaceIndex = 99;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_STRING("", RcMonitor.Namespace.Namespace.sNamespaceUri);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.Namespace.Namespace.nNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.Namespace.Namespace.nErrorId); // Good

	// Finished
	TEST_DONE;
}

_TEST BrbUaRcNamespaces_GetNamespace_InvalidNamespace(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcNamespacesInit.BrbUaRcNamespaces_GetNamespace_InvalidNamespace", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Namespace, 0, sizeof(Namespace));
	uintOut = BrbUaRcGetSrvNamespace(&RunClient, 4, &Namespace);
	TEST_ASSERT_EQUAL_INT(0, uintOut);
	TEST_ASSERT_EQUAL_STRING("http://br-automation.com/InvalidNamespace/", Namespace.sNamespaceUri);
	TEST_ASSERT_EQUAL_INT(0, Namespace.nNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(0xA0000200, Namespace.nErrorId); // PlcOpen_BadNsNotFound

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Namespace.nDatObjNamespaceIndex = 4;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_STRING("http://br-automation.com/InvalidNamespace/", RcMonitor.Namespace.Namespace.sNamespaceUri);
	TEST_ASSERT_EQUAL_INT(0, RcMonitor.Namespace.Namespace.nNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(0xA0000200, RcMonitor.Namespace.Namespace.nErrorId); // PlcOpen_BadNsNotFound
	
	// Finished
	TEST_DONE;
}

_TEST BrbUaRcNamespaces_GetNamespace_Ok(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcNamespacesInit.BrbUaRcNamespaces_GetNamespace_Ok", sizeof(sCurrentUnitTest));

	// Direkt
	memset(&Namespace, 0, sizeof(Namespace));
	uintOut = BrbUaRcGetSrvNamespace(&RunClient, 3, &Namespace);
	TEST_ASSERT_EQUAL_INT(6, uintOut);
	TEST_ASSERT_EQUAL_STRING("http://br-automation.com/OpcUa/PLC/PV/", Namespace.sNamespaceUri);
	TEST_ASSERT_EQUAL_INT(6, Namespace.nNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, Namespace.nErrorId); // Good

	// Monitor
	memset(&RcMonitor, 0, sizeof(RcMonitor));
	RcMonitor.bEnable = 1;
	RcMonitor.Namespace.nDatObjNamespaceIndex = 3;
	BrbUaRcMonitor(&RunClient, &RcMonitor);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, RcMonitor.nMonitorStatus);
	TEST_ASSERT_EQUAL_STRING("http://br-automation.com/OpcUa/PLC/PV/", RcMonitor.Namespace.Namespace.sNamespaceUri);
	TEST_ASSERT_EQUAL_INT(6, RcMonitor.Namespace.Namespace.nNamespaceIndex);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, RcMonitor.Namespace.Namespace.nErrorId); // Good
	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-04-04 12:14:02Z
By B+R UnitTest Helper Version: 6.0.0.146
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("BrbUaRcNamespaces_GetNamespace_NulPtr", BrbUaRcNamespaces_GetNamespace_NulPtr), 
	new_TestFixture("BrbUaRcNamespaces_GetNamespace_InvalidNamespaceIndex", BrbUaRcNamespaces_GetNamespace_InvalidNamespaceIndex), 
	new_TestFixture("BrbUaRcNamespaces_GetNamespace_InvalidNamespace", BrbUaRcNamespaces_GetNamespace_InvalidNamespace), 
	new_TestFixture("BrbUaRcNamespaces_GetNamespace_Ok", BrbUaRcNamespaces_GetNamespace_Ok), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaRcNamespaces, "Set_BrbUaRcNamespaces", 0, 0, fixtures, 0, 0, cyclicSetCaller);

