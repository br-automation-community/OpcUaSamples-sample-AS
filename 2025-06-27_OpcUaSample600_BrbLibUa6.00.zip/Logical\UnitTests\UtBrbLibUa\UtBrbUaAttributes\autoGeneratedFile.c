/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (List of TestSets).
LastUpdated: 2024-11-19 11:17:17Z
By B+R UnitTest Helper Version: 6.0.0.173
*/
#include "UnitTest.h"



UNITTEST_TESTSET_DECLARATION  Set_BrbUaGetAttributeIdDatatype;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaGetAttributeList;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaAddBooleanText;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaAddNodeClassText;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaAddDatatypeIdText;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaAddArrayDimensionText;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaAddAccessLevelText;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaAddEventNotifierText;



UNITTEST_TESTSET_FIXTURES(utTestSets)
{
	new_TestSet(Set_BrbUaGetAttributeIdDatatype),
	new_TestSet(Set_BrbUaGetAttributeList),
	new_TestSet(Set_BrbUaAddBooleanText),
	new_TestSet(Set_BrbUaAddNodeClassText),
	new_TestSet(Set_BrbUaAddDatatypeIdText),
	new_TestSet(Set_BrbUaAddArrayDimensionText),
	new_TestSet(Set_BrbUaAddAccessLevelText),
	new_TestSet(Set_BrbUaAddEventNotifierText),
};
UNTITTEST_TESTSET_HANDLER();

