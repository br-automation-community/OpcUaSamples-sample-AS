#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/* Gibt zur�ck, ob eine NodeId Null ist */
plcbit BrbUaIsNodeIdNull(struct UANodeID* pNodeId)
{
	if(pNodeId == 0)
	{
		return 1;
	}
	if(strcmp(pNodeId->Identifier, "") == 0)
	{
		return 1;
	}
	if(pNodeId->NamespaceIndex == 0)
	{
		if(pNodeId->IdentifierType == UAIT_Numeric)
		{
			if(strcmp(pNodeId->Identifier, "0") == 0)
			{
				return 1;
			}
		}
	}
	return 0;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)
