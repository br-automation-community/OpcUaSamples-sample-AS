/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (List of TestSets).
LastUpdated: 2024-03-25 11:33:57Z
By B+R UnitTest Helper Version: 6.0.0.146
*/
#include "UnitTest.h"



UNITTEST_TESTSET_DECLARATION  Set_BrbUaSetLocalizedTextString;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaSetLocalizedTextWcString;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaGetRandomLocalizedText;
UNITTEST_TESTSET_DECLARATION  Set_BrbUaAddLocalizedTextString;



UNITTEST_TESTSET_FIXTURES(utTestSets)
{
	new_TestSet(Set_BrbUaSetLocalizedTextString),
	new_TestSet(Set_BrbUaSetLocalizedTextWcString),
	new_TestSet(Set_BrbUaGetRandomLocalizedText),
	new_TestSet(Set_BrbUaAddLocalizedTextString),
};
UNTITTEST_TESTSET_HANDLER();

