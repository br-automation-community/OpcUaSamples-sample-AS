#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#include "UnitTest.h"
#include "BrbAsserts.h"
#include <string.h>

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

_SETUP_SET(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue._SETUP_SET", sizeof(sCurrentUnitTest));

	bOperateSubscriptionQueue = 0;
	memset(&fbUA_MonItemOperateList_Ok, 0, sizeof(fbUA_MonItemOperateList_Ok));
	memset(&Data, 0, sizeof(Data));
	memset(&SubscriptionQueueDataStored, 0, sizeof(SubscriptionQueueDataStored));

	// Operate Queue besetzen
	memset(&Subscription, 0, sizeof(Subscription));
	BrbUaRcGetSubscription(&RunClient, SUBQUEUE_IDX_OK, &Subscription, 0);
	fbUA_MonItemOperateList_Ok.SubscriptionHdl = Subscription.nSubscriptionHandle;
	fbUA_MonItemOperateList_Ok.MonitoredItemHdlCount = 2;
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	BrbUaRcGetMonitoredItem(&RunClient, SUBQUEUE_IDX_OK, 0, &MonitoredItem);
	fbUA_MonItemOperateList_Ok.MonitoredItemHdls[0] = MonitoredItem.nMonitoredItemHandle;
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	BrbUaRcGetMonitoredItem(&RunClient, SUBQUEUE_IDX_OK, 1, &MonitoredItem);
	fbUA_MonItemOperateList_Ok.MonitoredItemHdls[1] = MonitoredItem.nMonitoredItemHandle;
	
	// Finished
	TEST_DONE;
}

_CYCLIC_SET(void)
{
	if(RunClient.State.eState >= eBRB_RCSTATE_INIT_DONE && RunClient.State.eState < eBRB_RCSTATE_EXITING)
	{
		if(bRunCyclic == 1)
		{
			fbBrbUaRunClientCyclic.pRunClient = &RunClient;
			BrbUaRunClientCyclic(&fbBrbUaRunClientCyclic);
		}
		// Operate Queue
		fbUA_MonItemOperateList_Ok.Execute = bOperateSubscriptionQueue;
		if(fbUA_MonItemOperateList_Ok.Busy)
		{
			fbUA_MonItemOperateList_Ok.Execute = 1;
		}
		else if(fbUA_MonItemOperateList_Ok.Done || fbUA_MonItemOperateList_Ok.Error)
		{
			fbUA_MonItemOperateList_Ok.Execute = 0;
		}
		UA_MonitoredItemOperateList(&fbUA_MonItemOperateList_Ok);
	}
	BrbUaRcMonitor(&RunClient, &CyclicMonitor);
	return;
}

_TEST SubscriptionQueue_CheckMonitoredItems(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_CheckMonitoredItems", sizeof(sCurrentUnitTest));

	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, SUBQUEUE_IDX_INV_SIZE, 0, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0xB000000D, MonitoredItem.nMonitoredItemErrorId); // PlcOpen_BadMonitoringQueueSize
	
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, SUBQUEUE_IDX_INV_SIZE, 1, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0xB000000D, MonitoredItem.nMonitoredItemErrorId); // PlcOpen_BadMonitoringQueueSize
	
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, SUBQUEUE_IDX_INV_SIZE, 2, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0xB000000D, MonitoredItem.nMonitoredItemErrorId); // PlcOpen_BadMonitoringQueueSize

	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, SUBQUEUE_IDX_OK, 0, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nMonitoredItemErrorId); // Good
	
	memset(&MonitoredItem, 0, sizeof(MonitoredItem));
	uintOut = BrbUaRcGetMonitoredItem(&RunClient, SUBQUEUE_IDX_OK, 1, &MonitoredItem);
	TEST_ASSERT_EQUAL_INT(eBRB_ERR_OK, uintOut);
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nNodeHandleErrorId); // Good
	BRB_ASSERT_EQUAL_UDINT(0x00000000, MonitoredItem.nMonitoredItemErrorId); // Good

	// Finished
	TEST_DONE;
}

// Test des Empfangs -------------------------------------------------------------------------------------------------------------------

_TEST SubscriptionQueue_Receive_NotOperating_Store(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_Receive_NotOperating_Store", sizeof(sCurrentUnitTest));

	// Werte speichern
	memcpy(&SubscriptionQueueDataStored, &Data.SubscriptionQueue, sizeof(SubscriptionQueueDataStored));
	memset(&Data.SubscriptionQueue.nUintCltQueueNodeQuality002, 0, sizeof(Data.SubscriptionQueue.nUintCltQueueNodeQuality002));
	memset(&Data.SubscriptionQueue.dtUintCltQueueTimeStamp002, 0, sizeof(Data.SubscriptionQueue.dtUintCltQueueTimeStamp002));
	memset(&Data.SubscriptionQueue.nUintCltQueueNodeQuality010, 0, sizeof(Data.SubscriptionQueue.nUintCltQueueNodeQuality010));
	memset(&Data.SubscriptionQueue.dtUintCltQueueTimeStamp010, 0, sizeof(Data.SubscriptionQueue.dtUintCltQueueTimeStamp010));

	// Finished
	TEST_DONE;
}

_TEST SubscriptionQueue_Receive_NotOperating_Wait(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_Receive_NotOperating_Wait", sizeof(sCurrentUnitTest));

	// Zeit abwarten
	fbTonWait.IN = 1;
	fbTonWait.PT = 2000;
	TON(&fbTonWait);
	TEST_BUSY_CONDITION(fbTonWait.Q == 0)
	fbTonWait.IN = 0;
	TON(&fbTonWait);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionQueue_Receive_NotOperating_Check(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_Receive_NotOperating_Check", sizeof(sCurrentUnitTest));

	// Werte testen. Achtung: Da der Update stark von Zeiten abh�ngt, die ArSim aber nicht deterministisch ist, kann hier manchmal ein Fehler registiert werden!
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUintCltQueue002[0] == Data.SubscriptionQueue.nUintCltQueue002[0], "SubscriptionQueue002 not operated has changed!");
	TEST_ASSERT_MESSAGE(0 == Data.SubscriptionQueue.dtUintCltQueueTimeStamp002[0], "SubscriptionQueue002 not operated time stamp has changed!");
	TEST_ASSERT_MESSAGE(0x00000000 == Data.SubscriptionQueue.nUintCltQueueNodeQuality002[0], "SubscriptionQueue002 not operated node quality is not good!");

	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUintCltQueue010[0] == Data.SubscriptionQueue.nUintCltQueue010[0], "SubscriptionQueue010 not operated has changed!");
	TEST_ASSERT_MESSAGE(0 == Data.SubscriptionQueue.dtUintCltQueueTimeStamp010[0], "SubscriptionQueue010 not operated time stamp has changed!");
	TEST_ASSERT_MESSAGE(0x00000000 == Data.SubscriptionQueue.nUintCltQueueNodeQuality010[0], "SubscriptionQueue010 not operated node quality is not good!");
	
	// Finished
	TEST_DONE;
}

_TEST SubscriptionQueue_Receive_StartOperate(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_Receive_StartOperate", sizeof(sCurrentUnitTest));

	// Operate-Aufruf starten
	bOperateSubscriptionQueue = 1;

	// Finished
	TEST_DONE;
}

_TEST SubscriptionQueue_Receive_Operating_Store(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_Receive_Operating_Store", sizeof(sCurrentUnitTest));

	// Werte speichern
	memcpy(&SubscriptionQueueDataStored, &Data.SubscriptionQueue, sizeof(SubscriptionQueueDataStored));
	memset(&Data.SubscriptionQueue.nUintCltQueueNodeQuality002, 0, sizeof(Data.SubscriptionQueue.nUintCltQueueNodeQuality002));
	memset(&Data.SubscriptionQueue.dtUintCltQueueTimeStamp002, 0, sizeof(Data.SubscriptionQueue.dtUintCltQueueTimeStamp002));
	memset(&Data.SubscriptionQueue.nUintCltQueueNodeQuality010, 0, sizeof(Data.SubscriptionQueue.nUintCltQueueNodeQuality010));
	memset(&Data.SubscriptionQueue.dtUintCltQueueTimeStamp010, 0, sizeof(Data.SubscriptionQueue.dtUintCltQueueTimeStamp010));

	// Finished
	TEST_DONE;
}

_TEST SubscriptionQueue_Receive_Operating_Wait(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_Receive_Operating_Wait", sizeof(sCurrentUnitTest));

	// Zeit abwarten
	fbTonWait.IN = 1;
	fbTonWait.PT = 2000;
	TON(&fbTonWait);
	TEST_BUSY_CONDITION(fbTonWait.Q == 0)
	fbTonWait.IN = 0;
	TON(&fbTonWait);

	// Finished
	TEST_DONE;
}

_TEST SubscriptionQueue_Receive_Operating_Check(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_Receive_Operating_Check", sizeof(sCurrentUnitTest));

	// Werte testen. Achtung: Da der Update stark von Zeiten abh�ngt, die ArSim aber nicht deterministisch ist, kann hier manchmal ein Fehler registiert werden!
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUintCltQueue002 != Data.SubscriptionQueue.nUintCltQueue002, "SubscriptionQueue002 operated was not updated!");
	TEST_ASSERT_MESSAGE(0 != Data.SubscriptionQueue.dtUintCltQueueTimeStamp002[0], "SubscriptionQueue002 operated time stamp has not changed!");
	// Bei QueueSize=2: NodeQuality=1152
	// Siehe Ticketnr 400426494: Ist so korrekt
	TEST_ASSERT_MESSAGE(1152 == Data.SubscriptionQueue.nUintCltQueueNodeQuality002[0], "SubscriptionQueue002 operated node quality is not 1152!");
	TEST_ASSERT_MESSAGE(SubscriptionQueueDataStored.nUintCltQueue010 != Data.SubscriptionQueue.nUintCltQueue010, "SubscriptionQueue010 operated was not updated!");
	TEST_ASSERT_MESSAGE(0 != Data.SubscriptionQueue.dtUintCltQueueTimeStamp010[0], "SubscriptionQueue010 operated time stamp has not changed!");
	TEST_ASSERT_MESSAGE(0x00000000 == Data.SubscriptionQueue.nUintCltQueueNodeQuality010[0], "SubscriptionQueue010 operated node quality is not good!");

	// Finished
	TEST_DONE;
}

_TEST SubscriptionQueue_Receive_EndOperate(void)
{
	BrbStringCopy(sCurrentUnitTest, "BrbUaRcSubscriptionQueue.SubscriptionQueue_Receive_EndOperate", sizeof(sCurrentUnitTest));

	// Operate-Aufruf beenden
	bOperateSubscriptionQueue = 0;

	// Zeit abwarten
	fbTonWait.IN = 1;
	fbTonWait.PT = 1000;
	TON(&fbTonWait);
	TEST_BUSY_CONDITION(fbTonWait.Q == 0)
	fbTonWait.IN = 0;
	TON(&fbTonWait);

	// Finished
	TEST_DONE;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/*
B+R UnitTest: This is generated code.
Do not edit! Do not move!
Description: UnitTest Testprogramm infrastructure (TestSet).
LastUpdated: 2024-09-25 14:19:43Z
By B+R UnitTest Helper Version: 6.0.0.173
*/
UNITTEST_FIXTURES(fixtures)
{
	new_TestFixture("SubscriptionQueue_CheckMonitoredItems", SubscriptionQueue_CheckMonitoredItems), 
	new_TestFixture("SubscriptionQueue_Receive_NotOperating_Store", SubscriptionQueue_Receive_NotOperating_Store), 
	new_TestFixture("SubscriptionQueue_Receive_NotOperating_Wait", SubscriptionQueue_Receive_NotOperating_Wait), 
	new_TestFixture("SubscriptionQueue_Receive_NotOperating_Check", SubscriptionQueue_Receive_NotOperating_Check), 
	new_TestFixture("SubscriptionQueue_Receive_StartOperate", SubscriptionQueue_Receive_StartOperate), 
	new_TestFixture("SubscriptionQueue_Receive_Operating_Store", SubscriptionQueue_Receive_Operating_Store), 
	new_TestFixture("SubscriptionQueue_Receive_Operating_Wait", SubscriptionQueue_Receive_Operating_Wait), 
	new_TestFixture("SubscriptionQueue_Receive_Operating_Check", SubscriptionQueue_Receive_Operating_Check), 
	new_TestFixture("SubscriptionQueue_Receive_EndOperate", SubscriptionQueue_Receive_EndOperate), 
};

UNITTEST_CALLER_COMPLETE_EXPLICIT(Set_BrbUaRcSubscriptionQueue, "Set_BrbUaRcSubscriptionQueue", 0, 0, fixtures, setupSet, 0, cyclicSetCaller);

