#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLib.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

/* Sicheres Kopieren eines WcStrings */
unsigned long BrbWcStringCopy(plcwstring* pDest, plcwstring* pSrc, unsigned long nDestSize)
{
	UDINT nTotalLen = 0;
	if(pDest != 0 && pSrc != 0 && nDestSize > 0)
	{
		// Quellstring kopieren
		nTotalLen = brwcslen(pSrc);
		UDINT nCopySize = nTotalLen * 2;
		UDINT nDestinationSize = nDestSize-2;
		if(nCopySize > nDestinationSize)
		{
			nCopySize = nDestinationSize;
		}
		memcpy(pDest, pSrc, nCopySize);
		// Zielstring mit 0 auff�llen (gleichzeitig wird auf jeden Fall der Null-Terminator gesetzt)
		memset((USINT*)pDest+nCopySize, 0, nDestSize-nCopySize);
	}
	return nTotalLen;
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)
