
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif

// NOLINTBEGIN(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)

void _INIT ProgramInit(void)
{
	// Initialisieren des RunServers
	brsmemset((UDINT)&fbBrbUaRunServerInit, 0, sizeof(fbBrbUaRunServerInit));
	brsmemset((UDINT)&fbBrbUaRunServerCyclic, 0, sizeof(fbBrbUaRunServerCyclic));
	brsmemset((UDINT)&fbBrbUaRunServerExit, 0, sizeof(fbBrbUaRunServerExit));
	brsmemset((UDINT)&RunServer, 0, sizeof(RunServer));
	
	// Aufruf zum Initialisieren des RunServers
	brsstrcpy((UDINT)&RunServer.Cfg.sCfgDataObjName, (UDINT)&"UtRs");
	do
	{
		fbBrbUaRunServerInit.pRunServer = &RunServer;
		BrbUaRunServerInit(&fbBrbUaRunServerInit);
	} while(fbBrbUaRunServerInit.nStatus == eBRB_ERR_BUSY);
	
	// Initialisierung der Daten
	brsmemset((UDINT)&Data, 0, sizeof(Data));
	for(nIndex=0; nIndex<=nDATA_INDEX_MAX; nIndex++)
	{
		Data.Read.anUint[nIndex] = nIndex;
	}
	for(nIndex=0; nIndex<=nDATA_INDEX_MAX; nIndex++)
	{
		Data.SubscriptionVar.anUint[nIndex] = nIndex;
	}
	
	// Initialisieren der Methoden
	brsmemset((UDINT)&MethodWait, 0, sizeof(MethodWait));
	brsstrcpy((UDINT)&MethodWait.Par.sMethodName, (UDINT)&"Wait");
	MethodWait.Par.bEnable = 1;

	brsmemset((UDINT)&MethodCalculate, 0, sizeof(MethodCalculate));
	brsstrcpy((UDINT)&MethodCalculate.Par.sMethodName, (UDINT)&"Calculate");
	MethodCalculate.Par.bEnable = 1;

	brsmemset((UDINT)&MethodArgs0, 0, sizeof(MethodArgs0));
	brsstrcpy((UDINT)&MethodArgs0.Par.sMethodName, (UDINT)&"Args0");
	MethodArgs0.Par.bEnable = 1;

	brsmemset((UDINT)&MethodArgs10, 0, sizeof(MethodArgs10));
	brsstrcpy((UDINT)&MethodArgs10.Par.sMethodName, (UDINT)&"Args10");
	MethodArgs10.Par.bEnable = 1;

	brsmemset((UDINT)&MethodResultTest, 0, sizeof(MethodResultTest));
	brsstrcpy((UDINT)&MethodResultTest.Par.sMethodName, (UDINT)&"ResultTest");
	MethodResultTest.Par.bEnable = 1;

	// Initialisierung der Browse-Daten
	brsmemset((UDINT)&BrowseArrays, 0, sizeof(BrowseArrays));
}

void _CYCLIC ProgramCyclic(void)
{
	// Zyklischer Aufruf des RunServers
	if(RunServer.State.eState >= eBRB_RSSTATE_INIT_DONE && RunServer.State.eState <= eBRB_RSSTATE_EXITING)
	{
		fbBrbUaRunServerCyclic.pRunServer = &RunServer;
		BrbUaRunServerCyclic(&fbBrbUaRunServerCyclic);
	}

	// RunServer-Monitor
	BrbUaRsMonitor(&RunServer, &RsMonitor);	

	// Methode "Wait"
	if(BrbUaSrvHandleMethod(&MethodWait) == 0)
	{
		if(MethodWait.State.bExecuteUserCode == 1)
		{
			// User-Code
			fbTonWait.IN = 1;
			fbTonWait.PT = Data.Methods.Wait.nWaitMs;
			TON(&fbTonWait);
			if(fbTonWait.Q == 1)
			{
				fbTonWait.IN = 0;
				TON(&fbTonWait);
				// R�ckmeldung
				MethodWait.Par.nMethodResult = 0x00000000; // Good 
				MethodWait.Par.bUserCodeIsFinished = 1;
			}
		}
		else
		{
			fbTonWait.IN = 0;
			TON(&fbTonWait);
		}
	}

	// Methode "Calculate"
	if(BrbUaSrvHandleMethod(&MethodCalculate) == 0)
	{
		if(MethodCalculate.State.bExecuteUserCode == 1)
		{
			// User-Code
			Data.Methods.Calculate.nOut0 = Data.Methods.Calculate.nIn0 + Data.Methods.Calculate.nIn1;
			Data.Methods.Calculate.nOut1 = Data.Methods.Calculate.nIn0 * Data.Methods.Calculate.nIn1;
			// R�ckmeldung
			MethodCalculate.Par.nMethodResult = 0x00000000; // Good 
			MethodCalculate.Par.bUserCodeIsFinished = 1;
		}
	}

	// Methode "Args0"
	if(BrbUaSrvHandleMethod(&MethodArgs0) == 0)
	{
		if(MethodArgs0.State.bExecuteUserCode == 1)
		{
			// User-Code
			// R�ckmeldung
			MethodArgs0.Par.nMethodResult = 0x00000000; // Good 
			MethodArgs0.Par.bUserCodeIsFinished = 1;
		}
	}

	// Methode "Args10"
	if(BrbUaSrvHandleMethod(&MethodArgs10) == 0)
	{
		if(MethodArgs10.State.bExecuteUserCode == 1)
		{
			// User-Code
			Data.Methods.Args10.nOut0 = Data.Methods.Args10.nIn0;
			Data.Methods.Args10.nOut1 = Data.Methods.Args10.nIn1;
			Data.Methods.Args10.nOut2 = Data.Methods.Args10.nIn2;
			Data.Methods.Args10.nOut3 = Data.Methods.Args10.nIn3;
			Data.Methods.Args10.nOut4 = Data.Methods.Args10.nIn4;
			Data.Methods.Args10.nOut5 = Data.Methods.Args10.nIn5;
			Data.Methods.Args10.nOut6 = Data.Methods.Args10.nIn6;
			Data.Methods.Args10.nOut7 = Data.Methods.Args10.nIn7;
			Data.Methods.Args10.nOut8 = Data.Methods.Args10.nIn8;
			Data.Methods.Args10.nOut9 = Data.Methods.Args10.nIn9;
			// R�ckmeldung
			MethodArgs10.Par.nMethodResult = 0x00000000; // Good 
			MethodArgs10.Par.bUserCodeIsFinished = 1;
		}
	}

	// Methode "ResultTest"
	if(BrbUaSrvHandleMethod(&MethodResultTest) == 0)
	{
		if(MethodResultTest.State.bExecuteUserCode == 1)
		{
			// User-Code
			// R�ckmeldung
			MethodResultTest.Par.nMethodResult = Data.Methods.ResultTest.nInStatus;
			MethodResultTest.Par.bUserCodeIsFinished = 1;
		}
	}

	// SubscriptionVar
	fbTonSubscriptionVar.IN = 1;
	fbTonSubscriptionVar.PT = 100;
	TON(&fbTonSubscriptionVar);
	if(fbTonSubscriptionVar.Q == 1)
	{
		fbTonSubscriptionVar.IN = 0;
		TON(&fbTonSubscriptionVar);
		for(nIndex=0; nIndex<=nDATA_INDEX_MAX; nIndex++)
		{
			Data.SubscriptionVar.anUint[nIndex]++;
		}		
	}

	// SubscriptionQueue
	fbTonSubscriptionQueue.IN = 1;
	fbTonSubscriptionQueue.PT = 100;
	TON(&fbTonSubscriptionQueue);
	if(fbTonSubscriptionQueue.Q == 1)
	{
		fbTonSubscriptionQueue.IN = 0;
		TON(&fbTonSubscriptionQueue);
		Data.SubscriptionQueue.nUintSrv++;
	}

	// SubscriptionEvent (SystemStatusChangeEventType)
	fbTonSubscriptionEvent.IN = (RunServer.State.eState == eBRB_RSSTATE_RUNNING);
	fbTonSubscriptionEvent.PT = 1000;
	TON(&fbTonSubscriptionEvent);
	if(fbTonSubscriptionEvent.Q == 1)
	{
		fbBrbUaRsFireEvent.pRunServer = &RunServer;
		fbBrbUaRsFireEvent.nEventIndex = 4;
		BrbUaRsFireEvent(&fbBrbUaRsFireEvent);
		if(fbBrbUaRsFireEvent.bInit == 1)
		{
			BrbUaSetLocalizedTextString(&Data.SubscriptionEvent.SysStatusChangeEventSrv.Message, "en", "UnitTestSystemStatusChangeEvent");
			Data.SubscriptionEvent.SysStatusChangeEventSrv.nSeverity = (UINT)BrbGetRandomUdint(1, 999);
			BrbUaSetNodeId(&Data.SubscriptionEvent.SysStatusChangeEventSrv.SourceNode, "2253", 0);
			BrbStringCopy(Data.SubscriptionEvent.SysStatusChangeEventSrv.sSourceName, "UnitTestServer", sizeof(Data.SubscriptionEvent.SysStatusChangeEventSrv.sSourceName));
			Data.SubscriptionEvent.SysStatusChangeEventSrv.eSystemState++;
			if(Data.SubscriptionEvent.SysStatusChangeEventSrv.eSystemState > eSYSCHANGESTATE_UNKNOWN)
			{
				Data.SubscriptionEvent.SysStatusChangeEventSrv.eSystemState = eSYSCHANGESTATE_RUNNING;
			}
		}
		if(fbBrbUaRsFireEvent.nStatus != eBRB_ERR_BUSY)
		{
			// Timer neu triggern
			fbTonSubscriptionEvent.IN = 0;
			TON(&fbTonSubscriptionEvent);
		}
	}

}

void _EXIT ProgramExit(void)
{
	// Aufruf zum Exit des RunServers
	do
	{
		fbBrbUaRunServerExit.pRunServer = &RunServer;
		BrbUaRunServerExit(&fbBrbUaRunServerExit);
	} while(fbBrbUaRunServerExit.nStatus == eBRB_ERR_BUSY);
}

// NOLINTEND(readability-*, bugprone-easily-swappable-parameters, bugprone-branch-clone, clang-diagnostic-invalid-utf8, clang-diagnostic-invalid-source-encoding, clang-diagnostic-pointer-arith, clang-diagnostic-strict-prototypes, clang-diagnostic-bad-function-cast, clang-analyzer-security.insecureAPI.*, hicpp-uppercase-literal-suffix, cppcoreguidelines-*, performance-*)
